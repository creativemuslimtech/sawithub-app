// Dashboard / Ringkasan — main app screen

const KPICard = ({ label, value, sub, delta, deltaTone = "emerald", chart, accent = "var(--c1)" }) => (
  <div className="card" style={{ padding: 22, position: "relative", overflow: "hidden" }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
      <div>
        <div style={{ fontSize: 12, fontWeight: 600, color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: "0.06em" }}>{label}</div>
        <div className="num" style={{ fontSize: 32, fontWeight: 700, letterSpacing: "-0.025em", marginTop: 8 }}>{value}</div>
        {sub && <div style={{ fontSize: 12, color: "var(--ink-4)", marginTop: 2 }}>{sub}</div>}
      </div>
      {delta && (
        <span className={`chip chip-${deltaTone}`} style={{ fontSize: 11 }}>{delta}</span>
      )}
    </div>
    {chart && <div style={{ marginLeft: -8, marginRight: -8 }}>{chart}</div>}
    <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 3, background: accent, borderRadius: "20px 20px 0 0" }} />
  </div>
);

const DashboardPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="ringkasan" />
    <div style={{ padding: "28px 28px 36px" }}>
      {/* Welcome strip */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
        <div>
          <div className="eyebrow" style={{ marginBottom: 8 }}>Selamat pagi · Senin, 14 Mei 2026</div>
          <h1 className="display" style={{ margin: 0, fontSize: 36, fontWeight: 700, letterSpacing: "-0.025em" }}>
            Pak Budi, kebun kamu untung <span style={{ color: "var(--emerald)" }}>Rp 38,4 jt</span> bulan ini.
          </h1>
          <p style={{ margin: "8px 0 0", color: "var(--ink-3)", fontSize: 14.5 }}>2 jadwal kerja besok · Harga TBS naik 4,2% pagi ini.</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <div style={{ display: "inline-flex", padding: 4, background: "white", border: "1px solid var(--line)", borderRadius: 10 }}>
            {["Minggu", "Bulan", "Tahun"].map((t, i) => (
              <button key={t} style={{ padding: "8px 14px", background: i === 1 ? "var(--ink)" : "transparent", color: i === 1 ? "white" : "var(--ink-3)", border: "none", borderRadius: 7, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>{t}</button>
            ))}
          </div>
          <button className="btn btn-emerald"><Icons.Plus size={14} stroke="white" /> Catat panen</button>
        </div>
      </div>

      {/* KPI row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 20 }}>
        <KPICard
          label="Pendapatan"
          value="Rp 84,2 jt"
          sub="dari 12 panen · 38 ton TBS"
          delta="↑ 12,4%"
          accent="var(--c1)"
          chart={<AreaChart data={[8, 12, 10, 16, 14, 22, 28, 32]} width={300} height={56} showGrid={false} padding={0} stroke="var(--c1)" fill="rgba(10,120,71,0.18)" />}
        />
        <KPICard
          label="Biaya operasional"
          value="Rp 45,8 jt"
          sub="bahan + tenaga kerja"
          delta="↓ 3,1%"
          deltaTone="emerald"
          accent="var(--c2)"
          chart={<AreaChart data={[18, 22, 20, 19, 22, 21, 19, 18]} width={300} height={56} showGrid={false} padding={0} stroke="var(--c2)" fill="rgba(217,106,44,0.18)" />}
        />
        <KPICard
          label="Untung bersih"
          value="Rp 38,4 jt"
          sub="margin 45,6%"
          delta="↑ 18,2%"
          accent="var(--c4)"
          chart={<AreaChart data={[4, 6, 5, 10, 8, 14, 16, 20]} width={300} height={56} showGrid={false} padding={0} stroke="var(--c4)" fill="rgba(28,142,138,0.18)" />}
        />
        <KPICard
          label="Harga rata-rata TBS"
          value="Rp 2.318"
          sub="per kg · Mei 2026"
          delta="↑ 4,2%"
          accent="var(--c3)"
          chart={<AreaChart data={[2100, 2150, 2200, 2180, 2280, 2310, 2340, 2318]} width={300} height={56} showGrid={false} padding={0} stroke="var(--c3)" fill="rgba(212,160,23,0.2)" />}
        />
      </div>

      {/* Main grid */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16 }}>
        {/* Left big chart */}
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18 }}>
            <div>
              <div className="eyebrow">Arus kas · 12 bulan</div>
              <h3 className="display" style={{ fontSize: 22, fontWeight: 700, margin: "6px 0 0", letterSpacing: "-0.02em" }}>Pendapatan vs Biaya per Kebun</h3>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              {[["Suka Maju", "var(--c1)"], ["Maju Jaya", "var(--c2)"], ["Sumber Sari", "var(--c4)"], ["Tani Makmur", "var(--c5)"]].map(([n, c]) => (
                <span key={n} style={{ fontSize: 12, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 6, color: "var(--ink-3)" }}>
                  <span style={{ width: 8, height: 8, background: c, borderRadius: 2 }} />{n}
                </span>
              ))}
            </div>
          </div>
          <MultiArea
            series={[
              { name: "Suka Maju", data: [12, 14, 18, 16, 22, 24, 28, 26, 32, 30, 38, 42] },
              { name: "Maju Jaya", data: [8, 10, 12, 14, 16, 18, 20, 22, 21, 24, 28, 30] },
              { name: "Sumber Sari", data: [6, 8, 7, 10, 11, 12, 14, 16, 18, 17, 20, 22] },
              { name: "Tani Makmur", data: [4, 5, 6, 8, 9, 10, 12, 14, 13, 15, 17, 18] },
            ]}
            width={800}
            height={250}
            palette={["var(--c1)", "var(--c2)", "var(--c4)", "var(--c5)"]}
          />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            {["Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des", "Jan", "Feb", "Mar", "Apr", "Mei"].map((m, i) => (
              <span key={i} style={{ fontSize: 11, color: "var(--ink-4)", fontFamily: "var(--font-mono)" }}>{m}</span>
            ))}
          </div>
        </div>

        {/* Right: Harga TBS today + jadwal */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card" style={{ padding: 22, background: "linear-gradient(140deg, var(--emerald-2), var(--emerald) 80%)", color: "white", border: "none", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", right: -40, top: -40, opacity: 0.12 }}><SHLogo size={200} mono /></div>
            <div className="eyebrow" style={{ color: "rgba(255,255,255,0.6)" }}>Harga TBS · Hari ini</div>
            <div className="num" style={{ fontSize: 40, fontWeight: 700, letterSpacing: "-0.025em", marginTop: 8 }}>Rp 2.340<span style={{ fontSize: 16, fontWeight: 500, opacity: 0.7 }}>/kg</span></div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6, fontSize: 13 }}>
              <span style={{ background: "var(--terra)", color: "white", padding: "2px 8px", borderRadius: 99, fontWeight: 700, fontSize: 11 }}>↑ 4,2%</span>
              vs kemarin · sumber: Disbun Riau
            </div>
            <div style={{ marginTop: 12 }}>
              <AreaChart data={[2100, 2150, 2200, 2180, 2240, 2280, 2310, 2340]} width={290} height={56} stroke="var(--terra)" fill="rgba(217,106,44,0.3)" fillBottom="rgba(217,106,44,0)" showGrid={false} padding={0} />
            </div>
          </div>

          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <h3 className="display" style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>Jadwal terdekat</h3>
              <a style={{ fontSize: 12, color: "var(--emerald-2)", fontWeight: 700 }}>Lihat semua →</a>
            </div>
            {[
              { date: "BSK", color: "var(--c2)", title: "Pemupukan NPK · Blok A", meta: "240 pohon · Pak Hadi" },
              { date: "RAB", color: "var(--c5)", title: "Semprot rumput · Blok B", meta: "1,2 ha · 3 pekerja" },
              { date: "JUM", color: "var(--c4)", title: "Pruning · Blok C", meta: "180 pohon · Tim A" },
            ].map((j, i) => (
              <div key={i} style={{ display: "flex", gap: 12, padding: "10px 0", borderBottom: i < 2 ? "1px solid var(--line)" : "none" }}>
                <div style={{ width: 42, height: 42, borderRadius: 10, background: j.color, color: "white", display: "grid", placeItems: "center", fontWeight: 700, fontSize: 11, letterSpacing: "0.04em" }}>{j.date}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 700 }}>{j.title}</div>
                  <div style={{ fontSize: 12, color: "var(--ink-4)" }}>{j.meta}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Lower row */}
      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr 1fr", gap: 16, marginTop: 16 }}>
        {/* Recent panen */}
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <div>
              <div className="eyebrow">Riwayat panen</div>
              <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 0" }}>Panen terbaru</h3>
            </div>
            <a style={{ fontSize: 12, color: "var(--emerald-2)", fontWeight: 700 }}>Semua panen →</a>
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ fontSize: 11, color: "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
                <th style={{ textAlign: "left", padding: "8px 0", fontWeight: 600 }}>Tanggal</th>
                <th style={{ textAlign: "left", padding: "8px 0", fontWeight: 600 }}>Kebun</th>
                <th style={{ textAlign: "right", padding: "8px 0", fontWeight: 600 }}>Berat</th>
                <th style={{ textAlign: "right", padding: "8px 0", fontWeight: 600 }}>Harga/kg</th>
                <th style={{ textAlign: "right", padding: "8px 0", fontWeight: 600 }}>Total</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["12 Mei", "Suka Maju · A", "1.240 kg", "Rp 2.340", "Rp 2,9 jt", "var(--c1)"],
                ["10 Mei", "Maju Jaya · B", "980 kg", "Rp 2.310", "Rp 2,3 jt", "var(--c2)"],
                ["08 Mei", "Sumber Sari", "1.450 kg", "Rp 2.280", "Rp 3,3 jt", "var(--c4)"],
                ["05 Mei", "Suka Maju · A", "1.180 kg", "Rp 2.310", "Rp 2,7 jt", "var(--c1)"],
                ["02 Mei", "Tani Makmur", "820 kg", "Rp 2.250", "Rp 1,8 jt", "var(--c5)"],
              ].map((r, i) => (
                <tr key={i} style={{ fontSize: 13, borderTop: "1px solid var(--line)" }}>
                  <td style={{ padding: "12px 0", fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--ink-3)" }}>{r[0]}</td>
                  <td style={{ padding: "12px 0", display: "flex", alignItems: "center", gap: 8, fontWeight: 600 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: r[5] }} />{r[1]}</td>
                  <td style={{ padding: "12px 0", textAlign: "right", fontFamily: "var(--font-mono)" }}>{r[2]}</td>
                  <td style={{ padding: "12px 0", textAlign: "right", fontFamily: "var(--font-mono)" }}>{r[3]}</td>
                  <td style={{ padding: "12px 0", textAlign: "right", fontWeight: 700 }} className="num">{r[4]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Biaya breakdown */}
        <div className="card" style={{ padding: 24 }}>
          <div className="eyebrow">Komposisi biaya</div>
          <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 18px" }}>Pengeluaran Mei</h3>
          <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
            <Donut value={0.42} size={130} stroke={14} color="var(--c1)" track="var(--paper-2)" label={<><div style={{ fontSize: 12, color: "var(--ink-4)" }}>Total</div><div className="num" style={{ fontSize: 18 }}>45,8 jt</div></>} />
            <div style={{ display: "flex", flexDirection: "column", gap: 8, flex: 1 }}>
              {[
                ["Pupuk", "Rp 18,4jt", "var(--c1)"],
                ["Semprot", "Rp 9,2jt", "var(--c3)"],
                ["Tenaga kerja", "Rp 12,8jt", "var(--c2)"],
                ["Transport", "Rp 3,2jt", "var(--c4)"],
                ["Lainnya", "Rp 2,2jt", "var(--c5)"],
              ].map(([n, v, c]) => (
                <div key={n} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 13 }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: c }} />{n}</span>
                  <span className="num" style={{ fontWeight: 700 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tasks */}
        <div className="card" style={{ padding: 24, background: "var(--ink)", color: "white", border: "none" }}>
          <div className="eyebrow" style={{ color: "rgba(255,255,255,0.5)" }}>Saran cepat</div>
          <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 14px", color: "white" }}>AI insight</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {[
              { tone: "var(--terra)", title: "Kebun Tani Makmur biaya rawat naik 38%", desc: "Cek apakah kondisi tanah perlu pemulihan." },
              { tone: "var(--c1)", title: "Hasil Suka Maju · A naik konsisten", desc: "Pertahankan rotasi pupuk 3 bulanan." },
              { tone: "var(--c3)", title: "Harga TBS prediksi naik minggu depan", desc: "Pertimbangkan timing panen Blok B." },
            ].map((s, i) => (
              <div key={i} style={{ padding: 12, background: "rgba(255,255,255,0.05)", borderRadius: 12, borderLeft: `3px solid ${s.tone}` }}>
                <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 3, color: "white" }}>{s.title}</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", lineHeight: 1.4 }}>{s.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);

window.DashboardPage = DashboardPage;
