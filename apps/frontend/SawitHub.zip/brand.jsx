// Brand foundation — logo system, colors, typography, components grid.

const SwatchTile = ({ name, hex, value, light = false }) => (
  <div style={{ background: hex, color: light ? "var(--ink)" : "white", padding: 16, borderRadius: 14, border: light ? "1px solid var(--line)" : "1px solid rgba(0,0,0,0.06)", minHeight: 100, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
    <div style={{ fontSize: 12, fontWeight: 700, opacity: 0.8 }}>{name}</div>
    <div>
      <div className="num" style={{ fontSize: 18, fontWeight: 700 }}>{hex}</div>
      <div style={{ fontSize: 11, opacity: 0.7, fontFamily: "var(--font-mono)" }}>{value}</div>
    </div>
  </div>
);

const BrandFoundation = () => (
  <div className="pg" style={{ padding: 40 }}>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 28 }}>
      {/* Logo system */}
      <div className="card" style={{ padding: 28, gridColumn: "span 2" }}>
        <div className="eyebrow" style={{ marginBottom: 6 }}>01 · Identitas</div>
        <h2 className="display" style={{ margin: "0 0 4px", fontSize: 28, fontWeight: 700 }}>Lambang Pelepah Sawit</h2>
        <p style={{ margin: "0 0 24px", color: "var(--ink-3)", fontSize: 14, maxWidth: 640 }}>
          Bentuk pelepah sawit yang stylized — tulang daun lurus, delapan anak daun simetris yang melengkung ke atas, dan satu titik tandan buah berwarna terakota di puncak. Geometris, ramah, agraris.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr 1fr 1fr", gap: 20 }}>
          <div style={{ background: "var(--paper-2)", borderRadius: 18, padding: 36, display: "grid", placeItems: "center" }}>
            <SHLogo size={140} />
          </div>
          <div style={{ background: "var(--ink)", borderRadius: 18, padding: 36, display: "grid", placeItems: "center", color: "white" }}>
            <div style={{ color: "white" }}>
              <SHLogo size={92} />
            </div>
          </div>
          <div style={{ background: "white", border: "1px solid var(--line)", borderRadius: 18, padding: 24, display: "grid", placeItems: "center", gap: 10 }}>
            <SHWordmark size={28} />
            <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--ink-4)" }}>WORDMARK · LIGHT</div>
          </div>
          <div style={{ background: "var(--emerald-2)", borderRadius: 18, padding: 24, display: "grid", placeItems: "center", gap: 10 }}>
            <div style={{ color: "white" }}>
              <SHWordmark size={28} color="white" />
            </div>
            <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "rgba(255,255,255,0.6)" }}>WORDMARK · DARK</div>
          </div>
        </div>
      </div>

      {/* Color */}
      <div className="card" style={{ padding: 28 }}>
        <div className="eyebrow" style={{ marginBottom: 6 }}>02 · Palet</div>
        <h2 className="display" style={{ margin: "0 0 16px", fontSize: 22, fontWeight: 700 }}>Warna utama</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <SwatchTile name="Emerald — Primer" hex="#0A7847" value="oklch(.52 .14 152)" />
          <SwatchTile name="Emerald Dalam" hex="#0F5E3A" value="ink-on-light" />
          <SwatchTile name="Terakota — Aksen" hex="#D96A2C" value="oklch(.65 .14 45)" />
          <SwatchTile name="Tinta" hex="#0D1F17" value="text-primary" />
          <SwatchTile name="Kertas" hex="#FAF6EC" value="surface-bg" light />
          <SwatchTile name="Putih" hex="#FFFFFF" value="surface" light />
        </div>
      </div>

      {/* Categorical */}
      <div className="card" style={{ padding: 28 }}>
        <div className="eyebrow" style={{ marginBottom: 6 }}>03 · Kategorikal</div>
        <h2 className="display" style={{ margin: "0 0 16px", fontSize: 22, fontWeight: 700 }}>Palet grafik &amp; kategori</h2>
        <p style={{ color: "var(--ink-3)", fontSize: 13, margin: "0 0 16px" }}>
          Dipakai di grafik per-kebun, badge jenis pekerjaan, dan tag laporan. Tidak ada hierarki — semua bobot setara.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
          {[
            ["Emerald", "#0A7847"],
            ["Terakota", "#D96A2C"],
            ["Ochre", "#D4A017"],
            ["Teal", "#1C8E8A"],
            ["Plum", "#7D3A6B"],
            ["Sage", "#5E8A52"],
          ].map(([n, h]) => (
            <div key={n} style={{ background: h, color: "white", borderRadius: 12, padding: 12, minHeight: 64 }}>
              <div style={{ fontSize: 11, fontWeight: 700, opacity: 0.85 }}>{n}</div>
              <div className="mono" style={{ fontSize: 12, opacity: 0.8, marginTop: 18 }}>{h}</div>
            </div>
          ))}
        </div>
      </div>
    </div>

    {/* Typography */}
    <div className="card" style={{ padding: 28, marginBottom: 24 }}>
      <div className="eyebrow" style={{ marginBottom: 6 }}>04 · Tipografi</div>
      <h2 className="display" style={{ margin: "0 0 24px", fontSize: 22, fontWeight: 700 }}>Pasangan jenis huruf</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
        <div>
          <div className="mono" style={{ fontSize: 11, color: "var(--ink-4)", marginBottom: 8 }}>BODY · PLUS JAKARTA SANS</div>
          <div style={{ fontSize: 48, lineHeight: 1, fontWeight: 700, letterSpacing: "-0.02em" }}>Aa Bb Cc</div>
          <div style={{ fontSize: 14, color: "var(--ink-3)", marginTop: 12, lineHeight: 1.6 }}>
            Sans humanis yang dirancang untuk huruf Latin Asia Tenggara. Mudah dibaca di layar kecil, jelas dipakai di kebun.
          </div>
          <div style={{ display: "flex", gap: 18, marginTop: 16, flexWrap: "wrap" }}>
            {[400, 500, 600, 700, 800].map((w) => <span key={w} style={{ fontWeight: w, fontSize: 16 }}>Sawit {w}</span>)}
          </div>
        </div>
        <div>
          <div className="mono" style={{ fontSize: 11, color: "var(--ink-4)", marginBottom: 8 }}>DISPLAY &amp; ANGKA · BRICOLAGE GROTESQUE</div>
          <div className="display" style={{ fontSize: 56, lineHeight: 1, fontWeight: 700, letterSpacing: "-0.03em" }}>Rp 84,2jt</div>
          <div style={{ fontSize: 14, color: "var(--ink-3)", marginTop: 12, lineHeight: 1.6 }}>
            Sans display dengan karakter — dipakai untuk judul besar, angka kartu KPI, dan headline marketing.
          </div>
          <div style={{ display: "flex", gap: 18, marginTop: 16, alignItems: "baseline" }}>
            <span className="num" style={{ fontSize: 28, fontWeight: 700 }}>1.245</span>
            <span className="num" style={{ fontSize: 28, fontWeight: 600 }}>8,4 ton</span>
            <span className="num" style={{ fontSize: 28, fontWeight: 500 }}>+12,3%</span>
          </div>
        </div>
      </div>
    </div>

    {/* Components */}
    <div className="card" style={{ padding: 28 }}>
      <div className="eyebrow" style={{ marginBottom: 6 }}>05 · Komponen Inti</div>
      <h2 className="display" style={{ margin: "0 0 24px", fontSize: 22, fontWeight: 700 }}>Kartu, tombol, &amp; chip</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr 1fr", gap: 20 }}>
        {/* KPI card */}
        <div className="card" style={{ padding: 20, background: "var(--paper)" }}>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Kartu KPI</div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ fontSize: 13, color: "var(--ink-3)", marginBottom: 6 }}>Pendapatan bulan ini</div>
              <div className="num" style={{ fontSize: 36, fontWeight: 700, letterSpacing: "-0.025em" }}>Rp 84,2jt</div>
              <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center" }}>
                <span className="chip chip-emerald">↑ 12,4%</span>
                <span style={{ fontSize: 12, color: "var(--ink-4)" }}>vs bulan lalu</span>
              </div>
            </div>
            <Sparkline data={[12, 18, 16, 22, 19, 28, 32]} />
          </div>
        </div>
        {/* Buttons */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div className="eyebrow">Tombol</div>
          <button className="btn btn-primary">Mulai Sekarang <Icons.Arrow size={14} /></button>
          <button className="btn btn-emerald">Catat Panen <Icons.Plus size={14} /></button>
          <button className="btn btn-ghost">Lihat laporan</button>
          <button style={{ padding: "8px 14px", borderRadius: 999, background: "var(--terra-soft)", color: "var(--terra-2)", fontWeight: 600, fontSize: 13, border: "1px solid rgba(217,106,44,0.18)" }}>Berlangganan Pro</button>
        </div>
        {/* Chips & badges */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div className="eyebrow">Chip &amp; status</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            <span className="chip chip-emerald">● Aktif</span>
            <span className="chip chip-terra">● Perlu rawat</span>
            <span className="chip chip-warn">● Jadwal hari ini</span>
            <span className="chip">● Selesai</span>
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            <span className="chip" style={{ background: "var(--c4)", color: "white", borderColor: "transparent" }}>Pupuk</span>
            <span className="chip" style={{ background: "var(--c3)", color: "white", borderColor: "transparent" }}>Semprot</span>
            <span className="chip" style={{ background: "var(--c5)", color: "white", borderColor: "transparent" }}>Pruning</span>
            <span className="chip" style={{ background: "var(--c6)", color: "white", borderColor: "transparent" }}>Weeding</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

window.BrandFoundation = BrandFoundation;
