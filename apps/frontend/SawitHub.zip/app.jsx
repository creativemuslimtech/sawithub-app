// Main app — design canvas wiring all SawitHub pages.

const { useState, useEffect } = React;

const Cover = () => (
  <div className="pg" style={{ padding: 56, minHeight: 700, display: "flex", flexDirection: "column", justifyContent: "space-between", position: "relative", overflow: "hidden" }}>
    <div style={{ position: "absolute", right: -40, bottom: -60, opacity: 0.07 }}>
      <SHLogo size={620} />
    </div>
    <div style={{ position: "relative" }}>
      <SHWordmark size={26} />
      <div className="eyebrow" style={{ marginTop: 48, color: "var(--emerald-2)" }}>Refactor UI/UX · Mei 2026 · v2.0</div>
      <h1 className="display" style={{ fontSize: 96, lineHeight: 1.0, letterSpacing: "-0.04em", fontWeight: 700, margin: "20px 0 16px", maxWidth: 980 }}>
        Sistem desain<br />baru SawitHub.
      </h1>
      <p style={{ fontSize: 22, color: "var(--ink-3)", lineHeight: 1.45, maxWidth: 720, margin: 0 }}>
        Tema terang, identitas pelepah sawit, palet emerald + krim + terakota.<br />Tipografi data-product. 18 layar — dari landing sampai dashboard.
      </p>
    </div>
    <div style={{ position: "relative", display: "flex", gap: 32, alignItems: "flex-end", flexWrap: "wrap" }}>
      {[
        ["01", "Identitas", "Logo, palet, tipografi"],
        ["02", "Publik", "Landing · Auth"],
        ["03", "Dashboard", "Ringkasan · Insight"],
        ["04", "Operasional", "Lahan · Panen · Rawat"],
        ["05", "Keuangan", "Laporan · Pendapatan · TBS"],
        ["06", "Alat", "Jadwal · Kalkulator"],
        ["07", "Akun", "Profil · Langganan · Notifikasi"],
      ].map(([n, t, s]) => (
        <div key={n} style={{ minWidth: 160 }}>
          <div className="num" style={{ fontSize: 36, fontWeight: 800, color: "var(--emerald)", letterSpacing: "-0.02em" }}>{n}</div>
          <div className="display" style={{ fontSize: 18, fontWeight: 700, marginTop: 4 }}>{t}</div>
          <div style={{ fontSize: 12, color: "var(--ink-4)" }}>{s}</div>
        </div>
      ))}
    </div>
  </div>
);

const App = () => (
  <DesignCanvas
    title="SawitHub · UI/UX Refactor"
    subtitle="Tema terang · Sans body + display sans · Emerald + krim + terakota · Bahasa Indonesia"
  >
    <DCSection id="cover" title="Pengantar">
      <DCArtboard id="cover" label="Sampul" width={1440} height={800}><Cover /></DCArtboard>
    </DCSection>

    <DCSection id="foundation" title="01 · Identitas & Sistem Desain">
      <DCArtboard id="brand" label="Logo · Warna · Tipografi · Komponen" width={1440} height={1280}>
        <BrandFoundation />
      </DCArtboard>
    </DCSection>

    <DCSection id="public" title="02 · Halaman Publik">
      <DCArtboard id="landing" label="Landing Page" width={1440} height={3400}><LandingPage /></DCArtboard>
      <DCArtboard id="login" label="Masuk" width={1440} height={900}><LoginPage /></DCArtboard>
      <DCArtboard id="signup" label="Daftar" width={1440} height={900}><SignupPage /></DCArtboard>
      <DCArtboard id="reset" label="Reset Password" width={1440} height={900}><ResetPasswordPage /></DCArtboard>
    </DCSection>

    <DCSection id="dashboard" title="03 · Dashboard Utama">
      <DCArtboard id="ringkasan" label="Ringkasan · Hari ini" width={1440} height={1200}><DashboardPage /></DCArtboard>
    </DCSection>

    <DCSection id="ops" title="04 · Operasional Kebun">
      <DCArtboard id="lahan" label="Lahan · Daftar Kebun" width={1440} height={1100}><LahanPage /></DCArtboard>
      <DCArtboard id="panen" label="Panen · Riwayat + Form Cepat" width={1440} height={1200}><PanenPage /></DCArtboard>
      <DCArtboard id="perawatan" label="Perawatan · Timeline" width={1440} height={1200}><PerawatanPage /></DCArtboard>
    </DCSection>

    <DCSection id="finance" title="05 · Keuangan">
      <DCArtboard id="laporan" label="Laporan Keuangan" width={1440} height={1400}><LaporanPage /></DCArtboard>
      <DCArtboard id="pendapatan" label="Pendapatan Lain" width={1440} height={1100}><PendapatanPage /></DCArtboard>
      <DCArtboard id="hargatbs" label="Harga TBS" width={1440} height={1200}><HargaTbsPage /></DCArtboard>
    </DCSection>

    <DCSection id="tools" title="06 · Alat">
      <DCArtboard id="jadwal" label="Jadwal Perawatan · Kalender" width={1440} height={1100}><JadwalPage /></DCArtboard>
      <DCArtboard id="kalkulator" label="Kalkulator Pupuk" width={1440} height={1300}><KalkulatorPage /></DCArtboard>
    </DCSection>

    <DCSection id="account" title="07 · Akun & Pengaturan">
      <DCArtboard id="profile" label="Profil & Pengaturan" width={1440} height={1300}><ProfilePage /></DCArtboard>
      <DCArtboard id="subscription" label="Berlangganan & Pembayaran" width={1440} height={1100}><SubscriptionPage /></DCArtboard>
      <DCArtboard id="notif" label="Notifikasi" width={1440} height={1400}><NotifikasiPage /></DCArtboard>
    </DCSection>
  </DesignCanvas>
);

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
