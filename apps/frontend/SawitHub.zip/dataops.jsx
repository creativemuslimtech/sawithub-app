// Data operations — Lahan (kebun list), Panen (harvest list + form), Perawatan list

const StatPill = ({ label, value, accent }) => (
  <div className="card" style={{ padding: 16, display: "flex", flexDirection: "column", gap: 4 }}>
    <span style={{ fontSize: 11, color: "var(--ink-4)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>{label}</span>
    <span className="num" style={{ fontSize: 22, fontWeight: 700, color: accent || "var(--ink)" }}>{value}</span>
  </div>
);

const LahanPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="lahan" />
    <div style={{ padding: "28px 28px 36px" }}>
      <PageHeader
        eyebrow="Data Kebun"
        title="Lahan"
        sub="Catat nama kebun, luas, jumlah pohon, tahun tanam, dan lokasi setiap blok. Data ini dipakai untuk laporan per-hektare dan kalkulator pupuk."
        right={
          <>
            <button className="btn btn-ghost"><Icons.Filter size={14} /> Filter</button>
            <button className="btn btn-ghost"><Icons.Download size={14} /> Ekspor</button>
            <button className="btn btn-primary"><Icons.Plus size={14} stroke="white" /> Tambah Kebun</button>
          </>
        }
      />

      {/* Summary stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 16, marginBottom: 24 }}>
        <StatPill label="Total Kebun" value="6 blok" accent="var(--c1)" />
        <StatPill label="Total Luas" value="18,4 Ha" accent="var(--c4)" />
        <StatPill label="Jumlah Pohon" value="2.480" accent="var(--c2)" />
        <StatPill label="Umur Rata-rata" value="9 tahun" accent="var(--c5)" />
        <StatPill label="Produktivitas" value="1,8 t/ha/bln" accent="var(--c3)" />
      </div>

      {/* Grid of farm cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
        {[
          { name: "Kebun Suka Maju · Blok A", luas: "3,2 Ha", pohon: 480, umur: "8 thn", lokasi: "Desa Suka Maju, Kampar, Riau", status: "Aktif", c: "var(--c1)", prod: 92, panenAkhir: "12 Mei 2026" },
          { name: "Maju Jaya · Blok B", luas: "2,8 Ha", pohon: 420, umur: "11 thn", lokasi: "Desa Maju, Pelalawan, Riau", status: "Perlu rawat", c: "var(--c2)", prod: 68, panenAkhir: "10 Mei 2026" },
          { name: "Sumber Sari", luas: "4,1 Ha", pohon: 620, umur: "7 thn", lokasi: "Desa Sumber, Siak, Riau", status: "Aktif", c: "var(--c4)", prod: 88, panenAkhir: "08 Mei 2026" },
          { name: "Tani Makmur", luas: "3,5 Ha", pohon: 510, umur: "13 thn", lokasi: "Desa Makmur, Rokan Hulu", status: "Replanting", c: "var(--c5)", prod: 42, panenAkhir: "28 Apr 2026" },
          { name: "Sawit Lestari", luas: "2,4 Ha", pohon: 350, umur: "6 thn", lokasi: "Desa Lestari, Indragiri", status: "Aktif", c: "var(--c6)", prod: 76, panenAkhir: "05 Mei 2026" },
          { name: "Harapan Baru", luas: "2,4 Ha", pohon: 100, umur: "2 thn", lokasi: "Desa Harapan, Bengkalis", status: "Belum panen", c: "var(--c3)", prod: 12, panenAkhir: "—" },
        ].map((k, i) => (
          <div key={i} className="card" style={{ padding: 22, position: "relative" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <div style={{ width: 44, height: 44, borderRadius: 12, background: k.c, color: "white", display: "grid", placeItems: "center" }}><Icons.Map size={20} stroke="white" /></div>
                <div>
                  <div className="display" style={{ fontSize: 17, fontWeight: 700, letterSpacing: "-0.015em" }}>{k.name}</div>
                  <div style={{ fontSize: 12, color: "var(--ink-4)", display: "flex", alignItems: "center", gap: 4, marginTop: 2 }}><Icons.Pin size={11} /> {k.lokasi}</div>
                </div>
              </div>
              <span className={`chip ${k.status === "Aktif" ? "chip-emerald" : k.status === "Perlu rawat" ? "chip-terra" : "chip-warn"}`} style={{ fontSize: 11 }}>{k.status}</span>
            </div>

            {/* Stats row */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, padding: "14px 0", borderTop: "1px solid var(--line)", borderBottom: "1px solid var(--line)" }}>
              <div><div style={{ fontSize: 11, color: "var(--ink-4)" }}>Luas</div><div className="num" style={{ fontSize: 16, fontWeight: 700 }}>{k.luas}</div></div>
              <div><div style={{ fontSize: 11, color: "var(--ink-4)" }}>Pohon</div><div className="num" style={{ fontSize: 16, fontWeight: 700 }}>{k.pohon}</div></div>
              <div><div style={{ fontSize: 11, color: "var(--ink-4)" }}>Umur</div><div className="num" style={{ fontSize: 16, fontWeight: 700 }}>{k.umur}</div></div>
            </div>

            {/* Produktivitas bar */}
            <div style={{ marginTop: 14, marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 11, color: "var(--ink-4)" }}>
                <span>Produktivitas</span>
                <span className="num" style={{ fontWeight: 700, color: "var(--ink)" }}>{k.prod}%</span>
              </div>
              <div style={{ height: 6, background: "var(--paper-2)", borderRadius: 99, overflow: "hidden" }}>
                <div style={{ width: `${k.prod}%`, height: "100%", background: k.c, borderRadius: 99 }} />
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 12 }}>
              <span style={{ color: "var(--ink-4)" }}>Panen terakhir: <strong style={{ color: "var(--ink)" }}>{k.panenAkhir}</strong></span>
              <a style={{ color: "var(--emerald-2)", fontWeight: 700, display: "inline-flex", alignItems: "center", gap: 4 }}>Detail <Icons.Arrow size={12} stroke="var(--emerald-2)" /></a>
            </div>
          </div>
        ))}

        {/* Add new tile */}
        <div style={{ borderRadius: 20, border: "2px dashed var(--line)", display: "grid", placeItems: "center", padding: 22, minHeight: 240, cursor: "pointer", background: "white" }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ width: 56, height: 56, borderRadius: 99, background: "var(--paper-2)", display: "grid", placeItems: "center", margin: "0 auto 12px" }}>
              <Icons.Plus size={24} stroke="var(--emerald-2)" />
            </div>
            <div className="display" style={{ fontSize: 16, fontWeight: 700 }}>Tambah Kebun Baru</div>
            <div style={{ fontSize: 12, color: "var(--ink-4)", marginTop: 4 }}>Isi nama, luas, jumlah pohon, dan tahun tanam.</div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const PanenPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="panen" />
    <div style={{ padding: "28px 28px 36px" }}>
      <PageHeader
        eyebrow="Catat Panen"
        title="Riwayat Panen"
        sub="Tanggal, berat janjang, harga, dan biaya panen — hitungan harga rata-rata dan uang masuk otomatis."
        right={
          <>
            <button className="btn btn-ghost"><Icons.Calendar size={14} /> Mei 2026</button>
            <button className="btn btn-ghost"><Icons.Download size={14} /> Ekspor</button>
            <button className="btn btn-emerald"><Icons.Plus size={14} stroke="white" /> Catat Panen</button>
          </>
        }
      />

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16 }}>
        {/* Left: table + chart */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Chart */}
          <div className="card" style={{ padding: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
              <div>
                <div className="eyebrow">Hasil panen · 8 minggu terakhir</div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginTop: 6 }}>
                  <span className="num" style={{ fontSize: 32, fontWeight: 700, letterSpacing: "-0.025em" }}>38,4 ton</span>
                  <span className="chip chip-emerald" style={{ fontSize: 11 }}>↑ 14,8%</span>
                  <span style={{ fontSize: 12, color: "var(--ink-4)" }}>vs 8 minggu sebelumnya</span>
                </div>
              </div>
              <div style={{ display: "inline-flex", padding: 4, background: "var(--paper)", borderRadius: 10 }}>
                {["Ton", "Janjang", "Rupiah"].map((t, i) => (
                  <button key={t} style={{ padding: "6px 12px", background: i === 0 ? "white" : "transparent", color: "var(--ink)", border: i === 0 ? "1px solid var(--line)" : "none", borderRadius: 7, fontSize: 12, fontWeight: 600 }}>{t}</button>
                ))}
              </div>
            </div>
            <Bars data={[3.2, 4.1, 3.8, 4.6, 5.2, 4.8, 5.8, 6.9]} width={760} height={180} color="var(--c1)" labels={["M-7", "M-6", "M-5", "M-4", "M-3", "M-2", "M-1", "Kini"]} />
          </div>

          {/* Table */}
          <div className="card" style={{ padding: 0, overflow: "hidden" }}>
            <div style={{ padding: "18px 22px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid var(--line)" }}>
              <h3 className="display" style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>Daftar panen Mei 2026</h3>
              <div style={{ display: "flex", gap: 8 }}>
                <div style={{ position: "relative" }}>
                  <Icons.Search size={14} stroke="var(--ink-4)" />
                  <input placeholder="Cari kebun..." style={{ position: "absolute", inset: 0, padding: "6px 10px 6px 28px", borderRadius: 8, border: "1px solid var(--line)", fontSize: 12, width: 180 }} />
                </div>
              </div>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ fontSize: 11, color: "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.08em", background: "var(--paper)" }}>
                  <th style={{ textAlign: "left", padding: "10px 22px", fontWeight: 600 }}>Tanggal</th>
                  <th style={{ textAlign: "left", padding: "10px 0", fontWeight: 600 }}>Kebun</th>
                  <th style={{ textAlign: "right", padding: "10px 0", fontWeight: 600 }}>Janjang</th>
                  <th style={{ textAlign: "right", padding: "10px 0", fontWeight: 600 }}>Berat</th>
                  <th style={{ textAlign: "right", padding: "10px 0", fontWeight: 600 }}>Harga/kg</th>
                  <th style={{ textAlign: "right", padding: "10px 0", fontWeight: 600 }}>Biaya panen</th>
                  <th style={{ textAlign: "right", padding: "10px 22px", fontWeight: 600 }}>Total bersih</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["12 Mei 2026", "Suka Maju · A", 248, "1.240 kg", "Rp 2.340", "Rp 320rb", "Rp 2.582.600", "var(--c1)"],
                  ["10 Mei 2026", "Maju Jaya · B", 192, "980 kg", "Rp 2.310", "Rp 260rb", "Rp 2.003.800", "var(--c2)"],
                  ["08 Mei 2026", "Sumber Sari", 286, "1.450 kg", "Rp 2.280", "Rp 390rb", "Rp 2.916.000", "var(--c4)"],
                  ["05 Mei 2026", "Suka Maju · A", 232, "1.180 kg", "Rp 2.310", "Rp 305rb", "Rp 2.420.800", "var(--c1)"],
                  ["02 Mei 2026", "Tani Makmur", 162, "820 kg", "Rp 2.250", "Rp 220rb", "Rp 1.625.000", "var(--c5)"],
                  ["30 Apr 2026", "Sawit Lestari", 198, "1.020 kg", "Rp 2.280", "Rp 270rb", "Rp 2.055.600", "var(--c6)"],
                ].map((r, i) => (
                  <tr key={i} style={{ fontSize: 13, borderTop: "1px solid var(--line)" }}>
                    <td style={{ padding: "14px 22px", fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--ink-3)" }}>{r[0]}</td>
                    <td style={{ padding: "14px 0", fontWeight: 600, display: "flex", alignItems: "center", gap: 8 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: r[7] }} />{r[1]}</td>
                    <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)" }}>{r[2]}</td>
                    <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)" }}>{r[3]}</td>
                    <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)" }}>{r[4]}</td>
                    <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)", color: "var(--terra-2)" }}>{r[5]}</td>
                    <td style={{ padding: "14px 22px", textAlign: "right", fontWeight: 700 }} className="num">{r[6]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{ padding: "12px 22px", borderTop: "1px solid var(--line)", display: "flex", justifyContent: "space-between", fontSize: 12, color: "var(--ink-3)" }}>
              <span>Menampilkan 6 dari 12 panen di Mei 2026</span>
              <div style={{ display: "flex", gap: 4 }}>
                <button className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 12 }}>← Sebelumnya</button>
                <button className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 12 }}>Berikutnya →</button>
              </div>
            </div>
          </div>
        </div>

        {/* Right: quick form */}
        <div className="card" style={{ padding: 22, height: "fit-content", position: "sticky", top: 80 }}>
          <div className="eyebrow">Catat panen baru</div>
          <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 16px" }}>Formulir cepat</h3>

          {[
            { label: "Lahan", val: "Suka Maju · A", icon: Icons.Map },
            { label: "Tanggal panen", val: "14 Mei 2026", icon: Icons.Calendar },
          ].map((f) => (
            <div key={f.label} style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 12, color: "var(--ink-3)", marginBottom: 5, fontWeight: 600 }}>{f.label}</div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "11px 12px", border: "1px solid var(--line)", borderRadius: 10, background: "white" }}>
                <f.icon size={14} stroke="var(--ink-4)" />
                <span style={{ fontSize: 13, fontWeight: 600, flex: 1 }}>{f.val}</span>
                <Icons.Down size={14} stroke="var(--ink-4)" />
              </div>
            </div>
          ))}

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <div style={{ fontSize: 12, color: "var(--ink-3)", marginBottom: 5, fontWeight: 600 }}>Janjang</div>
              <div style={{ padding: "11px 12px", border: "1px solid var(--line)", borderRadius: 10, fontSize: 13, fontFamily: "var(--font-mono)", background: "white" }}>248</div>
            </div>
            <div>
              <div style={{ fontSize: 12, color: "var(--ink-3)", marginBottom: 5, fontWeight: 600 }}>Berat (kg)</div>
              <div style={{ padding: "11px 12px", border: "1px solid var(--line)", borderRadius: 10, fontSize: 13, fontFamily: "var(--font-mono)", background: "white" }}>1.240</div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>
            <div>
              <div style={{ fontSize: 12, color: "var(--ink-3)", marginBottom: 5, fontWeight: 600 }}>Harga/kg</div>
              <div style={{ padding: "11px 12px", border: "1px solid var(--line)", borderRadius: 10, fontSize: 13, fontFamily: "var(--font-mono)", background: "white" }}>Rp 2.340</div>
            </div>
            <div>
              <div style={{ fontSize: 12, color: "var(--ink-3)", marginBottom: 5, fontWeight: 600 }}>Biaya panen</div>
              <div style={{ padding: "11px 12px", border: "1px solid var(--line)", borderRadius: 10, fontSize: 13, fontFamily: "var(--font-mono)", background: "white" }}>Rp 320.000</div>
            </div>
          </div>

          {/* Computed */}
          <div style={{ marginTop: 16, padding: 14, background: "var(--emerald-soft)", border: "1px solid rgba(10,120,71,0.18)", borderRadius: 12 }}>
            <div style={{ fontSize: 11, color: "var(--emerald-2)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em" }}>Total bersih</div>
            <div className="num" style={{ fontSize: 28, fontWeight: 700, color: "var(--emerald-2)", letterSpacing: "-0.02em" }}>Rp 2.582.600</div>
            <div style={{ fontSize: 11, color: "var(--ink-3)", marginTop: 2 }}>Dihitung otomatis · Berat × Harga − Biaya panen</div>
          </div>

          <button className="btn btn-emerald" style={{ width: "100%", justifyContent: "center", marginTop: 14, padding: "12px 18px" }}>Simpan panen <Icons.Check size={14} stroke="white" /></button>
          <button className="btn btn-ghost" style={{ width: "100%", justifyContent: "center", marginTop: 8 }}>Simpan & catat berikutnya</button>
        </div>
      </div>
    </div>
  </div>
);

const PerawatanPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="perawatan" />
    <div style={{ padding: "28px 28px 36px" }}>
      <PageHeader
        eyebrow="Catat Rawat"
        title="Perawatan Kebun"
        sub="Pupuk, semprot, pruning, dan pekerjaan kebun lainnya — pisahkan biaya bahan dan tenaga kerja agar laporan jelas."
        right={
          <>
            <button className="btn btn-ghost"><Icons.Filter size={14} /> Semua jenis</button>
            <button className="btn btn-ghost"><Icons.Calendar size={14} /> 30 hari</button>
            <button className="btn btn-primary"><Icons.Plus size={14} stroke="white" /> Catat Perawatan</button>
          </>
        }
      />

      {/* Top stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 20 }}>
        <KPICard label="Biaya rawat" value="Rp 24,8 jt" sub="30 hari terakhir" delta="↑ 5,4%" deltaTone="warn" accent="var(--c2)" chart={<AreaChart data={[12, 14, 16, 18, 17, 20, 22, 24]} width={300} height={48} showGrid={false} padding={0} stroke="var(--c2)" fill="rgba(217,106,44,0.18)" />} />
        <KPICard label="Material" value="Rp 16,2 jt" sub="pupuk + pestisida" delta="65%" deltaTone="emerald" accent="var(--c4)" chart={<AreaChart data={[8, 10, 11, 12, 11, 14, 15, 16]} width={300} height={48} showGrid={false} padding={0} stroke="var(--c4)" fill="rgba(28,142,138,0.18)" />} />
        <KPICard label="Tenaga kerja" value="Rp 8,6 jt" sub="6 pekerja · 24 hari" delta="35%" deltaTone="emerald" accent="var(--c5)" chart={<AreaChart data={[3, 4, 5, 6, 6, 7, 8, 8.6]} width={300} height={48} showGrid={false} padding={0} stroke="var(--c5)" fill="rgba(125,58,107,0.18)" />} />
        <KPICard label="Per hektare" value="Rp 1,35 jt" sub="biaya rawat / ha" delta="↓ 2,1%" deltaTone="emerald" accent="var(--c3)" chart={<AreaChart data={[1.5, 1.48, 1.42, 1.40, 1.38, 1.36, 1.35, 1.35]} width={300} height={48} showGrid={false} padding={0} stroke="var(--c3)" fill="rgba(212,160,23,0.18)" />} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 16 }}>
        {/* Timeline */}
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
            <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>Timeline perawatan</h3>
            <div style={{ display: "flex", gap: 6 }}>
              {[["Pupuk", "var(--c1)"], ["Semprot", "var(--c3)"], ["Pruning", "var(--c5)"], ["Weeding", "var(--c6)"]].map(([n, c]) => (
                <span key={n} style={{ fontSize: 11, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 5, color: "var(--ink-3)" }}>
                  <span style={{ width: 8, height: 8, background: c, borderRadius: 2 }} />{n}
                </span>
              ))}
            </div>
          </div>

          {/* Activity items */}
          <div style={{ position: "relative" }}>
            <div style={{ position: "absolute", left: 18, top: 0, bottom: 0, width: 2, background: "var(--line)" }} />
            {[
              { date: "12 Mei", icon: Icons.Drop, color: "var(--c1)", title: "Pemupukan NPK Mutiara", kebun: "Suka Maju · A", bahan: "240 kg · Rp 18.500/kg", pekerja: "Pak Hadi + 2", total: "Rp 4.880.000" },
              { date: "08 Mei", icon: Icons.Sparkle, color: "var(--c3)", title: "Semprot rumput Round-up", kebun: "Maju Jaya · B", bahan: "8 liter · Rp 95.000/L", pekerja: "Tim B (3 org)", total: "Rp 1.310.000" },
              { date: "05 Mei", icon: Icons.Leaf, color: "var(--c5)", title: "Pruning pelepah tua", kebun: "Sumber Sari", bahan: "—", pekerja: "Tim A (5 org)", total: "Rp 920.000" },
              { date: "02 Mei", icon: Icons.Drop, color: "var(--c6)", title: "Weeding piringan", kebun: "Tani Makmur", bahan: "—", pekerja: "Tim C (4 org)", total: "Rp 680.000" },
              { date: "28 Apr", icon: Icons.Drop, color: "var(--c1)", title: "Pemupukan Urea + KCl", kebun: "Sawit Lestari", bahan: "180 kg · campur", pekerja: "Pak Yusran + 1", total: "Rp 3.240.000" },
            ].map((a, i) => {
              const I = a.icon;
              return (
                <div key={i} style={{ display: "flex", gap: 16, padding: "14px 0", position: "relative" }}>
                  <div style={{ width: 38, height: 38, borderRadius: 99, background: a.color, color: "white", display: "grid", placeItems: "center", flexShrink: 0, zIndex: 1 }}>
                    <I size={16} stroke="white" />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div>
                        <div style={{ fontSize: 11, color: "var(--ink-4)", fontFamily: "var(--font-mono)" }}>{a.date}</div>
                        <div style={{ fontSize: 14.5, fontWeight: 700, marginTop: 2 }}>{a.title}</div>
                        <div style={{ fontSize: 12, color: "var(--ink-3)", marginTop: 4, display: "flex", gap: 12 }}>
                          <span><Icons.Map size={11} /> {a.kebun}</span>
                          {a.bahan !== "—" && <span>· {a.bahan}</span>}
                          <span>· {a.pekerja}</span>
                        </div>
                      </div>
                      <div className="num" style={{ fontSize: 17, fontWeight: 700 }}>{a.total}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Breakdown */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card" style={{ padding: 24 }}>
            <div className="eyebrow">Biaya per jenis</div>
            <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 18px" }}>Komposisi rawat</h3>
            {[
              ["Pemupukan", 12.4, "Rp 12,4 jt", "var(--c1)", 50],
              ["Semprot rumput", 5.6, "Rp 5,6 jt", "var(--c3)", 22],
              ["Pruning", 3.2, "Rp 3,2 jt", "var(--c5)", 13],
              ["Weeding", 2.4, "Rp 2,4 jt", "var(--c6)", 10],
              ["Lainnya", 1.2, "Rp 1,2 jt", "var(--c2)", 5],
            ].map(([n, _v, label, c, pct]) => (
              <div key={n} style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 13 }}>
                  <span style={{ fontWeight: 600 }}>{n}</span>
                  <span className="num" style={{ fontWeight: 700 }}>{label} <span style={{ color: "var(--ink-4)", fontWeight: 500 }}>· {pct}%</span></span>
                </div>
                <div style={{ height: 8, background: "var(--paper-2)", borderRadius: 99, overflow: "hidden" }}>
                  <div style={{ width: `${pct * 2}%`, height: "100%", background: c, borderRadius: 99 }} />
                </div>
              </div>
            ))}
          </div>

          <div className="card" style={{ padding: 22, background: "var(--terra-soft)", borderColor: "rgba(217,106,44,0.22)" }}>
            <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: "var(--terra)", display: "grid", placeItems: "center", flexShrink: 0 }}><Icons.Sparkle size={16} stroke="white" /></div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: "var(--terra-2)" }}>Saran AI</div>
                <div style={{ fontSize: 13, color: "var(--ink-2)", marginTop: 4, lineHeight: 1.5 }}>
                  Biaya pupuk Suka Maju · A naik 22% dari rotasi sebelumnya. Cek <strong>Kalkulator Pupuk</strong> untuk hitung ulang dosis sesuai umur tanaman.
                </div>
                <a style={{ fontSize: 12, color: "var(--terra-2)", fontWeight: 700, marginTop: 8, display: "inline-flex", gap: 4 }}>Buka kalkulator →</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

Object.assign(window, { LahanPage, PanenPage, PerawatanPage });
