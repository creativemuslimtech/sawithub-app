// Auth pages — Login, Signup, Reset Password.
// Two-column layout: brand panel + form.

const AuthShell = ({ panel, children }) => (
  <div className="pg" style={{ minHeight: 900, display: "grid", gridTemplateColumns: "1.05fr 1fr" }}>
    {/* Brand panel left */}
    <div style={{ background: "var(--ink)", color: "var(--paper)", padding: "32px 40px", position: "relative", overflow: "hidden", display: "flex", flexDirection: "column" }}>
      <div style={{ position: "absolute", inset: 0, opacity: 0.05, backgroundImage: "radial-gradient(circle at 10% 90%, var(--emerald-3), transparent 40%), radial-gradient(circle at 80% 20%, var(--terra), transparent 30%)" }} />
      <div style={{ position: "relative" }}>
        <div style={{ color: "white" }}><SHWordmark size={22} color="white" /></div>
      </div>
      <div style={{ position: "relative", flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", paddingRight: 40 }}>
        {panel}
      </div>
      <div style={{ position: "relative", display: "flex", justifyContent: "space-between", fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
        <span>© 2026 SawitHub</span>
        <span>Bantuan · Privasi · Syarat</span>
      </div>
      <div style={{ position: "absolute", right: -120, bottom: -80, opacity: 0.08, color: "white" }}>
        <SHLogo size={500} mono />
      </div>
    </div>
    {/* Form panel right */}
    <div style={{ padding: "56px 56px", display: "flex", flexDirection: "column", justifyContent: "center", background: "var(--paper)" }}>
      <div style={{ maxWidth: 440, width: "100%", margin: "0 auto" }}>
        {children}
      </div>
    </div>
  </div>
);

const Field = ({ label, hint, type = "text", value, placeholder, icon, right }) => (
  <div style={{ marginBottom: 14 }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 6 }}>
      <label style={{ fontSize: 13, fontWeight: 600, color: "var(--ink-2)" }}>{label}</label>
      {hint && <span style={{ fontSize: 12, color: "var(--ink-4)" }}>{hint}</span>}
    </div>
    <div style={{ position: "relative", display: "flex", alignItems: "center" }}>
      {icon && <div style={{ position: "absolute", left: 14, color: "var(--ink-4)" }}>{icon}</div>}
      <input
        type={type}
        defaultValue={value}
        placeholder={placeholder}
        style={{ width: "100%", padding: `13px ${right ? 44 : 14}px 13px ${icon ? 42 : 14}px`, border: "1px solid var(--line)", borderRadius: 12, fontSize: 14, background: "white", outline: "none", color: "var(--ink)" }}
      />
      {right && <div style={{ position: "absolute", right: 12, color: "var(--ink-4)" }}>{right}</div>}
    </div>
  </div>
);

const PanelQuote = ({ quote, name, role }) => (
  <div>
    <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "5px 12px 5px 8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 999, fontSize: 12, fontWeight: 600, marginBottom: 28 }}>
      <span style={{ background: "var(--emerald)", color: "white", padding: "2px 8px", borderRadius: 99, fontSize: 11, fontWeight: 700 }}>BARU</span>
      Versi 2026 · 12.400+ petani sudah pakai
    </div>
    <h2 className="display" style={{ fontSize: 44, lineHeight: 1.05, letterSpacing: "-0.03em", fontWeight: 700, color: "white", margin: "0 0 24px" }}>{quote}</h2>
    <div style={{ display: "flex", alignItems: "center", gap: 12, paddingTop: 20, borderTop: "1px solid rgba(255,255,255,0.1)" }}>
      <div className="ph" style={{ width: 44, height: 44, borderRadius: 99, background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}>foto</div>
      <div>
        <div style={{ fontSize: 14, fontWeight: 700, color: "white" }}>{name}</div>
        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)" }}>{role}</div>
      </div>
    </div>
    {/* Mini stats card */}
    <div style={{ marginTop: 36, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 18, padding: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
        <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase" }}>Pendapatan tahun ini</span>
        <span className="chip chip-emerald" style={{ fontSize: 11 }}>↑ 18%</span>
      </div>
      <div className="num" style={{ fontSize: 32, fontWeight: 700, color: "white", letterSpacing: "-0.02em" }}>Rp 142,8jt</div>
      <AreaChart data={[6, 9, 8, 12, 11, 15, 18, 22, 24]} width={360} height={56} stroke="var(--terra)" fill="rgba(217,106,44,0.25)" showGrid={false} padding={0} />
    </div>
  </div>
);

const LoginPage = () => (
  <AuthShell panel={<PanelQuote quote={"“Sekali isi panen, langsung tahu untung kebun.”"} name="Pak Suparman" role="Petani Riau · 3,2 ha · Anggota sejak 2024" />}>
    <div className="eyebrow" style={{ marginBottom: 10 }}>Masuk</div>
    <h1 className="display" style={{ fontSize: 36, fontWeight: 700, letterSpacing: "-0.03em", margin: "0 0 8px" }}>Selamat datang kembali.</h1>
    <p style={{ color: "var(--ink-3)", margin: "0 0 32px", fontSize: 14.5, lineHeight: 1.55 }}>Masuk untuk mengelola kebun. Belum punya akun? <a style={{ color: "var(--emerald-2)", fontWeight: 700 }}>Daftar gratis →</a></p>

    <Field label="Email / Username / No. HP" placeholder="email, username, atau 08xx..." icon={<Icons.User size={16} />} />
    <Field label="Password" hint={<span style={{ color: "var(--emerald-2)", fontWeight: 600, cursor: "pointer" }}>Lupa password?</span>} type="password" placeholder="••••••••" icon={<Icons.Lock size={16} />} right={<Icons.Eye size={16} />} />

    <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6, marginBottom: 24, fontSize: 13, color: "var(--ink-3)" }}>
      <div style={{ width: 16, height: 16, borderRadius: 4, border: "1.5px solid var(--ink)", background: "var(--ink)", display: "grid", placeItems: "center" }}><Icons.Check size={11} stroke="white" /></div>
      Ingat saya di perangkat ini
    </div>

    <button className="btn btn-primary" style={{ width: "100%", justifyContent: "center", padding: "14px 20px", fontSize: 15 }}>Masuk ke Dashboard <Icons.Arrow size={16} /></button>

    <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "24px 0" }}>
      <div style={{ flex: 1, height: 1, background: "var(--line)" }} />
      <span style={{ fontSize: 12, color: "var(--ink-4)" }}>atau lanjut dengan</span>
      <div style={{ flex: 1, height: 1, background: "var(--line)" }} />
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
      <button className="btn btn-ghost" style={{ justifyContent: "center", padding: "12px" }}>
        <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#EA4335" d="M5 12a7 7 0 0 1 12-5l2.6-2.6A11 11 0 0 0 1 12l4-1.1c.4-1 1.1-1.8 2-2.4Z"/><path fill="#34A853" d="M3.1 17.5A11 11 0 0 0 12 23a11 11 0 0 0 10.6-7.8l-4.6-1.2A6 6 0 0 1 7.2 15Z"/><path fill="#FBBC05" d="M3.1 17.5 7.2 15c-.3-.8-.4-1.7-.3-2.6L2.4 11A11 11 0 0 0 3 17.5Z"/><path fill="#4285F4" d="M22.6 15.2c.3-1 .4-2 .4-3.2 0-.8-.1-1.6-.2-2.4H12v4.6h6c-.3 1.5-1.2 2.7-2.5 3.5l4.6 1.2c1.4-1.3 2.3-3 2.5-3.7Z"/></svg>
        Google
      </button>
      <button className="btn btn-ghost" style={{ justifyContent: "center", padding: "12px" }}>
        <Icons.Phone size={16} /> OTP WhatsApp
      </button>
    </div>

    <div style={{ background: "white", border: "1px solid var(--line)", borderRadius: 14, padding: 14, marginTop: 28, fontSize: 12.5, color: "var(--ink-3)", lineHeight: 1.55 }}>
      <strong style={{ color: "var(--ink)" }}>Data kebun kamu aman.</strong> Kami tidak menjual data petani. Masuk hanya lewat akun resmi SawitHub.
    </div>
  </AuthShell>
);

const SignupPage = () => (
  <AuthShell panel={
    <div>
      <div className="eyebrow" style={{ color: "var(--terra)", marginBottom: 16 }}>Daftar 14 hari gratis</div>
      <h2 className="display" style={{ fontSize: 44, lineHeight: 1.05, letterSpacing: "-0.03em", fontWeight: 700, color: "white", margin: "0 0 28px" }}>Bawa kebun kamu ke dalam satu aplikasi.</h2>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {[
          ["Catat panen, biaya rawat, dan jadwal kerja dalam hitungan detik.", Icons.Leaf],
          ["Laporan keuangan otomatis — siap untuk koperasi atau bank.", Icons.Chart],
          ["Kalkulator pupuk presisi berdasarkan kadar NPK tanah.", Icons.Calc],
          ["Pengingat jadwal lewat WhatsApp.", Icons.Bell],
        ].map(([t, I], i) => (
          <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: "var(--emerald)", display: "grid", placeItems: "center", flexShrink: 0 }}><I size={14} stroke="white" /></div>
            <div style={{ fontSize: 14.5, color: "rgba(255,255,255,0.85)", lineHeight: 1.55, paddingTop: 4 }}>{t}</div>
          </div>
        ))}
      </div>
    </div>
  }>
    <div className="eyebrow" style={{ marginBottom: 10 }}>Buat akun</div>
    <h1 className="display" style={{ fontSize: 36, fontWeight: 700, letterSpacing: "-0.03em", margin: "0 0 8px" }}>Daftar gratis 14 hari.</h1>
    <p style={{ color: "var(--ink-3)", margin: "0 0 28px", fontSize: 14.5 }}>Tanpa kartu kredit. Sudah punya akun? <a style={{ color: "var(--emerald-2)", fontWeight: 700 }}>Masuk →</a></p>

    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
      <Field label="Nama lengkap" placeholder="Mis. Pak Budi" icon={<Icons.User size={16} />} />
      <Field label="Nama kebun" placeholder="Mis. Kebun Suka Maju" icon={<Icons.Map size={16} />} />
    </div>
    <Field label="No. WhatsApp" hint="Untuk verifikasi & pengingat" placeholder="08xx-xxxx-xxxx" icon={<Icons.Phone size={16} />} />
    <Field label="Email (opsional)" placeholder="email@kamu.id" icon={<Icons.Mail size={16} />} />
    <Field label="Password" hint="Min. 8 karakter" type="password" placeholder="••••••••" icon={<Icons.Lock size={16} />} right={<Icons.Eye size={16} />} />

    <div style={{ display: "flex", alignItems: "flex-start", gap: 8, marginTop: 6, marginBottom: 20, fontSize: 12.5, color: "var(--ink-3)", lineHeight: 1.5 }}>
      <div style={{ width: 16, height: 16, borderRadius: 4, border: "1.5px solid var(--ink)", background: "var(--ink)", display: "grid", placeItems: "center", flexShrink: 0, marginTop: 1 }}><Icons.Check size={11} stroke="white" /></div>
      Saya setuju dengan <a style={{ color: "var(--emerald-2)", fontWeight: 600 }}>Syarat Layanan</a> dan <a style={{ color: "var(--emerald-2)", fontWeight: 600 }}>Kebijakan Privasi</a>.
    </div>

    <button className="btn btn-primary" style={{ width: "100%", justifyContent: "center", padding: "14px 20px", fontSize: 15 }}>Mulai 14 hari gratis <Icons.Arrow size={16} /></button>

    <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 28, padding: 16, background: "var(--emerald-soft)", border: "1px solid rgba(10,120,71,0.18)", borderRadius: 14 }}>
      <div style={{ width: 36, height: 36, borderRadius: 10, background: "var(--emerald)", display: "grid", placeItems: "center" }}><Icons.Sparkle size={18} stroke="white" /></div>
      <div style={{ flex: 1, fontSize: 13, color: "var(--ink-2)", lineHeight: 1.5 }}>
        <strong>Bantuan migrasi gratis.</strong> Punya catatan di Excel atau buku? Kirim ke kami, tim akan memindahkan.
      </div>
    </div>
  </AuthShell>
);

const ResetPasswordPage = () => (
  <AuthShell panel={
    <div>
      <div style={{ width: 64, height: 64, borderRadius: 16, background: "var(--terra)", display: "grid", placeItems: "center", marginBottom: 28 }}>
        <Icons.Lock size={28} stroke="white" />
      </div>
      <h2 className="display" style={{ fontSize: 44, lineHeight: 1.05, letterSpacing: "-0.03em", fontWeight: 700, color: "white", margin: "0 0 16px" }}>Lupa password? Tenang — kebun kamu tetap aman.</h2>
      <p style={{ color: "rgba(255,255,255,0.65)", fontSize: 15, lineHeight: 1.6, margin: 0 }}>
        Kami akan kirim tautan reset ke email atau kode 6 digit ke WhatsApp kamu. Berlaku 15 menit.
      </p>
      <div style={{ marginTop: 32, padding: 16, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 14, fontSize: 13, color: "rgba(255,255,255,0.7)", display: "flex", gap: 12 }}>
        <Icons.Phone size={18} stroke="rgba(255,255,255,0.6)" />
        Butuh bantuan? Hubungi <strong style={{ color: "white" }}>0811-7100-200</strong>
      </div>
    </div>
  }>
    <a style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 13, color: "var(--ink-3)", fontWeight: 600, marginBottom: 24 }}>← Kembali ke masuk</a>
    <div className="eyebrow" style={{ marginBottom: 10 }}>Reset Password</div>
    <h1 className="display" style={{ fontSize: 36, fontWeight: 700, letterSpacing: "-0.03em", margin: "0 0 8px" }}>Atur ulang password.</h1>
    <p style={{ color: "var(--ink-3)", margin: "0 0 28px", fontSize: 14.5, lineHeight: 1.55 }}>Masukkan email atau nomor WhatsApp yang terdaftar.</p>

    {/* Tab toggle */}
    <div style={{ display: "inline-flex", padding: 4, background: "white", border: "1px solid var(--line)", borderRadius: 10, marginBottom: 20 }}>
      <button style={{ padding: "8px 16px", background: "var(--ink)", color: "white", border: "none", borderRadius: 7, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>📱 WhatsApp</button>
      <button style={{ padding: "8px 16px", background: "transparent", color: "var(--ink-3)", border: "none", borderRadius: 7, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>✉️ Email</button>
    </div>

    <Field label="No. WhatsApp" placeholder="08xx-xxxx-xxxx" icon={<Icons.Phone size={16} />} />

    <button className="btn btn-primary" style={{ width: "100%", justifyContent: "center", padding: "14px 20px", fontSize: 15, marginTop: 8 }}>Kirim kode 6 digit <Icons.Arrow size={16} /></button>

    {/* Step indicator */}
    <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 36 }}>
      {[
        { n: 1, label: "Identitas", done: true, active: true },
        { n: 2, label: "Kode OTP", done: false, active: false },
        { n: 3, label: "Password baru", done: false, active: false },
      ].map((s, i, arr) => (
        <React.Fragment key={s.n}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 26, height: 26, borderRadius: 99, background: s.active ? "var(--ink)" : "white", color: s.active ? "white" : "var(--ink-4)", border: s.active ? "none" : "1px solid var(--line)", display: "grid", placeItems: "center", fontSize: 12, fontWeight: 700 }}>{s.n}</div>
            <span style={{ fontSize: 13, fontWeight: 600, color: s.active ? "var(--ink)" : "var(--ink-4)" }}>{s.label}</span>
          </div>
          {i < arr.length - 1 && <div style={{ flex: 1, height: 1, background: "var(--line)" }} />}
        </React.Fragment>
      ))}
    </div>
  </AuthShell>
);

Object.assign(window, { LoginPage, SignupPage, ResetPasswordPage });
