// Financial pages — Laporan Keuangan, Pendapatan, Harga TBS

const LaporanPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="laporan" />
    <div style={{ padding: "28px 28px 36px" }}>
      <PageHeader
        eyebrow="Laporan"
        title="Laporan Keuangan"
        sub="Pendapatan, biaya, dan laba bersih per kebun — siap diunduh sebagai PDF atau Excel untuk koperasi, bank, atau pajak."
        right={
          <>
            <button className="btn btn-ghost"><Icons.Calendar size={14} /> Jan – Mei 2026</button>
            <button className="btn btn-ghost"><Icons.Share size={14} /> Kirim email</button>
            <button className="btn btn-ghost"><Icons.Download size={14} /> Unduh Excel</button>
            <button className="btn btn-primary"><Icons.Download size={14} stroke="white" /> Unduh PDF</button>
          </>
        }
      />

      {/* Period selector + KPI */}
      <div className="card" style={{ padding: 24, marginBottom: 16, background: "linear-gradient(120deg, var(--ink) 0%, #18302a 100%)", color: "white", border: "none", overflow: "hidden", position: "relative" }}>
        <div style={{ position: "absolute", right: -60, top: -60, opacity: 0.08, color: "white" }}><SHLogo size={340} mono /></div>
        <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr", gap: 32, position: "relative" }}>
          <div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase" }}>Periode laporan</div>
            <div className="display" style={{ fontSize: 28, fontWeight: 700, marginTop: 4, letterSpacing: "-0.02em" }}>Januari – Mei 2026</div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", marginTop: 4 }}>5 bulan · 6 kebun · 58 panen tercatat</div>
            <div style={{ display: "inline-flex", marginTop: 16, padding: 4, background: "rgba(255,255,255,0.06)", borderRadius: 10 }}>
              {["Bulan", "Kuartal", "Tahun", "Kustom"].map((t, i) => (
                <button key={t} style={{ padding: "7px 14px", background: i === 0 ? "white" : "transparent", color: i === 0 ? "var(--ink)" : "rgba(255,255,255,0.7)", border: "none", borderRadius: 7, fontSize: 12, fontWeight: 600 }}>{t}</button>
              ))}
            </div>
          </div>
          {[
            { l: "Pendapatan", v: "Rp 482,4 jt", d: "↑ 18,2%", c: "var(--c1)" },
            { l: "Biaya", v: "Rp 228,6 jt", d: "↑ 4,8%", c: "var(--c2)" },
            { l: "Laba bersih", v: "Rp 253,8 jt", d: "↑ 32,1%", c: "var(--terra)" },
          ].map((s) => (
            <div key={s.l}>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase" }}>{s.l}</div>
              <div className="num" style={{ fontSize: 32, fontWeight: 700, marginTop: 4, color: "white", letterSpacing: "-0.02em" }}>{s.v}</div>
              <div style={{ display: "inline-block", marginTop: 6, padding: "2px 8px", background: s.c, color: "white", borderRadius: 99, fontSize: 11, fontWeight: 700 }}>{s.d}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Main chart */}
      <div className="card" style={{ padding: 24, marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
          <div>
            <div className="eyebrow">Tren bulanan</div>
            <h3 className="display" style={{ fontSize: 22, fontWeight: 700, margin: "4px 0 0" }}>Pendapatan, biaya & laba bersih</h3>
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            {[
              ["Pendapatan", "var(--c1)"],
              ["Biaya", "var(--c2)"],
              ["Laba bersih", "var(--terra)"],
            ].map(([n, c]) => (
              <span key={n} style={{ fontSize: 12, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 6, color: "var(--ink-2)" }}>
                <span style={{ width: 10, height: 10, background: c, borderRadius: 2 }} />{n}
              </span>
            ))}
          </div>
        </div>
        <MultiArea
          series={[
            { name: "Pendapatan", data: [62, 78, 92, 108, 142] },
            { name: "Biaya", data: [38, 42, 48, 52, 48] },
            { name: "Laba", data: [24, 36, 44, 56, 94] },
          ]}
          width={1340}
          height={260}
          palette={["var(--c1)", "var(--c2)", "var(--terra)"]}
        />
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, padding: "0 12px" }}>
          {["Januari", "Februari", "Maret", "April", "Mei"].map((m) => (
            <span key={m} style={{ fontSize: 12, color: "var(--ink-4)", fontWeight: 600 }}>{m}</span>
          ))}
        </div>
      </div>

      {/* Breakdown table + revenue sources */}
      <div style={{ display: "grid", gridTemplateColumns: "1.7fr 1fr", gap: 16 }}>
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ padding: "20px 24px", borderBottom: "1px solid var(--line)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div className="eyebrow">Rincian per kebun</div>
              <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 0" }}>Performa setiap blok</h3>
            </div>
            <button className="btn btn-ghost" style={{ fontSize: 12 }}><Icons.Filter size={12} /> Urutkan: Laba ↓</button>
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ fontSize: 11, color: "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.08em", background: "var(--paper)" }}>
                <th style={{ textAlign: "left", padding: "10px 24px", fontWeight: 600 }}>Kebun</th>
                <th style={{ textAlign: "right", padding: "10px 0", fontWeight: 600 }}>Hasil</th>
                <th style={{ textAlign: "right", padding: "10px 0", fontWeight: 600 }}>Pendapatan</th>
                <th style={{ textAlign: "right", padding: "10px 0", fontWeight: 600 }}>Biaya</th>
                <th style={{ textAlign: "right", padding: "10px 0", fontWeight: 600 }}>Laba bersih</th>
                <th style={{ textAlign: "right", padding: "10px 24px", fontWeight: 600 }}>Margin</th>
              </tr>
            </thead>
            <tbody>
              {[
                { n: "Suka Maju · A", t: "12,8 t", p: "Rp 124jt", b: "Rp 48jt", l: "Rp 76jt", m: 61, c: "var(--c1)" },
                { n: "Sumber Sari", t: "10,2 t", p: "Rp 96jt", b: "Rp 42jt", l: "Rp 54jt", m: 56, c: "var(--c4)" },
                { n: "Maju Jaya · B", t: "8,6 t", p: "Rp 82jt", b: "Rp 38jt", l: "Rp 44jt", m: 54, c: "var(--c2)" },
                { n: "Sawit Lestari", t: "7,2 t", p: "Rp 68jt", b: "Rp 32jt", l: "Rp 36jt", m: 53, c: "var(--c6)" },
                { n: "Tani Makmur", t: "5,4 t", p: "Rp 52jt", b: "Rp 38jt", l: "Rp 14jt", m: 27, c: "var(--c5)" },
                { n: "Harapan Baru", t: "—", p: "—", b: "Rp 8jt", l: "−Rp 8jt", m: 0, c: "var(--c3)" },
              ].map((r, i) => (
                <tr key={i} style={{ fontSize: 13, borderTop: "1px solid var(--line)" }}>
                  <td style={{ padding: "14px 24px", display: "flex", alignItems: "center", gap: 10, fontWeight: 600 }}>
                    <span style={{ width: 10, height: 10, borderRadius: 2, background: r.c }} />
                    {r.n}
                  </td>
                  <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)", color: "var(--ink-3)" }}>{r.t}</td>
                  <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)", color: "var(--emerald-2)", fontWeight: 600 }}>{r.p}</td>
                  <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)", color: "var(--terra-2)" }}>{r.b}</td>
                  <td style={{ padding: "14px 0", textAlign: "right", fontWeight: 700 }} className="num">{r.l}</td>
                  <td style={{ padding: "14px 24px", textAlign: "right" }}>
                    <div style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
                      <div style={{ width: 56, height: 6, background: "var(--paper-2)", borderRadius: 99, overflow: "hidden" }}>
                        <div style={{ width: `${r.m}%`, height: "100%", background: r.c }} />
                      </div>
                      <span className="num" style={{ fontWeight: 700, fontSize: 12 }}>{r.m}%</span>
                    </div>
                  </td>
                </tr>
              ))}
              <tr style={{ fontSize: 13, borderTop: "2px solid var(--ink)", background: "var(--paper)" }}>
                <td style={{ padding: "14px 24px", fontWeight: 800 }}>Total</td>
                <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)", fontWeight: 800 }}>44,2 t</td>
                <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)", color: "var(--emerald-2)", fontWeight: 800 }}>Rp 482,4jt</td>
                <td style={{ padding: "14px 0", textAlign: "right", fontFamily: "var(--font-mono)", color: "var(--terra-2)", fontWeight: 800 }}>Rp 228,6jt</td>
                <td style={{ padding: "14px 0", textAlign: "right", fontWeight: 800 }} className="num">Rp 253,8jt</td>
                <td style={{ padding: "14px 24px", textAlign: "right", fontWeight: 800 }} className="num">52,6%</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Right column: composition + export */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card" style={{ padding: 24 }}>
            <div className="eyebrow">Komposisi pendapatan</div>
            <h3 className="display" style={{ fontSize: 18, fontWeight: 700, margin: "4px 0 16px" }}>Per sumber</h3>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <Donut value={0.86} size={120} stroke={12} color="var(--c1)" track="var(--paper-2)" label={<><div className="num" style={{ fontSize: 22, fontWeight: 700 }}>86%</div><div style={{ fontSize: 11, color: "var(--ink-4)" }}>TBS</div></>} />
              <div style={{ display: "flex", flexDirection: "column", gap: 8, flex: 1 }}>
                {[
                  ["Penjualan TBS", "86%", "var(--c1)"],
                  ["Subsidi PSR", "9%", "var(--c2)"],
                  ["Lain-lain", "5%", "var(--c4)"],
                ].map(([n, v, c]) => (
                  <div key={n} style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                    <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: c }} />{n}</span>
                    <span className="num" style={{ fontWeight: 700 }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="card" style={{ padding: 24 }}>
            <div className="eyebrow">Unduh laporan</div>
            <h3 className="display" style={{ fontSize: 18, fontWeight: 700, margin: "4px 0 14px" }}>Ekspor</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {[
                { f: "PDF Lengkap", s: "Cocok untuk koperasi & bank", icon: Icons.Download, c: "var(--c2)" },
                { f: "Excel Detail", s: "Pivot per kebun & bulan", icon: Icons.Download, c: "var(--c1)" },
                { f: "Kirim via Email", s: "Otomatis tiap bulan", icon: Icons.Mail, c: "var(--c4)" },
                { f: "Bagikan link", s: "Tautan baca-saja 7 hari", icon: Icons.Share, c: "var(--c5)" },
              ].map((d) => {
                const I = d.icon;
                return (
                  <div key={d.f} style={{ display: "flex", alignItems: "center", gap: 12, padding: 12, borderRadius: 12, border: "1px solid var(--line)", cursor: "pointer" }}>
                    <div style={{ width: 32, height: 32, borderRadius: 8, background: d.c, color: "white", display: "grid", placeItems: "center" }}><I size={14} stroke="white" /></div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 700 }}>{d.f}</div>
                      <div style={{ fontSize: 11, color: "var(--ink-4)" }}>{d.s}</div>
                    </div>
                    <Icons.Arrow size={14} stroke="var(--ink-4)" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const PendapatanPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="keuangan" />
    <div style={{ padding: "28px 28px 36px" }}>
      <PageHeader
        eyebrow="Keuangan"
        title="Pendapatan Lain"
        sub="Catat pendapatan di luar penjualan TBS — subsidi, hibah, penjualan brondolan, atau pendapatan sampingan."
        right={<button className="btn btn-emerald"><Icons.Plus size={14} stroke="white" /> Catat Pendapatan</button>}
      />

      {/* Tabs */}
      <div style={{ display: "inline-flex", padding: 4, background: "white", border: "1px solid var(--line)", borderRadius: 12, marginBottom: 20 }}>
        {[
          { l: "Semua", n: 24, active: true },
          { l: "Subsidi PSR", n: 6 },
          { l: "Brondolan", n: 12 },
          { l: "Penjualan bibit", n: 4 },
          { l: "Lain-lain", n: 2 },
        ].map((t, i) => (
          <button key={i} style={{ padding: "8px 14px", background: t.active ? "var(--ink)" : "transparent", color: t.active ? "white" : "var(--ink-2)", border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 6 }}>
            {t.l} <span style={{ fontSize: 11, padding: "1px 7px", background: t.active ? "rgba(255,255,255,0.18)" : "var(--paper-2)", borderRadius: 99 }}>{t.n}</span>
          </button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 16 }}>
        <KPICard label="Total pendapatan lain" value="Rp 38,4 jt" sub="Jan – Mei 2026" delta="↑ 9,2%" accent="var(--c1)" chart={<AreaChart data={[3, 6, 5, 8, 9, 12, 14]} width={300} height={56} showGrid={false} padding={0} stroke="var(--c1)" fill="rgba(10,120,71,0.18)" />} />
        <KPICard label="Subsidi diterima" value="Rp 22,8 jt" sub="6 pencairan PSR" delta="59%" accent="var(--c2)" chart={<AreaChart data={[2, 4, 4, 6, 6, 8, 10]} width={300} height={56} showGrid={false} padding={0} stroke="var(--c2)" fill="rgba(217,106,44,0.18)" />} />
        <KPICard label="Brondolan & lain" value="Rp 15,6 jt" sub="catatan harian" delta="41%" accent="var(--c4)" chart={<AreaChart data={[1, 2, 3, 3, 4, 5, 7]} width={300} height={56} showGrid={false} padding={0} stroke="var(--c4)" fill="rgba(28,142,138,0.18)" />} />
      </div>

      {/* List */}
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ fontSize: 11, color: "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.08em", background: "var(--paper)" }}>
              <th style={{ textAlign: "left", padding: "12px 24px", fontWeight: 600 }}>Tanggal</th>
              <th style={{ textAlign: "left", padding: "12px 0", fontWeight: 600 }}>Sumber</th>
              <th style={{ textAlign: "left", padding: "12px 0", fontWeight: 600 }}>Kategori</th>
              <th style={{ textAlign: "left", padding: "12px 0", fontWeight: 600 }}>Kebun</th>
              <th style={{ textAlign: "right", padding: "12px 0", fontWeight: 600 }}>Jumlah</th>
              <th style={{ textAlign: "right", padding: "12px 24px", fontWeight: 600 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["08 Mei 2026", "Dinas Perkebunan Riau", "Subsidi PSR", "Suka Maju · A", "Rp 8.400.000", "var(--c2)", "Diterima", "chip-emerald"],
              ["02 Mei 2026", "Pengepul Mitra Tani", "Brondolan", "Maju Jaya · B", "Rp 1.240.000", "var(--c4)", "Diterima", "chip-emerald"],
              ["28 Apr 2026", "Pengepul Mitra Tani", "Brondolan", "Sumber Sari", "Rp 980.000", "var(--c4)", "Diterima", "chip-emerald"],
              ["20 Apr 2026", "Kementan", "Hibah pupuk", "Multi", "Rp 12.000.000", "var(--c5)", "Proses", "chip-warn"],
              ["10 Apr 2026", "Koperasi Sawit Lestari", "Dividen SHU", "—", "Rp 2.400.000", "var(--c1)", "Diterima", "chip-emerald"],
            ].map((r, i) => (
              <tr key={i} style={{ fontSize: 13, borderTop: "1px solid var(--line)" }}>
                <td style={{ padding: "14px 24px", fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--ink-3)" }}>{r[0]}</td>
                <td style={{ padding: "14px 0", fontWeight: 600 }}>{r[1]}</td>
                <td style={{ padding: "14px 0" }}><span className="chip" style={{ background: r[5], color: "white", border: "none", fontSize: 11 }}>{r[2]}</span></td>
                <td style={{ padding: "14px 0", color: "var(--ink-3)" }}>{r[3]}</td>
                <td style={{ padding: "14px 0", textAlign: "right", fontWeight: 700 }} className="num">{r[4]}</td>
                <td style={{ padding: "14px 24px", textAlign: "right" }}><span className={`chip ${r[7]}`} style={{ fontSize: 11 }}>{r[6]}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

const HargaTbsPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="keuangan" />
    <div style={{ padding: "28px 28px 36px" }}>
      <PageHeader
        eyebrow="Harga"
        title="Harga TBS Hari Ini"
        sub="Pantau harga Tandan Buah Segar di Riau dan sekitarnya. Data dikumpulkan dari Disbun provinsi, pengepul, dan pabrik resmi."
        right={
          <>
            <button className="btn btn-ghost"><Icons.Bell size={14} /> Atur alert</button>
            <button className="btn btn-ghost"><Icons.Share size={14} /> Bagikan</button>
          </>
        }
      />

      {/* Big hero card with today's price */}
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16, marginBottom: 16 }}>
        <div className="card" style={{ padding: 32, background: "linear-gradient(135deg, var(--emerald) 0%, var(--emerald-2) 100%)", color: "white", border: "none", position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", right: -40, bottom: -40, opacity: 0.1, color: "white" }}><SHLogo size={280} mono /></div>
          <div style={{ position: "relative" }}>
            <div className="eyebrow" style={{ color: "rgba(255,255,255,0.6)" }}>Senin, 14 Mei 2026 · 09:42 WIB</div>
            <div style={{ marginTop: 16 }}>
              <span className="num" style={{ fontSize: 88, fontWeight: 800, letterSpacing: "-0.04em", lineHeight: 1 }}>2.340</span>
              <span style={{ fontSize: 20, marginLeft: 6, opacity: 0.7 }}>Rp/kg</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 16 }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 12px", background: "var(--terra)", borderRadius: 99, fontSize: 13, fontWeight: 700 }}>↑ Rp 95 (4,2%)</span>
              <span style={{ fontSize: 13, opacity: 0.7 }}>vs kemarin · Rp 2.245/kg</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20, marginTop: 28, paddingTop: 24, borderTop: "1px solid rgba(255,255,255,0.15)" }}>
              {[
                ["7 hari", "Rp 2.218", "↑ 5,5%"],
                ["30 hari", "Rp 2.156", "↑ 8,5%"],
                ["1 tahun", "Rp 1.984", "↑ 17,9%"],
              ].map(([l, v, d]) => (
                <div key={l}>
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>{l} avg</div>
                  <div className="num" style={{ fontSize: 22, fontWeight: 700, marginTop: 4 }}>{v}</div>
                  <div style={{ fontSize: 11, color: "var(--terra)", fontWeight: 700 }}>{d}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="card" style={{ padding: 24 }}>
          <div className="eyebrow">Per kelas umur tanaman</div>
          <h3 className="display" style={{ fontSize: 18, fontWeight: 700, margin: "4px 0 16px" }}>Harga PKS Riau</h3>
          {[
            ["TBS umur ≥ 10 tahun", "Rp 2.340", "Standar", "var(--c1)"],
            ["TBS umur 7 – 9 tahun", "Rp 2.290", "−2%", "var(--c4)"],
            ["TBS umur 4 – 6 tahun", "Rp 2.210", "−6%", "var(--c5)"],
            ["TBS umur 3 tahun", "Rp 2.085", "−11%", "var(--c2)"],
            ["Brondolan", "Rp 1.840", "−21%", "var(--c3)"],
          ].map(([l, v, d, c]) => (
            <div key={l} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 0", borderBottom: "1px solid var(--line)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: c }} />
                <span style={{ fontSize: 13, fontWeight: 600 }}>{l}</span>
              </div>
              <div style={{ textAlign: "right" }}>
                <div className="num" style={{ fontSize: 15, fontWeight: 700 }}>{v}</div>
                <div style={{ fontSize: 11, color: "var(--ink-4)" }}>{d}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* History chart + sources */}
      <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 16 }}>
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
            <div>
              <div className="eyebrow">Riwayat harga</div>
              <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 0" }}>12 bulan terakhir</h3>
            </div>
            <div style={{ display: "inline-flex", padding: 4, background: "var(--paper)", borderRadius: 10 }}>
              {["7H", "1B", "3B", "6B", "1T", "Semua"].map((t, i) => (
                <button key={t} style={{ padding: "6px 12px", background: i === 4 ? "white" : "transparent", color: "var(--ink)", border: i === 4 ? "1px solid var(--line)" : "none", borderRadius: 7, fontSize: 12, fontWeight: 600 }}>{t}</button>
              ))}
            </div>
          </div>
          <AreaChart data={[1980, 2020, 2050, 2120, 2080, 2150, 2180, 2220, 2200, 2250, 2280, 2340]} width={840} height={240} stroke="var(--emerald)" fill="rgba(10,120,71,0.16)" />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            {["Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des", "Jan", "Feb", "Mar", "Apr", "Mei"].map((m) => (
              <span key={m} style={{ fontSize: 11, color: "var(--ink-4)", fontFamily: "var(--font-mono)" }}>{m}</span>
            ))}
          </div>
        </div>

        <div className="card" style={{ padding: 24 }}>
          <div className="eyebrow">Sumber data</div>
          <h3 className="display" style={{ fontSize: 18, fontWeight: 700, margin: "4px 0 16px" }}>Pengepul & pabrik</h3>
          {[
            ["Disbun Riau (resmi)", "Rp 2.340", "9 menit lalu", "var(--c1)"],
            ["PKS Sawit Mas", "Rp 2.310", "1 jam lalu", "var(--c4)"],
            ["KopSawit Tanjung Jabung", "Rp 2.295", "2 jam lalu", "var(--c5)"],
            ["Pengepul Mitra Tani", "Rp 2.280", "3 jam lalu", "var(--c2)"],
            ["PKS Bumi Lestari", "Rp 2.260", "5 jam lalu", "var(--c6)"],
          ].map(([n, v, t, c]) => (
            <div key={n} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 0", borderBottom: "1px solid var(--line)" }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{n}</div>
                <div style={{ fontSize: 11, color: "var(--ink-4)" }}>{t}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div className="num" style={{ fontSize: 15, fontWeight: 700, color: c }}>{v}</div>
                <div style={{ fontSize: 11, color: "var(--ink-4)" }}>/kg</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

Object.assign(window, { LaporanPage, PendapatanPage, HargaTbsPage });
