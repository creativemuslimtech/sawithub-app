// Tools — Jadwal Perawatan, Kalkulator Pupuk

const JadwalPage = () => {
  // build a 5-week mini grid (35 days)
  const days = [];
  for (let i = 0; i < 35; i++) days.push(i + 1);
  // mark events by day index
  const events = {
    2: [{ k: "pupuk", l: "NPK Blok A" }],
    5: [{ k: "semprot", l: "Round-up Blok B" }],
    7: [{ k: "pruning", l: "Pelepah tua Blok C" }],
    11: [{ k: "pupuk", l: "Urea + KCl Blok A" }, { k: "weeding", l: "Piringan Blok B" }],
    14: [{ k: "semprot", l: "Insektisida Blok D" }],
    17: [{ k: "pupuk", l: "NPK 12-12-27 multi" }],
    20: [{ k: "pruning", l: "Pelepah Blok A" }],
    23: [{ k: "weeding", l: "Jalan panen Blok B" }],
    25: [{ k: "pupuk", l: "NPK kuartal 2" }, { k: "semprot", l: "Round-up Blok C" }],
    28: [{ k: "pruning", l: "Sanitasi tandan busuk" }],
    31: [{ k: "weeding", l: "Piringan multi" }],
  };
  const eventColors = { pupuk: "var(--c1)", semprot: "var(--c3)", pruning: "var(--c5)", weeding: "var(--c6)" };

  return (
    <div className="pg-app" style={{ width: 1440 }}>
      <AppTopNav active="jadwal" />
      <div style={{ padding: "28px 28px 36px" }}>
        <PageHeader
          eyebrow="Jadwal"
          title="Kalender Perawatan"
          sub="Atur jadwal pupuk 3 bulanan, semprot bulanan, pruning 6 bulanan, dan jadwal kerja lain. Pengingat dikirim lewat WhatsApp 1 hari sebelumnya."
          right={
            <>
              <button className="btn btn-ghost"><Icons.Filter size={14} /> Semua jenis</button>
              <button className="btn btn-ghost"><Icons.Calendar size={14} /> Mei 2026</button>
              <button className="btn btn-primary"><Icons.Plus size={14} stroke="white" /> Buat Jadwal</button>
            </>
          }
        />

        {/* Preset rotations */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 20 }}>
          {[
            { l: "Pemupukan 3 bulanan", n: "Rotasi NPK 12-12-27", c: "var(--c1)", icon: Icons.Drop, next: "20 Mei (6 hari lagi)" },
            { l: "Semprot rumput bulanan", n: "Round-up + ajuvan", c: "var(--c3)", icon: Icons.Sparkle, next: "18 Mei (4 hari lagi)" },
            { l: "Pruning 6 bulanan", n: "Pelepah tua + sanitasi", c: "var(--c5)", icon: Icons.Leaf, next: "07 Jun (24 hari lagi)" },
            { l: "Weeding piringan", n: "Manual + cangkul", c: "var(--c6)", icon: Icons.Drop, next: "16 Mei (besok)" },
          ].map((p, i) => {
            const I = p.icon;
            return (
              <div key={i} className="card" style={{ padding: 18 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
                  <div style={{ width: 34, height: 34, borderRadius: 10, background: p.c, color: "white", display: "grid", placeItems: "center" }}><I size={16} stroke="white" /></div>
                  <div className="eyebrow">{p.l}</div>
                </div>
                <div className="display" style={{ fontSize: 16, fontWeight: 700, letterSpacing: "-0.015em" }}>{p.n}</div>
                <div style={{ fontSize: 12, color: "var(--ink-3)", marginTop: 8 }}>Jadwal terdekat: <strong style={{ color: "var(--ink)" }}>{p.next}</strong></div>
              </div>
            );
          })}
        </div>

        {/* Calendar + upcoming list */}
        <div style={{ display: "grid", gridTemplateColumns: "2.2fr 1fr", gap: 16 }}>
          <div className="card" style={{ padding: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <h3 className="display" style={{ fontSize: 24, fontWeight: 700, margin: 0, letterSpacing: "-0.02em" }}>Mei 2026</h3>
                <div style={{ display: "flex", gap: 4 }}>
                  <button className="btn btn-ghost" style={{ padding: 6, borderRadius: 8 }}><Icons.Arrow size={14} stroke="var(--ink-3)" /></button>
                  <button className="btn btn-ghost" style={{ padding: 6, borderRadius: 8, transform: "rotate(180deg)" }}><Icons.Arrow size={14} stroke="var(--ink-3)" /></button>
                </div>
              </div>
              <div style={{ display: "flex", gap: 10 }}>
                {[["Pupuk", "var(--c1)"], ["Semprot", "var(--c3)"], ["Pruning", "var(--c5)"], ["Weeding", "var(--c6)"]].map(([n, c]) => (
                  <span key={n} style={{ fontSize: 11, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 5, color: "var(--ink-3)" }}>
                    <span style={{ width: 8, height: 8, background: c, borderRadius: 2 }} />{n}
                  </span>
                ))}
              </div>
            </div>

            {/* Day headers */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 6, marginBottom: 8 }}>
              {["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"].map((d, i) => (
                <div key={d} style={{ fontSize: 11, fontWeight: 600, color: i >= 5 ? "var(--terra-2)" : "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.08em", padding: "6px 4px" }}>{d}</div>
              ))}
            </div>

            {/* Days grid */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 6 }}>
              {days.map((d) => {
                const ev = events[d] || [];
                const isToday = d === 14;
                return (
                  <div key={d} style={{ minHeight: 86, border: "1px solid var(--line)", borderRadius: 10, padding: 8, background: isToday ? "var(--emerald-soft)" : "white", position: "relative" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                      <span className="num" style={{ fontSize: 13, fontWeight: 700, color: isToday ? "var(--emerald-2)" : "var(--ink)" }}>{d > 30 ? d - 30 : d}</span>
                      {isToday && <span style={{ fontSize: 9, fontWeight: 700, color: "white", background: "var(--emerald)", padding: "1px 5px", borderRadius: 99, letterSpacing: "0.06em" }}>HARI INI</span>}
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                      {ev.map((e, i) => (
                        <div key={i} style={{ fontSize: 10, fontWeight: 600, padding: "2px 5px", borderRadius: 5, background: eventColors[e.k], color: "white", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{e.l}</div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Upcoming */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div className="card" style={{ padding: 24 }}>
              <div className="eyebrow">Akan datang</div>
              <h3 className="display" style={{ fontSize: 18, fontWeight: 700, margin: "4px 0 14px" }}>7 jadwal terdekat</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {[
                  { day: "16", mo: "MEI", l: "BSK", title: "Weeding Blok B", meta: "1,2 ha · Tim C (4 org)", c: "var(--c6)" },
                  { day: "18", mo: "MEI", l: "JUM", title: "Semprot rumput Blok B", meta: "Round-up 8L · Tim B", c: "var(--c3)" },
                  { day: "20", mo: "MEI", l: "MIN", title: "Pemupukan NPK Blok A", meta: "240 pohon · Pak Hadi", c: "var(--c1)" },
                  { day: "23", mo: "MEI", l: "RAB", title: "Weeding jalan Blok B", meta: "Tim C (3 org)", c: "var(--c6)" },
                  { day: "07", mo: "JUN", l: "MIN", title: "Pruning pelepah Blok A", meta: "180 pohon · Tim A", c: "var(--c5)" },
                ].map((j, i) => (
                  <div key={i} style={{ display: "flex", gap: 12, padding: "10px 12px", borderRadius: 12, border: "1px solid var(--line)", background: "white" }}>
                    <div style={{ width: 44, textAlign: "center", padding: "4px 0", borderRadius: 8, background: j.c, color: "white", flexShrink: 0 }}>
                      <div className="num" style={{ fontSize: 18, fontWeight: 800, lineHeight: 1 }}>{j.day}</div>
                      <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.08em", marginTop: 2 }}>{j.mo}</div>
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 700 }}>{j.title}</div>
                      <div style={{ fontSize: 11.5, color: "var(--ink-4)", marginTop: 2 }}>{j.meta}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="card" style={{ padding: 20, background: "var(--ink)", color: "white", border: "none" }}>
              <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: "var(--terra)", display: "grid", placeItems: "center", flexShrink: 0 }}><Icons.Phone size={16} stroke="white" /></div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "white" }}>Pengingat WhatsApp aktif</div>
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", marginTop: 4, lineHeight: 1.5 }}>
                    Kamu akan diingatkan 1 hari sebelum jadwal kerja, di nomor <strong style={{ color: "white" }}>0852-1234-5678</strong>.
                  </div>
                  <a style={{ fontSize: 12, color: "var(--terra)", fontWeight: 700, marginTop: 8, display: "inline-flex", gap: 4 }}>Atur preferensi →</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const KalkulatorPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="kalkulator" />
    <div style={{ padding: "28px 28px 36px" }}>
      <PageHeader
        eyebrow="Tools"
        title="Kalkulator Pupuk"
        sub="Hitung kebutuhan pupuk berdasarkan umur tanaman, jumlah pohon, kadar NPK tanah, dan jenis pupuk. Hasil dapat disimpan ke catatan perawatan."
        right={
          <>
            <button className="btn btn-ghost"><Icons.Download size={14} /> Simpan hasil</button>
            <button className="btn btn-primary"><Icons.Plus size={14} stroke="white" /> Buat jadwal pupuk</button>
          </>
        }
      />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 16 }}>
        {/* Input form */}
        <div className="card" style={{ padding: 28 }}>
          <div className="eyebrow">Input data</div>
          <h3 className="display" style={{ fontSize: 22, fontWeight: 700, margin: "4px 0 22px" }}>Profil kebun &amp; tanah</h3>

          {/* Auto-fill from kebun */}
          <div style={{ background: "var(--emerald-soft)", border: "1px solid rgba(10,120,71,0.18)", borderRadius: 12, padding: 12, display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
            <Icons.Sparkle size={16} stroke="var(--emerald-2)" />
            <div style={{ flex: 1, fontSize: 13 }}>Pilih kebun untuk auto-isi umur tanaman & jumlah pohon</div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 12px", background: "white", borderRadius: 8, fontSize: 13, fontWeight: 600 }}>
              <span style={{ width: 8, height: 8, background: "var(--c1)", borderRadius: 99 }} />Suka Maju · A
              <Icons.Down size={12} />
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            {[
              ["Umur tanaman", "8", "tahun"],
              ["Jumlah pohon", "480", "pohon"],
            ].map(([l, v, u]) => (
              <div key={l}>
                <div style={{ fontSize: 12, color: "var(--ink-3)", marginBottom: 5, fontWeight: 600 }}>{l}</div>
                <div style={{ display: "flex", alignItems: "center", border: "1px solid var(--line)", borderRadius: 10, background: "white" }}>
                  <input defaultValue={v} className="num" style={{ flex: 1, padding: "11px 12px", border: "none", outline: "none", fontSize: 15, fontWeight: 700, background: "transparent" }} />
                  <span style={{ padding: "0 12px", fontSize: 11, color: "var(--ink-4)", fontWeight: 600 }}>{u}</span>
                </div>
              </div>
            ))}
          </div>

          {/* NPK levels with visual sliders */}
          <div style={{ marginTop: 22 }}>
            <div className="eyebrow" style={{ marginBottom: 12 }}>Kadar tanah (hasil uji)</div>
            {[
              { label: "Nitrogen (N)", val: 0.18, level: "rendah", color: "var(--c2)", scale: "0,1 – 0,3%" },
              { label: "Fosfor (P)", val: 12, level: "sedang", color: "var(--c1)", scale: "5 – 20 ppm" },
              { label: "Kalium (K)", val: 0.34, level: "tinggi", color: "var(--c4)", scale: "0,2 – 0,5 me/100g" },
            ].map((n) => (
              <div key={n.label} style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{n.label}</span>
                  <span style={{ fontSize: 12 }}>
                    <span className="num" style={{ fontWeight: 700 }}>{n.val}</span>
                    <span className={`chip ${n.level === "rendah" ? "chip-warn" : n.level === "sedang" ? "chip-emerald" : "chip-terra"}`} style={{ marginLeft: 8, fontSize: 10, padding: "2px 7px" }}>{n.level}</span>
                  </span>
                </div>
                <div style={{ position: "relative", height: 8, background: "var(--paper-2)", borderRadius: 99, overflow: "hidden" }}>
                  <div style={{ width: `${(n.level === "rendah" ? 0.2 : n.level === "sedang" ? 0.5 : 0.85) * 100}%`, height: "100%", background: n.color, borderRadius: 99 }} />
                </div>
                <div style={{ fontSize: 10.5, color: "var(--ink-4)", marginTop: 4, fontFamily: "var(--font-mono)" }}>Skala referensi: {n.scale}</div>
              </div>
            ))}
          </div>

          {/* Fertilizer selection */}
          <div style={{ marginTop: 20 }}>
            <div className="eyebrow" style={{ marginBottom: 10 }}>Jenis pupuk</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {[
                ["NPK 12-12-27", true],
                ["NPK 15-15-15", false],
                ["Urea + KCl", false],
                ["Pupuk organik", false],
              ].map(([n, active]) => (
                <div key={n} style={{ padding: "10px 12px", border: active ? "1.5px solid var(--emerald-2)" : "1px solid var(--line)", borderRadius: 10, background: active ? "var(--emerald-soft)" : "white", display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 16, height: 16, borderRadius: 99, border: active ? "5px solid var(--emerald)" : "2px solid var(--line)" }} />
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{n}</span>
                </div>
              ))}
            </div>
          </div>

          <div style={{ marginTop: 20 }}>
            <div style={{ fontSize: 12, color: "var(--ink-3)", marginBottom: 6, fontWeight: 600 }}>Periode pemupukan</div>
            <div style={{ display: "flex", gap: 6 }}>
              {["1 bulan", "2 bulan", "3 bulan", "4 bulan", "6 bulan"].map((p, i) => (
                <button key={p} style={{ padding: "8px 14px", borderRadius: 8, background: i === 2 ? "var(--ink)" : "white", color: i === 2 ? "white" : "var(--ink-2)", border: i === 2 ? "1px solid var(--ink)" : "1px solid var(--line)", fontSize: 12, fontWeight: 600, flex: 1 }}>{p}</button>
              ))}
            </div>
          </div>

          <button className="btn btn-emerald" style={{ width: "100%", justifyContent: "center", marginTop: 24, padding: "14px 18px", fontSize: 15 }}>Hitung dosis pupuk <Icons.Arrow size={16} stroke="white" /></button>
        </div>

        {/* Result */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Main result */}
          <div className="card" style={{ padding: 28, background: "linear-gradient(140deg, var(--ink) 0%, #14241c 100%)", color: "white", border: "none", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", right: -40, top: -40, opacity: 0.08, color: "white" }}><SHLogo size={240} mono /></div>
            <div style={{ position: "relative" }}>
              <div className="eyebrow" style={{ color: "rgba(255,255,255,0.5)" }}>Hasil perhitungan · NPK 12-12-27</div>
              <h3 className="display" style={{ fontSize: 26, fontWeight: 700, margin: "6px 0 24px", color: "white" }}>Dosis Pupuk Direkomendasikan</h3>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 18, marginBottom: 24 }}>
                {[
                  { l: "Per pohon / periode", v: "1,8", u: "kg", c: "var(--terra)" },
                  { l: "Total per periode", v: "864", u: "kg", c: "var(--c1)" },
                  { l: "Total per tahun", v: "3,46", u: "ton", c: "var(--c3)" },
                ].map((r, i) => (
                  <div key={i} style={{ paddingTop: 16, borderTop: "1px solid rgba(255,255,255,0.12)" }}>
                    <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>{r.l}</div>
                    <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginTop: 8 }}>
                      <span className="num" style={{ fontSize: 40, fontWeight: 800, letterSpacing: "-0.03em", color: r.c }}>{r.v}</span>
                      <span style={{ fontSize: 14, color: "rgba(255,255,255,0.7)" }}>{r.u}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 14, padding: 16 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 11, color: "rgba(255,255,255,0.5)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                  <span>Komposisi Nutrisi</span>
                  <span>per kg pupuk</span>
                </div>
                <div style={{ display: "flex", gap: 12 }}>
                  {[["N", "120 g", "var(--c2)"], ["P", "120 g", "var(--c4)"], ["K", "270 g", "var(--c3)"]].map(([n, v, c]) => (
                    <div key={n} style={{ flex: 1, background: c, padding: "12px 14px", borderRadius: 10 }}>
                      <div style={{ fontSize: 11, fontWeight: 800, color: "white", opacity: 0.85 }}>{n}</div>
                      <div className="num" style={{ fontSize: 18, fontWeight: 800, color: "white" }}>{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Cost estimation */}
          <div className="card" style={{ padding: 24 }}>
            <div className="eyebrow">Perkiraan biaya</div>
            <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 16px" }}>Biaya pupuk satu rotasi</h3>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
              {[
                { l: "Harga / kg", v: "Rp 18.500", c: "var(--ink)" },
                { l: "Total / rotasi", v: "Rp 15,98 jt", c: "var(--c2)" },
                { l: "Total / tahun", v: "Rp 64,01 jt", c: "var(--c1)" },
              ].map((c, i) => (
                <div key={i} style={{ padding: 14, borderRadius: 12, background: "var(--paper)", border: "1px solid var(--line)" }}>
                  <div style={{ fontSize: 11, color: "var(--ink-4)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>{c.l}</div>
                  <div className="num" style={{ fontSize: 20, fontWeight: 700, color: c.c, marginTop: 4 }}>{c.v}</div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 14, padding: 12, background: "var(--terra-soft)", borderRadius: 10, fontSize: 12, color: "var(--ink-2)", lineHeight: 1.5 }}>
              <strong>Catatan:</strong> Perhitungan ini adalah <strong>estimasi awal</strong>. Sesuaikan dengan kondisi nyata dan saran agronom lapangan. Hasil dapat berbeda untuk tanah ekstrem (sangat asam, gambut dalam).
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

Object.assign(window, { JadwalPage, KalkulatorPage });
