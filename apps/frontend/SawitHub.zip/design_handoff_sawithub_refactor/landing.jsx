// Landing page — public marketing
const LandingHeader = () => (
  <header style={{ display: "flex", alignItems: "center", padding: "20px 56px", borderBottom: "1px solid var(--line)", position: "sticky", top: 0, background: "rgba(250,246,236,0.85)", backdropFilter: "blur(10px)", zIndex: 5 }}>
    <SHWordmark size={22} />
    <nav style={{ display: "flex", alignItems: "center", gap: 28, marginLeft: 56, flex: 1, fontSize: 14, fontWeight: 600, color: "var(--ink-2)" }}>
      <span>Fitur</span>
      <span>Untuk Petani</span>
      <span>Untuk Koperasi</span>
      <span>Harga</span>
      <span>Cerita</span>
      <span>Bantuan</span>
    </nav>
    <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
      <button className="btn btn-ghost">Masuk</button>
      <button className="btn btn-primary">Coba gratis 14 hari <Icons.Arrow size={14} /></button>
    </div>
  </header>
);

const LandingHero = () => (
  <section style={{ padding: "72px 56px 60px", position: "relative", overflow: "hidden" }}>
    {/* decorative palm fronds bg */}
    <div style={{ position: "absolute", right: -60, top: -40, opacity: 0.08, transform: "rotate(15deg)" }}>
      <SHLogo size={520} />
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1.15fr 1fr", gap: 56, alignItems: "center", position: "relative" }}>
      <div>
        <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 12px 6px 6px", border: "1px solid var(--line)", background: "white", borderRadius: 999, fontSize: 13, fontWeight: 600 }}>
          <span style={{ background: "var(--emerald-soft)", color: "var(--emerald-2)", padding: "2px 8px", borderRadius: 999, fontSize: 11, fontWeight: 700 }}>BARU</span>
          Kalkulator pupuk presisi · Versi 2026
        </div>
        <h1 className="display" style={{ fontSize: 72, lineHeight: 1.0, fontWeight: 700, letterSpacing: "-0.04em", margin: "20px 0 20px" }}>
          Hape kamu,<br />
          <span style={{ color: "var(--emerald)" }}>kantor kebun</span> kamu.
        </h1>
        <p style={{ fontSize: 18, lineHeight: 1.55, color: "var(--ink-3)", maxWidth: 540, margin: 0 }}>
          SawitHub bantu petani sawit catat panen, biaya rawat, harga TBS, dan jadwal kerja — sekali isi, hasilnya langsung jadi laporan keuangan yang rapi.
        </p>
        <div style={{ display: "flex", gap: 12, marginTop: 32, alignItems: "center" }}>
          <button className="btn btn-primary" style={{ padding: "14px 22px", fontSize: 15 }}>Mulai gratis 14 hari <Icons.Arrow size={16} /></button>
          <button className="btn btn-ghost" style={{ padding: "14px 22px", fontSize: 15 }}>Lihat demo singkat ▶</button>
        </div>
        <div style={{ display: "flex", gap: 24, marginTop: 40 }}>
          {[
            ["12.400+", "petani aktif"],
            ["18 prov.", "tersebar"],
            ["Rp 240M", "tercatat /thn"],
          ].map(([v, l]) => (
            <div key={l}>
              <div className="num" style={{ fontSize: 28, fontWeight: 700, color: "var(--ink)" }}>{v}</div>
              <div style={{ fontSize: 12, color: "var(--ink-4)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Phone mockup with dashboard preview */}
      <div style={{ position: "relative" }}>
        <div style={{ position: "absolute", inset: "-20px -40px -20px 0", background: "radial-gradient(circle at 70% 50%, var(--emerald-soft), transparent 60%)", borderRadius: 200, zIndex: 0 }} />
        <div style={{ position: "relative", display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 16, zIndex: 1 }}>
          {/* Big card: dashboard preview */}
          <div className="card" style={{ padding: 18, boxShadow: "var(--shadow-lg)", overflow: "hidden" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 11, color: "var(--ink-4)", fontWeight: 600 }}>RINGKASAN · MEI 2026</div>
                <div className="display" style={{ fontSize: 17, fontWeight: 700, marginTop: 2 }}>Kebun Suka Maju</div>
              </div>
              <SHLogo size={22} />
            </div>
            <div style={{ background: "var(--paper)", borderRadius: 14, padding: 14, marginBottom: 10 }}>
              <div style={{ fontSize: 11, color: "var(--ink-4)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>Untung bersih</div>
              <div className="num" style={{ fontSize: 32, fontWeight: 700, letterSpacing: "-0.025em" }}>Rp 38,4jt</div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
                <span className="chip chip-emerald" style={{ fontSize: 11 }}>↑ 18,2%</span>
                <AreaChart data={[8, 12, 10, 16, 14, 22, 28, 32, 38]} width={140} height={48} padding={2} showGrid={false} />
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {[
                ["Panen", "8,4 ton", "var(--c1)"],
                ["Biaya", "Rp 12jt", "var(--c2)"],
              ].map(([l, v, c]) => (
                <div key={l} style={{ background: "white", border: "1px solid var(--line)", borderRadius: 10, padding: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 6 }}>
                    <span style={{ width: 6, height: 6, background: c, borderRadius: 99 }} />
                    <span style={{ fontSize: 11, color: "var(--ink-4)", fontWeight: 600 }}>{l}</span>
                  </div>
                  <div className="num" style={{ fontSize: 18, fontWeight: 700 }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
          {/* Stack of supporting cards */}
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div className="card" style={{ padding: 14, boxShadow: "var(--shadow)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <div style={{ width: 28, height: 28, borderRadius: 8, background: "var(--terra-soft)", color: "var(--terra-2)", display: "grid", placeItems: "center" }}>
                  <Icons.Calendar size={14} />
                </div>
                <div style={{ fontSize: 12, fontWeight: 700 }}>Jadwal besok</div>
              </div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>Pemupukan Blok A</div>
              <div style={{ fontSize: 11, color: "var(--ink-4)" }}>240 pohon · 3 jam · Pak Hadi</div>
            </div>
            <div className="card" style={{ padding: 14, boxShadow: "var(--shadow)" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div>
                  <div style={{ fontSize: 11, color: "var(--ink-4)", fontWeight: 600, marginBottom: 4 }}>Harga TBS hari ini</div>
                  <div className="num" style={{ fontSize: 22, fontWeight: 700 }}>Rp 2.340<span style={{ fontSize: 12, fontWeight: 500, color: "var(--ink-4)" }}>/kg</span></div>
                </div>
                <span className="chip chip-emerald" style={{ fontSize: 10 }}>↑ 4,2%</span>
              </div>
              <Sparkline data={[2100, 2150, 2200, 2180, 2280, 2310, 2340]} width={180} height={36} />
            </div>
            <div className="card" style={{ padding: 14, boxShadow: "var(--shadow)", background: "var(--ink)", color: "white" }}>
              <div style={{ fontSize: 11, opacity: 0.6, fontWeight: 600 }}>KALKULATOR PUPUK</div>
              <div style={{ fontSize: 15, fontWeight: 700, margin: "4px 0 8px" }}>Hitung dosis NPK</div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div className="num" style={{ fontSize: 18, fontWeight: 700, color: "var(--terra)" }}>1,8 kg / pohon</div>
                <Icons.Arrow size={16} stroke="white" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const TrustBar = () => (
  <section style={{ padding: "20px 56px", borderTop: "1px solid var(--line)", borderBottom: "1px solid var(--line)", background: "white" }}>
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 40 }}>
      <div className="eyebrow" style={{ flexShrink: 0 }}>Dipakai bersama koperasi &amp; mitra</div>
      <div style={{ display: "flex", gap: 40, alignItems: "center", flexWrap: "wrap" }}>
        {["KOPSAWIT Riau", "ASIAN AGRI Petani Mitra", "GAPKI", "Kementan", "Bank BSI Tani", "PSR Indonesia"].map((n) => (
          <span key={n} style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 16, color: "var(--ink-4)", letterSpacing: "-0.01em" }}>{n}</span>
        ))}
      </div>
    </div>
  </section>
);

const FEATURES = [
  { icon: Icons.Home, color: "var(--c1)", eyebrow: "Ringkasan", title: "Satu layar untuk semua kebun", desc: "Untung bersih, hasil panen, harga TBS, dan jadwal — terhitung otomatis dari catatan harian." },
  { icon: Icons.Map, color: "var(--c4)", eyebrow: "Lahan", title: "Banyak kebun, satu pencatatan", desc: "Catat luas, jumlah pohon, tahun tanam, dan koordinat per blok agar laporan per-hektare akurat." },
  { icon: Icons.Leaf, color: "var(--c1)", eyebrow: "Panen", title: "Janjang, berat, harga, semua nyambung", desc: "Isi sekali, aplikasi hitung harga rata-rata, uang masuk, dan biaya panen secara otomatis." },
  { icon: Icons.Drop, color: "var(--c5)", eyebrow: "Perawatan", title: "Pisahkan biaya bahan dan tenaga", desc: "Catat pupuk, semprot, dan upah pekerja terpisah agar laporan biaya kebun jelas." },
  { icon: Icons.Calendar, color: "var(--c2)", eyebrow: "Jadwal", title: "Jadwal kerja tidak terlewat", desc: "Atur rotasi pupuk 3 bulanan, pruning 6 bulanan — pengingat masuk langsung ke hape." },
  { icon: Icons.Calc, color: "var(--c6)", eyebrow: "Kalkulator", title: "Hitung pupuk sesuai pohon", desc: "Masukkan umur tanaman, jumlah pohon, kadar NPK — keluar dosis per pohon &amp; total tahunan." },
];

const FeatureGrid = () => (
  <section style={{ padding: "80px 56px" }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 40 }}>
      <div>
        <div className="eyebrow" style={{ marginBottom: 10 }}>Apa yang bisa dikerjakan</div>
        <h2 className="display" style={{ fontSize: 48, lineHeight: 1.05, fontWeight: 700, letterSpacing: "-0.03em", margin: 0, maxWidth: 700 }}>
          Tujuh alat kerja kebun — bekerja sama, bukan terpisah.
        </h2>
      </div>
      <button className="btn btn-ghost">Lihat semua fitur →</button>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 18 }}>
      {FEATURES.map((f, i) => {
        const I = f.icon;
        return (
          <div key={i} className="card" style={{ padding: 24, position: "relative", overflow: "hidden", minHeight: 220 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: f.color, color: "white", display: "grid", placeItems: "center" }}>
                <I size={18} stroke="white" />
              </div>
              <div className="eyebrow">{f.eyebrow}</div>
            </div>
            <h3 className="display" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", margin: "0 0 10px", lineHeight: 1.15 }}>{f.title}</h3>
            <p style={{ color: "var(--ink-3)", fontSize: 14, lineHeight: 1.6, margin: 0 }} dangerouslySetInnerHTML={{ __html: f.desc }} />
            <div style={{ position: "absolute", right: -30, bottom: -30, opacity: 0.06 }}>
              <I size={120} stroke={f.color} strokeWidth={1.5} />
            </div>
          </div>
        );
      })}
    </div>
  </section>
);

const BigVisualSection = () => (
  <section style={{ padding: "0 56px 80px" }}>
    <div className="card" style={{ background: "var(--ink)", color: "var(--paper)", padding: "56px 56px", borderRadius: 28, position: "relative", overflow: "hidden" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.1fr", gap: 56, alignItems: "center", position: "relative", zIndex: 1 }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--terra)" }}>Laporan Keuangan</div>
          <h2 className="display" style={{ fontSize: 52, lineHeight: 1.0, letterSpacing: "-0.03em", margin: "16px 0 20px", fontWeight: 700, color: "white" }}>
            Akhir bulan tanpa kalkulator manual.
          </h2>
          <p style={{ fontSize: 17, lineHeight: 1.6, color: "rgba(255,255,255,0.7)", margin: "0 0 28px", maxWidth: 480 }}>
            Pendapatan, biaya, laba bersih per kebun — siap untuk koperasi, bank, atau pajak. Unduh PDF atau Excel, atau kirim langsung ke email.
          </p>
          <div style={{ display: "flex", gap: 12 }}>
            <button className="btn" style={{ background: "var(--terra)", color: "white", padding: "12px 20px" }}>Lihat contoh laporan</button>
            <button className="btn btn-ghost" style={{ borderColor: "rgba(255,255,255,0.2)", color: "white", background: "transparent" }}>Tonton 2 menit ▶</button>
          </div>
        </div>
        {/* Chart preview inside dark card */}
        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>Untung bersih · 12 bulan</div>
              <div className="num" style={{ fontSize: 34, fontWeight: 700, color: "white" }}>Rp 482,4jt</div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              {[["Pendapatan", "var(--c1)"], ["Biaya", "var(--c2)"]].map(([n, c]) => (
                <span key={n} style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.7)", display: "inline-flex", alignItems: "center", gap: 4 }}>
                  <span style={{ width: 8, height: 8, background: c, borderRadius: 2 }} />{n}
                </span>
              ))}
            </div>
          </div>
          <MultiArea
            series={[
              { name: "Pendapatan", data: [42, 48, 55, 52, 61, 68, 72, 78, 75, 88, 92, 96] },
              { name: "Biaya", data: [22, 24, 28, 26, 31, 30, 34, 32, 36, 38, 40, 38] },
            ]}
            width={520}
            height={200}
            palette={["var(--c1)", "var(--c2)"]}
          />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            {["Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des", "Jan", "Feb", "Mar", "Apr", "Mei"].map((m) => (
              <span key={m} style={{ fontSize: 10, color: "rgba(255,255,255,0.45)", fontFamily: "var(--font-mono)" }}>{m}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const Testimonial = () => (
  <section style={{ padding: "80px 56px" }}>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 18 }}>
      {[
        { name: "Pak Suparman", role: "Petani · Riau · 3,2 ha", quote: "Sebelum pakai, catatan panen ada di buku tulis. Sekarang anak saya tinggal foto setruk timbangan dan saya tahu untungnya berapa." },
        { name: "Bu Hartini", role: "Bendahara KopSawit Tanjung Jabung", quote: "Laporan bulanan anggota tinggal unduh. Kami tidak perlu lagi tunggu 3 minggu untuk rapat keuangan." },
        { name: "Pak Yusran", role: "Petani · Sumut · 8,5 ha", quote: "Jadwal pupuk 3 bulanan tidak pernah terlewat. Hasil panen naik 14% dalam setahun." },
      ].map((t) => (
        <div key={t.name} className="card" style={{ padding: 28 }}>
          <div className="display" style={{ fontSize: 22, lineHeight: 1.4, fontWeight: 500, letterSpacing: "-0.015em", color: "var(--ink)" }}>“{t.quote}”</div>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 22, paddingTop: 22, borderTop: "1px solid var(--line)" }}>
            <div className="ph" style={{ width: 44, height: 44, borderRadius: 99 }}>foto</div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700 }}>{t.name}</div>
              <div style={{ fontSize: 12, color: "var(--ink-4)" }}>{t.role}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  </section>
);

const Pricing = () => (
  <section style={{ padding: "60px 56px 80px" }}>
    <div style={{ textAlign: "center", marginBottom: 40 }}>
      <div className="eyebrow" style={{ marginBottom: 10 }}>Harga</div>
      <h2 className="display" style={{ fontSize: 48, fontWeight: 700, letterSpacing: "-0.03em", margin: 0 }}>Mulai gratis. Tambah saat siap.</h2>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 18, maxWidth: 1080, margin: "0 auto" }}>
      {[
        { name: "Coba", price: "Gratis", per: "14 hari", desc: "Semua fitur, tanpa kartu kredit.", cta: "Mulai gratis", feats: ["2 kebun", "Catat panen & rawat", "Laporan bulanan", "Backup di cloud"] },
        { name: "Petani Pro", price: "Rp 49rb", per: "/bulan", desc: "Untuk kebun keluarga sampai 20 ha.", cta: "Pilih Petani Pro", feats: ["Kebun tak terbatas", "Kalkulator pupuk", "Ekspor PDF & Excel", "Pengingat WhatsApp", "Dukungan prioritas"], featured: true },
        { name: "Koperasi", price: "Hubungi", per: "kami", desc: "Untuk koperasi & kelompok tani 50+ anggota.", cta: "Diskusi dengan tim", feats: ["Multi-akun anggota", "Rekap koperasi", "API integrasi pabrik", "Pelatihan onsite", "Dedicated manager"] },
      ].map((p) => (
        <div key={p.name} className="card" style={{ padding: 28, background: p.featured ? "var(--ink)" : "white", color: p.featured ? "white" : "var(--ink)", border: p.featured ? "1px solid var(--ink)" : "1px solid var(--line)", position: "relative" }}>
          {p.featured && <div style={{ position: "absolute", top: -10, right: 24, background: "var(--terra)", color: "white", fontSize: 11, fontWeight: 700, padding: "4px 10px", borderRadius: 999, letterSpacing: "0.06em", textTransform: "uppercase" }}>Paling populer</div>}
          <div className="eyebrow" style={{ color: p.featured ? "var(--terra)" : "var(--ink-4)" }}>{p.name}</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 6, margin: "12px 0 4px" }}>
            <span className="display" style={{ fontSize: 44, fontWeight: 700, letterSpacing: "-0.03em" }}>{p.price}</span>
            <span style={{ fontSize: 14, color: p.featured ? "rgba(255,255,255,0.5)" : "var(--ink-4)" }}>{p.per}</span>
          </div>
          <p style={{ fontSize: 14, color: p.featured ? "rgba(255,255,255,0.65)" : "var(--ink-3)", margin: "0 0 24px" }}>{p.desc}</p>
          <button className="btn" style={{ width: "100%", justifyContent: "center", background: p.featured ? "var(--terra)" : "var(--ink)", color: "white", padding: "12px 20px" }}>{p.cta} <Icons.Arrow size={14} stroke="white" /></button>
          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 24, paddingTop: 24, borderTop: p.featured ? "1px solid rgba(255,255,255,0.1)" : "1px solid var(--line)" }}>
            {p.feats.map((f) => (
              <div key={f} style={{ display: "flex", gap: 10, alignItems: "center", fontSize: 13.5 }}>
                <Icons.Check size={14} stroke={p.featured ? "var(--c1)" : "var(--emerald)"} />
                {f}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  </section>
);

const CTA = () => (
  <section style={{ padding: "0 56px 80px" }}>
    <div style={{ borderRadius: 28, background: "linear-gradient(120deg, var(--emerald) 0%, var(--emerald-2) 70%)", padding: "64px 56px", color: "white", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", right: -80, top: -80, opacity: 0.15, transform: "rotate(20deg)", color: "white" }}>
        <SHLogo size={400} mono />
      </div>
      <div style={{ position: "relative", maxWidth: 640 }}>
        <h2 className="display" style={{ fontSize: 56, fontWeight: 700, letterSpacing: "-0.03em", lineHeight: 1.0, margin: "0 0 16px" }}>Mulai dari panen<br />minggu ini.</h2>
        <p style={{ fontSize: 17, lineHeight: 1.55, opacity: 0.85, margin: "0 0 32px" }}>14 hari gratis tanpa kartu kredit. Tim kami bantu pindahkan catatan lama kamu — gratis.</p>
        <div style={{ display: "flex", gap: 12 }}>
          <button className="btn" style={{ background: "white", color: "var(--ink)", padding: "14px 22px", fontSize: 15 }}>Daftar sekarang <Icons.Arrow size={16} /></button>
          <button className="btn" style={{ background: "transparent", color: "white", border: "1px solid rgba(255,255,255,0.3)", padding: "14px 22px", fontSize: 15 }}>WhatsApp tim · 0811-7100-200</button>
        </div>
      </div>
    </div>
  </section>
);

const LandingPage = () => (
  <div className="pg" style={{ width: 1440 }}>
    <LandingHeader />
    <LandingHero />
    <TrustBar />
    <FeatureGrid />
    <BigVisualSection />
    <Testimonial />
    <Pricing />
    <CTA />
    <PublicFooter />
  </div>
);

window.LandingPage = LandingPage;
