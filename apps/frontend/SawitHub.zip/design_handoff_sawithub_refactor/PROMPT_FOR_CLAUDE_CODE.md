# Prompt untuk Claude Code

Salin teks di bawah ini dan paste sebagai pesan pertama saat membuka Claude Code di repository `frontend-sawithub`. Sertakan folder `design_handoff_sawithub_refactor/` di root repo (atau di lokasi yang Anda pilih) sebelum mulai.

---

## VERSI PENDEK (cepat)

> Refactor seluruh UI/UX aplikasi SawitHub mengikuti design handoff di folder `design_handoff_sawithub_refactor/`. **Baca `README.md` di folder itu sampai habis sebelum mulai**, lalu kerjakan per fase sesuai urutan di bab "Fase Pengerjaan". Aplikasi pindah dari **tema gelap ke tema terang** dengan identitas baru (logo pelepah sawit, palet emerald + krim + terakota, font Plus Jakarta Sans + Bricolage Grotesque), navigasi top-bar horizontal menggantikan sidebar. Cakupannya: landing, login, signup, reset password, dashboard, lahan, panen, perawatan, jadwal, kalkulator pupuk, laporan keuangan, pendapatan, harga TBS, profil, langganan, notifikasi — total 18 layar. File `.jsx` di handoff folder adalah **referensi visual**, bukan untuk disalin mentah — implementasi pakai stack yang sudah ada (React 19 + TypeScript + Tailwind v4 + Recharts). Kerjakan **fase demi fase**, commit per fase, dan **tanya saya konfirmasi sebelum lanjut fase berikutnya**.

---

## VERSI LENGKAP (rekomendasi)

> # Refactor UI/UX SawitHub — Fresh, Light, Modern Fintech
>
> Halo Claude Code. Saya butuh kamu refactor seluruh tampilan aplikasi SawitHub (web app untuk petani sawit Indonesia, React 19 + TypeScript + Tailwind v4 + Vite) dari tema gelap saat ini ke desain baru yang fresh, light, professional, dan modern.
>
> ## Sumber kebenaran desain
>
> Folder `design_handoff_sawithub_refactor/` berisi **semua spesifikasi yang kamu butuhkan**:
> - `README.md` — dokumen handoff lengkap (design tokens, tipografi, komponen inti, spesifikasi tiap halaman, behavior, responsive, aksesibilitas, dan checklist)
> - File `.jsx` (landing, auth, dashboard, dataops, financial, tools, account, brand, ui-primitives) — mockup visual berupa React HTML prototype
> - `index.html` + `app.jsx` — kanvas yang menggabungkan semua mockup
>
> **PENTING:** file `.jsx` di handoff adalah **referensi visual saja** — pixel-perfect mockup yang menunjukkan tujuan akhir. **Jangan copy-paste sebagai komponen mentah.** Kamu harus me-rewrite ulang sebagai komponen TSX yang rapi mengikuti konvensi codebase yang sudah ada (Tailwind utilities, pola dari `src/api/client.ts`, `src/context/`, `src/components/design-system.tsx`, `react-hot-toast`, `recharts`).
>
> ## Langkah pertama (WAJIB)
>
> 1. Baca `design_handoff_sawithub_refactor/README.md` sampai habis
> 2. Eksplor repo untuk memahami pola yang ada di `src/` — terutama `App.tsx`, `index.css`, `tailwind.config.js`, `components/AppLayout.tsx`, `components/AuthLayout.tsx`, `components/design-system.tsx`, dan struktur `pages/`
> 3. Jawab pertanyaan yang ada di **bab 19 README** (atau eskalasi ke saya jika butuh keputusan)
> 4. Buat rencana implementasi lengkap dengan TodoWrite, kelompokkan sesuai 6 fase di README
>
> ## Eksekusi
>
> Kerjakan **fase demi fase**:
>
> - **Fase 0** — Foundation: ganti CSS root tokens, load Google Fonts (Plus Jakarta Sans, Bricolage Grotesque, JetBrains Mono), update `tailwind.config.js`, buat `Logo.tsx` baru, perluas `design-system.tsx`, buat `AppTopNav.tsx`
> - **Fase 1** — Public: Landing, Login, Signup, Reset Password, PublicHeader/Footer, AuthLayout
> - **Fase 2** — Dashboard inti: Ringkasan, AppLayout pakai top nav baru
> - **Fase 3** — Operasional: Lahan (list + form), Panen, Perawatan
> - **Fase 4** — Keuangan: Laporan, Pendapatan, Harga TBS
> - **Fase 5** — Alat: Jadwal Perawatan, Kalkulator Pupuk
> - **Fase 6** — Akun: Profile, Subscription, Notifikasi, dan halaman info publik (Help, About, Privacy, Terms)
>
> Di tiap fase:
> 1. List file yang akan disentuh dan rencana perubahan
> 2. Implementasi
> 3. **Test build** (`npm run build` atau `npm run dev`) — pastikan tidak ada TS error & app berjalan
> 4. Commit dengan pesan deskriptif: `refactor(ui): phase N — <ringkasan>`
> 5. **Berhenti dan tanya saya** sebelum lanjut fase berikutnya
>
> ## Hal yang HARUS dihapus
>
> Cari & ganti semua artefak tema gelap lama:
> - Background `#07100a`, `#13102a`, `bg-white/5`, `bg-white/[0.0X]`, `border-white/10`
> - Class lama: `.app-card`, `.primary-button`, `.app-submit-button`, `.app-submit-button--sky`
> - Override `select` dark di `body`
> - Warna text hardcoded `text-white`, `text-white/70`, `text-white/45` di komponen non-marketing-dark
>
> Ganti dengan token baru dari `README.md` bab "Design Tokens".
>
> ## Hal yang HARUS dipertahankan
>
> - Semua route di `App.tsx` (URL tidak berubah)
> - Logika bisnis di `src/api/`, `src/context/`, `src/utils/`, `src/hooks/`
> - Endpoint API call dan signature data
> - Analytics events (`trackEvent`, `GAEvents`)
> - File tes Playwright di `tests/` (sesuaikan jika selektor berubah, tapi jangan hapus tesnya)
>
> ## Catatan teknis
>
> - **Recharts** sudah terpasang — gunakan untuk semua grafik (Area, Line, Bar, Composed). Konfigurasi visual ada di README bab 10.
> - **Icon** — install `lucide-react` dan map nama yang ada di `Icons` object handoff ke `lucide-react`. Daftar lengkap di README bab 16.
> - **Logo SawitHub** — bukan file PNG/SVG eksternal, melainkan SVG inline di `src/components/Logo.tsx` (lihat fungsi `SHLogo` dan `SHWordmark` di `ui-primitives.jsx`)
> - **react-hot-toast** sudah dipakai — override style toast agar match desain (bg white, border line, shadow-lg)
> - **Responsive** — desain utama 1440px desktop. Breakpoint behavior ada di README bab 14. `BottomNav.tsx` untuk mobile tetap dipertahankan (tapi re-skin).
> - **Bahasa Indonesia** — semua copy UI harus Bahasa Indonesia (sudah disalin di mockup, bisa langsung di-extract jika belum ada)
>
> ## Format laporan
>
> Setiap kali selesai fase, beri ringkasan:
> ```
> ✅ Fase N selesai
>
> File yang diubah:
> - src/...
>
> File baru:
> - src/...
>
> File dihapus:
> - src/...
>
> Catatan:
> - <hal yang perlu perhatian saya>
> - <pertanyaan jika ada>
>
> Boleh saya lanjut ke Fase N+1?
> ```
>
> Mulai sekarang — baca README dulu, lalu balas dengan rencana implementasi & pertanyaan klarifikasi sebelum mulai coding.

---

## TIPS PENGGUNAAN

1. **Jangan kerjakan semua sekaligus.** Bahkan dengan Claude Code, refactor 18 layar dalam 1 sesi rentan menghasilkan inkonsistensi. Per-fase + commit per-fase adalah safety net.
2. **Buka mockup di browser** sambil Claude Code bekerja. Buka `design_handoff_sawithub_refactor/index.html` di tab terpisah agar bisa cek visual tiap saat.
3. **Sebelum mulai fase baru**, jalankan `git diff` atau buka PR untuk fase sebelumnya — review screenshot per halaman.
4. **Kalau ada keputusan desain abu-abu** (mis. "mobile bottom nav harus diapakan"), jawaban ada di bab 19 README atau tanya saya.
5. **Backup dulu** — buat branch `refactor/ui-v2-2026` sebelum Claude Code mulai. Jangan kerjakan langsung di `main`.

Selamat refactor! 🌴
