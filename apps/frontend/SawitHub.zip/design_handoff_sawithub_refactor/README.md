# Handoff: SawitHub UI/UX Refactor (v2.0)

> **Untuk Claude Code:** baca dokumen ini sampai habis sebelum mulai. Pengerjaan akan menyentuh seluruh halaman, jadi rencanakan dalam beberapa fase. Tanyakan ke user jika ragu — jangan asumsikan.

---

## 1. Overview

SawitHub adalah aplikasi web untuk petani sawit Indonesia: catat panen, biaya rawat, jadwal kerja, harga TBS, dan laporan keuangan. Dokumen ini adalah **handoff desain refactor lengkap** — semua halaman publik, autentikasi, dan dashboard akan diganti ke sistem desain baru.

**Tujuan refactor:**
- Pindah dari **tema gelap** ke **tema terang** (modern fintech, krim/cream paper)
- Identitas visual baru: logo pelepah sawit, palet emerald + krim + terakota
- Tipografi data-product: Plus Jakarta Sans (body) + Bricolage Grotesque (display/angka)
- Top nav horizontal (bukan sidebar)
- Kartu data lebih lapang, grafik area lembut dengan gradient, palet kategorikal yang berani

---

## 2. About the Design Files

File di dalam bundle ini adalah **referensi desain dalam bentuk HTML/React** — bukan kode produksi. Mereka adalah mockup yang menunjukkan layout, warna, tipografi, dan interaksi yang dituju.

**Tugas Anda:** buat ulang desain ini di codebase SawitHub yang sudah ada (React 19 + TypeScript + Tailwind v4 + Vite + React Router) menggunakan pola dan library yang sudah dipakai (recharts untuk grafik, react-hot-toast, dll). **Jangan menyalin HTML mentah** — terapkan sebagai komponen React/TSX yang rapi dengan Tailwind utilities, sesuai konvensi codebase.

---

## 3. Fidelity

**High-fidelity (hifi).** Mockup ini sudah final dalam hal:
- ✅ Warna (hex pasti, lihat Design Tokens)
- ✅ Tipografi (font + ukuran + weight)
- ✅ Spacing, radius, shadow
- ✅ Konten/copy bahasa Indonesia
- ✅ Layout dan komponen

Recreate **pixel-perfect**, tapi tetap pakai library/komponen yang ada di codebase (jangan reinvent — pakai `recharts` untuk chart, jangan SVG manual).

---

## 4. Stack & Konvensi Codebase

Codebase saat ini menggunakan:

```
React 19 + TypeScript + Vite
Tailwind CSS v4 (@import "tailwindcss")
React Router DOM
Recharts (untuk grafik)
react-hot-toast (untuk notifikasi)
```

**Pola yang sudah ada (gunakan, jangan ganti):**
- `src/api/client.ts` — axios client untuk API calls
- `src/context/useAuth.ts`, `useFarm.ts` — context providers
- `src/components/AppLayout.tsx`, `AppTopbar.tsx` — shell layout (akan di-refactor)
- `src/components/AuthLayout.tsx` — shell autentikasi (akan di-refactor)
- `src/components/FormPage.tsx` — wrapper halaman form
- `src/components/design-system.tsx` — komponen reusable (perlu diperluas)
- `src/utils/rupiah.ts` — formatter mata uang
- `src/utils/analytics.ts` — `trackEvent` + `GAEvents`

**Pola CSS lama (HAPUS):** `.app-card`, `.primary-button`, dark bg `#07100a`, `bg-white/5` overlays — semua harus diganti dengan token tema terang baru.

---

## 5. Fase Pengerjaan (Rekomendasi)

Lakukan dalam urutan ini agar tidak merusak fitur yang berjalan:

### Fase 0 — Foundation (HARUS DULUAN)
1. **Update CSS root tokens** di `src/index.css`:
   - Ganti `--color-bg` jadi `#FAF6EC` (krim)
   - Ganti `--color-primary` jadi `#0A7847` (emerald)
   - Tambah semua token baru (lihat `Design Tokens` di bawah)
   - Hapus dark mode hardcoded di `select`, `body`
2. **Setup font** — tambah Google Fonts (`Plus Jakarta Sans`, `Bricolage Grotesque`, `JetBrains Mono`) di `index.html`
3. **Update `tailwind.config.js`** — extend warna dengan token baru (lihat Design Tokens)
4. **Buat `src/components/Logo.tsx` baru** — SVG pelepah sawit (lihat `ui-primitives.jsx` di bundle, fungsi `SHLogo`)
5. **Update `src/components/design-system.tsx`** — tambah primitives: `AreaChart` (wrapper recharts), `Sparkline`, `Donut`, `KPICard`, `Chip`, `StatPill`, `Icons` (lucide-react atau extract dari bundle)
6. **Buat `src/components/AppTopNav.tsx` baru** menggantikan `AppTopbar.tsx` + `Sidebar.tsx`

### Fase 1 — Public (Landing + Auth)
7. `src/pages/Landing.tsx` — refactor total
8. `src/components/PublicHeader.tsx`, `PublicFooter.tsx` — refactor
9. `src/components/AuthLayout.tsx` — refactor (panel kiri gelap + form kanan krim)
10. `src/pages/Login.tsx`, `Signup.tsx`, `ForgotPassword.tsx`, `ResetPassword.tsx`

### Fase 2 — Dashboard core
11. `src/components/AppLayout.tsx` — pakai `AppTopNav` baru
12. `src/pages/Dashboard.tsx` — refactor jadi Ringkasan baru

### Fase 3 — Data operasional
13. `src/pages/Lahan.tsx` (form) + tambah `LahanList.tsx` jika belum ada (kartu kebun grid)
14. `src/pages/Panen.tsx` (form + list)
15. `src/pages/Perawatan.tsx` (timeline)
16. `src/pages/AddLahan.tsx`, `AddPanen.tsx`, `AddPerawatan.tsx`, `AddPendapatan.tsx`

### Fase 4 — Keuangan
17. `src/pages/LaporanKeuangan.tsx` + sub-komponen di `LaporanKeuangan/`
18. `src/pages/Pendapatan.tsx`
19. `src/pages/HargaTbs.tsx`

### Fase 5 — Alat
20. `src/pages/JadwalPerawatan.tsx` (kalender bulanan)
21. `src/pages/KalkulatorPupuk.tsx`

### Fase 6 — Akun
22. `src/pages/Profile.tsx`
23. `src/pages/Subscription.tsx`, `SubscriptionPayments.tsx`
24. `src/pages/Notifikasi.tsx`
25. `src/pages/Help.tsx`, `About.tsx`, `Privacy.tsx`, `Terms.tsx`, `BantuanAkses.tsx`, `CookieSettings.tsx` — pakai shell publik baru

---

## 6. Design Tokens

Ganti `:root` di `src/index.css` jadi:

```css
:root {
  /* Ink (text) */
  --ink: #0d1f17;
  --ink-2: #1a2b22;
  --ink-3: #4a5b53;       /* muted */
  --ink-4: #7b8a83;       /* dimmer muted */

  /* Surface */
  --paper: #faf6ec;       /* page bg */
  --paper-2: #f4eedf;     /* subtle alt */
  --surface: #ffffff;     /* card bg */
  --line: #e7e2d4;        /* border */
  --line-2: #efeadd;      /* softer border */

  /* Brand — emerald */
  --emerald: #0a7847;
  --emerald-2: #0f5e3a;   /* hover/deep */
  --emerald-3: #1a9959;   /* bright */
  --emerald-soft: #e6f3eb;
  --emerald-tint: #f1f8f3;

  /* Accent — terracotta */
  --terra: #d96a2c;
  --terra-2: #b84e1a;
  --terra-soft: #fbe9dc;

  /* Categorical (charts, badges per jenis kerja, per kebun) */
  --c1: #0a7847;  /* emerald */
  --c2: #d96a2c;  /* terracotta */
  --c3: #d4a017;  /* ochre */
  --c4: #1c8e8a;  /* teal */
  --c5: #7d3a6b;  /* plum */
  --c6: #5e8a52;  /* sage */

  /* Radius */
  --radius-sm: 10px;
  --radius: 14px;
  --radius-lg: 20px;
  --radius-xl: 28px;

  /* Shadow */
  --shadow-sm: 0 1px 0 rgba(13, 31, 23, 0.04), 0 1px 2px rgba(13, 31, 23, 0.04);
  --shadow: 0 4px 14px -6px rgba(13, 31, 23, 0.08), 0 1px 0 rgba(13, 31, 23, 0.04);
  --shadow-lg: 0 24px 48px -24px rgba(13, 31, 23, 0.18), 0 8px 24px -16px rgba(13, 31, 23, 0.08);

  /* Font */
  --font-sans: "Plus Jakarta Sans", system-ui, sans-serif;
  --font-display: "Bricolage Grotesque", "Plus Jakarta Sans", sans-serif;
  --font-mono: "JetBrains Mono", ui-monospace, monospace;
}
```

**Tailwind config** (`tailwind.config.js`) — extend dengan token:

```js
extend: {
  colors: {
    ink: { DEFAULT: '#0d1f17', 2: '#1a2b22', 3: '#4a5b53', 4: '#7b8a83' },
    paper: { DEFAULT: '#faf6ec', 2: '#f4eedf' },
    line: { DEFAULT: '#e7e2d4', 2: '#efeadd' },
    emerald: { DEFAULT: '#0a7847', 2: '#0f5e3a', 3: '#1a9959', soft: '#e6f3eb', tint: '#f1f8f3' },
    terra: { DEFAULT: '#d96a2c', 2: '#b84e1a', soft: '#fbe9dc' },
    cat: { 1: '#0a7847', 2: '#d96a2c', 3: '#d4a017', 4: '#1c8e8a', 5: '#7d3a6b', 6: '#5e8a52' },
  },
  fontFamily: {
    sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
    display: ['"Bricolage Grotesque"', '"Plus Jakarta Sans"', 'sans-serif'],
    mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
  },
  borderRadius: { 'sm-1': '10px', 'md-1': '14px', 'lg-1': '20px', 'xl-1': '28px' },
}
```

---

## 7. Tipografi

| Pemakaian | Font | Size | Weight | Letter-spacing |
|---|---|---|---|---|
| Display besar (hero) | Bricolage Grotesque | 56–96px | 700 | -0.03em – -0.04em |
| H1 halaman | Bricolage Grotesque | 32–36px | 700 | -0.025em |
| H2 section | Bricolage Grotesque | 20–28px | 700 | -0.02em |
| H3 sub | Plus Jakarta Sans | 16–18px | 700 | -0.015em |
| Body | Plus Jakarta Sans | 14–15px | 400/500 | normal |
| Body kecil / meta | Plus Jakarta Sans | 12–13px | 500 | normal |
| Eyebrow | Plus Jakarta Sans | 11px | 700 | 0.14em uppercase |
| Angka KPI besar | Bricolage Grotesque | 28–40px | 700 | -0.025em, tabular-nums |
| Angka di tabel | JetBrains Mono | 12–13px | 400 | normal |
| Timestamp / kode | JetBrains Mono | 11–12px | 500 | normal |

CSS helper:
```css
.display { font-family: var(--font-display); letter-spacing: -0.02em; }
.num { font-family: var(--font-display); font-variant-numeric: tabular-nums; letter-spacing: -0.02em; }
.mono { font-family: var(--font-mono); }
.eyebrow { font-size: 11px; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; color: var(--ink-4); }
```

---

## 8. Logo & Brand

Logo SawitHub = **pelepah sawit stylized**:
- Tulang daun vertikal lurus
- 4 pasang anak daun melengkung ke atas (8 total, simetris kiri-kanan)
- Satu titik tandan buah berwarna **terakota** di puncak
- Default: stroke emerald `#0A7847`, fruit terakota `#D96A2C`
- Mode mono: pakai `currentColor` untuk stroke + fruit

Wordmark: `sawit` (ink) + `hub` (emerald), display sans, weight 700.

Implementasi: lihat fungsi `SHLogo` dan `SHWordmark` di `ui-primitives.jsx`. Pakai SVG inline di komponen React (`src/components/Logo.tsx`), jangan import sebagai file.

---

## 9. Komponen Inti

### Card
```
bg: var(--surface) atau var(--paper)
border: 1px solid var(--line)
border-radius: var(--radius-lg)  /* 20px */
padding: 20–28px
shadow: var(--shadow-sm) default, var(--shadow-lg) untuk elevated
```

### Button — Primary (ink/black)
```
bg: var(--ink), color: var(--paper)
padding: 10px 16px (md), 14px 22px (lg)
border-radius: 999px (pill)
font-weight: 600, font-size: 14px
hover: bg var(--emerald-2)
```

### Button — Emerald
```
bg: var(--emerald), color: white
sama radius/font seperti primary
```

### Button — Ghost
```
bg: transparent, border: 1px solid var(--line), color: var(--ink)
hover: bg var(--paper-2)
```

### Chip
```
padding: 4px 10px, border-radius: 999px
font-size: 12px, font-weight: 600
border: 1px solid var(--line)
bg: white
Variants: chip-emerald (emerald soft), chip-terra (terra soft), chip-warn (#fff7e0)
Categorical: bg cat-1..cat-6, color white, no border
```

### KPI Card (signature)
```
Card biasa + accent strip 3px di TOP edge berwarna kategorikal
Layout:
- Eyebrow label (11px uppercase muted)
- Value besar (32px Bricolage 700)
- Sub label (12px muted)
- Top-right: chip delta (↑ 12.4% emerald) atau (↓ 3.1% terra)
- Bottom: sparkline / area chart 56px height
```

### Top Nav
```
sticky top: 0, bg rgba(255,255,255,0.9) + backdrop-blur(10px)
border-bottom: 1px solid var(--line)
padding: 12px 28px
content (kiri ke kanan):
  - Wordmark
  - Farm switcher chip (kebun aktif + chevron)
  - Nav items: Ringkasan · Lahan · Panen · Perawatan · Jadwal · Keuangan · Laporan · Kalkulator
    - Active: bg emerald-soft, text ink, border emerald 18% opacity
    - Inactive: text ink-3, no bg
  - Search icon button, Bell button (dengan notification dot terra)
  - User pill: avatar gradient emerald + nama
```

### Input
```
padding: 13px 14px (kiri padding 42px jika ada icon)
border: 1px solid var(--line)
border-radius: 12px
bg: white
focus: border var(--emerald), outline none
font-size: 14px
Label: 13px weight 600 ink-2, mb 6px
Hint: 12px ink-4, right-aligned di baris label
```

### Empty / Add tile
```
Border: 2px dashed var(--line)
bg: white, radius: 20px
center: lingkaran 56px bg paper-2 + icon Plus
Text: "Tambah X Baru" + sub copy
```

---

## 10. Grafik (Recharts)

Gunakan komponen Recharts yang sudah dipakai (`AreaChart`, `LineChart`, `ComposedChart`, `Bar`). Konfigurasi visual untuk match desain:

**Area chart (soft, rounded, gradient):**
- `<defs>` dengan `linearGradient` vertikal: top 22% opacity warna kategorikal → bottom 0%
- `<Area type="monotone" strokeWidth={2} stroke={c} fill="url(#gradId)" />`
- Grid: horizontal only, `strokeDasharray="2 4"`, stroke `var(--line)`
- Axis: hide axis lines, font 11px `JetBrains Mono` color `var(--ink-4)`
- Tooltip: white bg, border `var(--line)`, radius 10px, shadow

**Bar chart:**
- Rounded corners (radius 6px atas)
- Last/active bar full opacity, sisanya 78% opacity
- Sama grid + axis treatment

**Sparkline:**
- No grid, no axis, padding 0
- Stroke 1.8px, smooth (monotone)

**Donut:**
- Stroke 10–14px
- Track: `var(--paper-2)`
- Stroke linecap: round
- Center label: angka di tengah (display sans), label kecil di bawah

---

## 11. Halaman — Spesifikasi per Layar

> **Catatan:** untuk setiap halaman, lihat file React/JSX yang sesuai di bundle ini. Tag `<DCArtboard>` di `app.jsx` memetakan setiap layar ke file komponennya.

### 11.1 Landing (`Landing.tsx`)
**File referensi:** `landing.jsx`

- **Header sticky:** wordmark + nav (Fitur, Untuk Petani, Untuk Koperasi, Harga, Cerita, Bantuan) + Masuk + CTA "Coba gratis 14 hari"
- **Hero:** 2 kolom
  - Kiri: badge "BARU · Kalkulator pupuk presisi · Versi 2026", H1 96px "Hape kamu, **kantor kebun** kamu." (kata "kantor kebun" warna emerald), subcopy, 2 CTA, 3 stats (12.400+ petani aktif, 18 prov., Rp 240M tercatat/thn)
  - Kanan: composite — 1 card besar (preview dashboard ringkasan dengan KPI Rp 38,4jt + sparkline + 2 mini KPI) + stack 3 card (jadwal besok, harga TBS hari ini, kalkulator pupuk dark)
- **Trust bar:** logo wordmark mitra (KOPSAWIT Riau, ASIAN AGRI, GAPKI, dll) — pakai text wordmark style, jangan SVG logo asli
- **Feature grid:** 3 kolom x 2 baris = 6 fitur (Ringkasan, Lahan, Panen, Perawatan, Jadwal, Kalkulator) — tiap card punya icon berwarna kategorikal, eyebrow, judul display, deskripsi, dan watermark icon besar di pojok bawah dengan opacity 6%
- **Section gelap (Laporan Keuangan):** card hitam `var(--ink)` full-width, 2 kolom — kiri copy + 2 CTA, kanan chart MultiArea (pendapatan vs biaya 12 bulan, palet emerald + terakota)
- **Testimoni:** 3 kartu pull-quote
- **Pricing:** 3 tier (Coba gratis, Petani Pro Rp 49rb/bln **featured**, Koperasi "Hubungi"), card featured = bg ink + chip "Paling populer" terakota di atas
- **CTA besar:** card gradient emerald, copy "Mulai dari panen minggu ini", 2 tombol
- **Footer:** wordmark + tagline + Play/App store badge + 4 kolom link + copyright + "Made with 🌴 in Pekanbaru"

### 11.2 Login (`Login.tsx`)
**File referensi:** `auth.jsx` → `LoginPage`

- Layout: 2 kolom 1.05:1 (panel kiri ink, form kanan paper)
- **Panel kiri:** wordmark putih atas, di tengah: badge "BARU · Versi 2026 · 12.400+ petani sudah pakai" + quote besar 44px display ("Sekali isi panen, langsung tahu untung kebun.") + nama + role + mini stats card (Pendapatan tahun ini Rp 142,8jt dengan sparkline terakota), footer copyright
- Background panel: radial gradients emerald di pojok kiri-bawah + terra di kanan-atas, opacity 5%; watermark logo besar di pojok kanan-bawah opacity 8%
- **Form kanan:** eyebrow "Masuk", H1 "Selamat datang kembali.", subcopy dengan link Daftar
- Fields: Email/Username/HP (icon User di kiri), Password (icon Lock + Eye toggle di kanan, link "Lupa password?" di label-right)
- Checkbox "Ingat saya"
- Tombol primary full-width "Masuk ke Dashboard"
- Divider "atau lanjut dengan"
- 2 tombol ghost grid: Google (SVG logo), OTP WhatsApp
- Info card bawah: "Data kebun kamu aman..."

### 11.3 Signup (`Signup.tsx`)
**File referensi:** `auth.jsx` → `SignupPage`

- Layout sama (2 kolom)
- Panel kiri: eyebrow terakota "Daftar 14 hari gratis", H 44px "Bawa kebun kamu ke dalam satu aplikasi.", 4 bullet dengan icon berwarna emerald (catat panen, laporan otomatis, kalkulator pupuk, pengingat WA)
- Form kanan fields (urutan):
  1. Nama lengkap + Nama kebun (2 kolom)
  2. No. WhatsApp (full, hint "Untuk verifikasi & pengingat")
  3. Email opsional
  4. Password + hint "Min. 8 karakter" + Eye toggle
- Checkbox setuju syarat
- Tombol primary "Mulai 14 hari gratis"
- Info card bawah emerald soft: "Bantuan migrasi gratis"

### 11.4 Reset Password (`ForgotPassword.tsx` + `ResetPassword.tsx`)
**File referensi:** `auth.jsx` → `ResetPasswordPage`

- Panel kiri: icon Lock besar di card terakota, copy "Lupa password? Tenang — kebun kamu tetap aman.", info hubungi tim
- Form kanan: link "← Kembali ke masuk", tab toggle (WhatsApp active vs Email), field nomor HP, tombol "Kirim kode 6 digit"
- **Step indicator** di bawah: 3 step (Identitas active → Kode OTP → Password baru)
- Untuk page "Reset" (set new password), ganti field jadi: Password baru + Konfirmasi, hint kekuatan password

### 11.5 Dashboard Ringkasan (`Dashboard.tsx`)
**File referensi:** `dashboard.jsx`

- Top nav active = "Ringkasan"
- **Welcome strip:** eyebrow "Selamat pagi · Senin, 14 Mei 2026", H1 36px personal greeting dengan angka untung bersih (warna emerald), sub copy jadwal+harga; kanan: pill toggle [Minggu·Bulan·Tahun] + tombol emerald "Catat panen"
- **4 KPI cards** (grid 4 kolom): Pendapatan, Biaya operasional, Untung bersih, Harga rata-rata TBS — masing-masing dengan accent strip warna kategorikal berbeda, sparkline area di bawah
- **Main grid 2:1:**
  - Kiri (2fr): Card "Arus kas · 12 bulan" dengan multi-area chart 4 series (4 kebun, palet kategorikal), legend di kanan-atas, axis bulan
  - Kanan (1fr) stack 2:
    - Card hijau gradient "Harga TBS Hari Ini" — angka 40px Rp 2.340/kg + chip delta terakota + sparkline area mini
    - Card "Jadwal terdekat" — 3 list item, label hari (BSK/RAB/JUM) di kotak warna kategorikal kiri
- **Bottom grid 1.3:1:1:**
  - Card "Riwayat panen" — table 5 baris (Tanggal mono, Kebun dengan dot kategorikal, Berat, Harga, Total bold display num)
  - Card "Komposisi biaya" — Donut 130px (42% pakai) + legend 5 kategori dengan dot
  - Card hitam "AI insight / Saran cepat" — 3 list item dengan border-left kategorikal, judul putih + body abu transparant

### 11.6 Lahan (`Lahan.tsx` — refactor jadi LIST, bukan form saja)
**File referensi:** `dataops.jsx` → `LahanPage`

- Page header: eyebrow "Data Kebun", H1 "Lahan", subcopy, kanan: Filter + Ekspor + tombol primary "Tambah Kebun"
- **5 stat pills** atas (grid 5 kolom): Total Kebun, Total Luas, Jumlah Pohon, Umur Rata-rata, Produktivitas — angka 22px display, accent kategorikal
- **Grid 3 kolom kebun cards** — tiap card:
  - Header: icon Map warna kategorikal + nama + lokasi kecil dengan icon Pin + chip status (Aktif=emerald, Perlu rawat=terra, Replanting/Belum panen=warn)
  - Stats row 3 kolom (Luas/Pohon/Umur) — border atas-bawah
  - Produktivitas bar (progress) dengan persentase
  - Footer: panen terakhir + link "Detail →"
- **Tile terakhir = add new** (dashed border)

Form tambah lahan (`AddLahan.tsx`) tetap pakai `FormPage` shell tapi dengan style baru:
- Card form: bg white, radius 20px, padding 24–28px, border var(--line)
- Field grid 1 atau 2 kolom sesuai konteks
- Tombol bawah: primary "Simpan" + ghost "Tambah lagi"

### 11.7 Panen (`Panen.tsx` — list+form gabungan)
**File referensi:** `dataops.jsx` → `PanenPage`

- Page header: eyebrow "Catat Panen", H1 "Riwayat Panen", kanan: bulan picker + Ekspor + tombol emerald
- **Layout 2:1:**
  - Kiri (2fr) stack:
    - Card chart "Hasil panen · 8 minggu terakhir" — angka 32jt + chip delta + toggle [Ton·Janjang·Rupiah] kanan; bar chart 8 minggu (bar terakhir highlight)
    - Card tabel "Daftar panen Mei 2026" — header dengan judul + search input; tabel: Tanggal mono, Kebun (dot kategorikal), Janjang num, Berat, Harga/kg, Biaya panen (terra), Total bersih (bold display); footer pagination
  - Kanan (1fr) sticky form cepat:
    - Card title eyebrow + "Formulir cepat"
    - Field dropdown Lahan + Tanggal (display style "card field")
    - Grid 2 kolom: Janjang/Berat, Harga/Biaya
    - **Result card emerald soft**: total bersih dihitung otomatis (28px display)
    - Tombol emerald "Simpan panen" + ghost "Simpan & catat berikutnya"

### 11.8 Perawatan (`Perawatan.tsx`)
**File referensi:** `dataops.jsx` → `PerawatanPage`

- Page header + actions (Filter, Calendar, Catat Perawatan)
- **4 KPI cards** top: Biaya rawat, Material, Tenaga kerja, Per hektare
- **Grid 1.2:1:**
  - Kiri: Card "Timeline perawatan" — legend 4 jenis kategorikal di atas; list aktivitas dengan **vertical timeline line** + icon bulat warna jenis kerja kategorikal; tiap item: tanggal mono + judul + meta (kebun, bahan, pekerja) + total bold
  - Kanan stack:
    - Card "Biaya per jenis" — 5 progress bar berwarna kategorikal dengan persentase
    - Card terakota soft "Saran AI" — icon + copy + link "Buka kalkulator →"

### 11.9 Laporan Keuangan (`LaporanKeuangan.tsx`)
**File referensi:** `financial.jsx` → `LaporanPage`

- Page header + actions (date range, Kirim email, Unduh Excel, **Unduh PDF primary**)
- **Hero strip card** bg gradient ink — grid 1.4:1:1:1: kiri periode + tab Bulan/Kuartal/Tahun/Kustom; kanan 3 KPI besar (Pendapatan, Biaya, Laba bersih) warna putih dengan chip delta kategorikal
- **Main chart card** — multi-area 3 series (Pendapatan emerald, Biaya terakota, Laba terakota), legend di kanan-atas
- **Grid 1.7:1:**
  - Kiri: Tabel "Rincian per kebun" — header eyebrow + sort; baris dengan dot kategorikal, hasil/pendapatan/biaya (warna terra)/laba bersih bold/margin progress mini; **baris Total** dengan border-top 2px hitam, bold 800
  - Kanan stack:
    - Card "Komposisi pendapatan" — Donut 120px (86% TBS) + legend
    - Card "Unduh laporan" — 4 opsi (PDF, Excel, Email, Bagikan link) dengan icon warna kategorikal

### 11.10 Pendapatan (`Pendapatan.tsx`)
**File referensi:** `financial.jsx` → `PendapatanPage`

- Page header + tombol emerald
- Tab horizontal: Semua, Subsidi PSR, Brondolan, Penjualan bibit, Lain-lain (active = bg ink)
- 3 KPI cards (Total, Subsidi, Brondolan)
- Tabel: Tanggal, Sumber, Kategori (chip warna kategorikal solid), Kebun, Jumlah, Status

### 11.11 Harga TBS (`HargaTbs.tsx`)
**File referensi:** `financial.jsx` → `HargaTbsPage`

- Page header
- **Grid 1.4:1:**
  - Kiri: Hero card gradient emerald — eyebrow tanggal+jam, **angka raksasa 88px Rp/kg**, chip delta terakota; bawah strip 3 stats (7H/30H/1T avg)
  - Kanan: Card "Per kelas umur tanaman" — 5 baris (≥10thn, 7-9, 4-6, 3, Brondolan) dengan dot kategorikal + harga + delta percentage
- **Grid 1.6:1:**
  - Kiri: Card chart "Riwayat harga · 12 bulan" + toggle range
  - Kanan: Card "Sumber data" — 5 sumber (Disbun Riau, PKS, koperasi, pengepul, pabrik) dengan harga warna kategorikal + timestamp

### 11.12 Jadwal Perawatan (`JadwalPerawatan.tsx`)
**File referensi:** `tools.jsx` → `JadwalPage`

- Page header + actions
- **4 preset rotation cards** atas: Pupuk 3bln, Semprot bulanan, Pruning 6bln, Weeding — tiap card icon + eyebrow + judul + "Jadwal terdekat: …"
- **Grid 2.2:1:**
  - Kiri: Card kalender bulanan — header "Mei 2026" + nav prev/next + legend 4 jenis; grid 7 kolom (Sen-Min, Sab/Min header warna terra); 35 sel hari, sel "hari ini" bg emerald-soft + chip "HARI INI", event pills berwarna kategorikal di dalam sel (max 2-3)
  - Kanan stack:
    - Card "Akan datang" — 5 list item dengan date badge kotak kategorikal (DD + bulan)
    - Card hitam "Pengingat WhatsApp aktif" — icon terakota + copy + link atur

### 11.13 Kalkulator Pupuk (`KalkulatorPupuk.tsx`)
**File referensi:** `tools.jsx` → `KalkulatorPage`

- Page header + 2 tombol kanan
- **Grid 1:1.2:**
  - Kiri (Input form):
    - Banner auto-fill emerald soft + dropdown Kebun
    - Grid 2 kolom: Umur tanaman + Jumlah pohon (input dengan satuan di kanan)
    - **Section "Kadar tanah"**: 3 nutrient (N, P, K) dengan label + nilai + **chip level (rendah=warn, sedang=emerald, tinggi=terra)** + progress bar berwarna kategorikal + skala referensi mono kecil
    - **Pilihan pupuk:** grid 2x2 radio card (NPK 12-12-27, NPK 15-15-15, Urea+KCl, Organik) — active = border emerald 1.5px + bg emerald soft + radio filled
    - **Periode pemupukan:** segmented [1/2/3/4/6 bulan] — active = bg ink
    - Tombol emerald "Hitung dosis pupuk"
  - Kanan (Result):
    - Card hitam "Hasil perhitungan" — 3 angka raksasa (Per pohon 1,8kg terakota, Per periode 864kg emerald, Per tahun 3,46ton ochre); panel bawah "Komposisi Nutrisi" 3 box warna kategorikal (N/P/K)
    - Card "Perkiraan biaya" — 3 box (Harga/kg, Total/rotasi, Total/tahun) + catatan terra soft

### 11.14 Profil (`Profile.tsx`)
**File referensi:** `account.jsx` → `ProfilePage`

- Layout 2 kolom: sub-nav kiri sticky 220px (Profil saya active, Kebun&blok, Tim, Pengingat WA, Keamanan, Privasi, Bantuan) + konten kanan
- **Identity card:** avatar gradient emerald 92px + tombol kamera kecil pojok, H2 nama, role + 2 chip (Terverifikasi emerald, Petani Pro terakota); tombol "Edit profil"
- Grid 2 kolom: 6 info box (Nama, WA, Email, Lokasi, Bahasa, Member sejak) — tiap box icon + label eyebrow + value
- Card "Ringkasan aktivitas" — 4 stat besar dengan top border kategorikal 3px (Kebun, Panen, Hasil panen, Laporan)
- Card "Anggota tim" — 4 list item dengan inisial avatar kategorikal + nama + role + tombol "Atur akses"

### 11.15 Subscription (`Subscription.tsx`)
**File referensi:** `account.jsx` → `SubscriptionPage`

- **Banner paket aktif:** card gradient emerald — chip "Paket aktif" + H38 "Petani Pro" + info billing + 2 tombol; kanan box semi-transparan dengan 3 usage bar
- **Grid 1:1:**
  - Kiri: Card upgrade "Naik ke Koperasi" — copy + 5 fitur dengan check emerald + harga + tombol primary
  - Kanan: Card "Riwayat pembayaran" — list tagihan dengan icon card + tanggal + metode + jumlah display + chip status + download icon

### 11.16 Notifikasi (`Notifikasi.tsx`)
**File referensi:** `account.jsx` → `NotifikasiPage`

- Page header + 2 tombol kanan
- Tab horizontal underline (Semua, Jadwal, Harga TBS, Keuangan, Sistem) dengan count badge
- **Group by hari:** "Hari ini", "Kemarin", "Minggu lalu"
- Tiap notifikasi card: icon bulat warna kategorikal + judul + body + timestamp mono + chip kategori; unread = bg emerald 3% + dot terra kecil

### 11.17 Halaman info publik (Help, About, Privacy, Terms, dll)
- Pakai `PublicPageLayout.tsx` baru dengan header + footer publik
- Konten body: max-width 800px, padding generous (40-56px top/bottom), tipografi Plus Jakarta Sans untuk body, Bricolage untuk H1/H2

### 11.18 Lainnya
- **NotFound, RouteError** — pakai card empty besar bg paper + Bricolage display H1 angka error + copy + tombol kembali
- **CookieConsent, TrialBanner** — toast bar tipis di bawah/atas, bg ink, copy putih, tombol terakota

---

## 12. Interaksi & Behavior

### Tombol
- Hover: bg shift (lihat token); transition 150ms ease
- Active/pressed: scale 0.98
- Disabled: opacity 0.55, cursor not-allowed
- Focus visible: outline 2px var(--emerald) offset 2px

### Form inputs
- Focus: border `var(--emerald)`, no glow; transition 150ms
- Error: border `var(--terra-2)` + helper text terra-2 di bawah
- Success: border emerald + check icon di kanan

### Cards
- Tidak ada hover state default
- Card yang clickable: hover shadow lebih besar (shadow → shadow-lg), transition 200ms; cursor pointer
- Card focus: outline 2px emerald offset 2px

### Charts
- Tooltip muncul on hover dengan delay 100ms
- Animasi awal: fade-in + slide-up 400ms ease-out (recharts default)

### Nav
- Active item: bg emerald-soft, border 1px emerald 18%
- Hover (inactive): bg paper-2
- Transitions 150ms

### Modal/dialog
- Backdrop: rgba(13,31,23,0.5) + blur 4px
- Modal card: max-width 480-640px, radius 20px, shadow-lg, padding 28-32px
- Animasi: backdrop fade 200ms, modal slide-up 8px + fade 250ms

### Toast (react-hot-toast)
- Override style: bg white, border 1px var(--line), shadow-lg, radius 14px, padding 12-16px
- Success: icon Check emerald
- Error: icon Alert terra
- Posisi: top-right desktop, top-center mobile

### Loading
- Skeleton: bg `var(--paper-2)`, radius matches container, shimmer animation linear-gradient 90deg + bg-position 1.5s infinite
- Spinner: stroke emerald 2px, 1s rotate

---

## 13. State Management

Semua state yang sudah ada (`useAuth`, `useFarm`, dll) **tidak berubah**. Refactor hanya menyentuh layer presentasi.

**Yang perlu ditambah:**
- `useDateRange()` hook — untuk picker periode di Laporan & KPI cards (week/month/quarter/year/custom)
- `useNotifications()` — fetcher list + mark-as-read endpoint (kalau belum ada)

---

## 14. Responsive

Desain mockup adalah **1440px desktop**. Untuk smaller breakpoint:

| Breakpoint | Perilaku |
|---|---|
| ≥1280px | Layout penuh seperti mockup |
| 1024–1279px | Padding turun ke 20–24px, KPI grid 2x2 alih-alih 4 kolom |
| 768–1023px | Top nav → hamburger; KPI 2 kolom; grid 2-kolom → 1 kolom; chart full width |
| <768px (mobile) | Bottom nav (sudah ada `BottomNav.tsx` — refactor warnanya) menggantikan top nav; semua card stack vertical; tabel jadi list card |

Halaman publik (Landing): hero stack vertical di <1024px, feature grid jadi 1 kolom di <768px.

---

## 15. Aksesibilitas

- Semua tombol harus punya text label atau `aria-label`
- Kontras ink/paper = 14.2:1 (✓ AAA), emerald/white = 4.8:1 (✓ AA)
- Hindari kombinasi ink-4 di paper untuk konten penting — gunakan minimal ink-3
- Form: label-for + helper text, error message di bawah field dengan `aria-describedby`
- Charts: sertakan `aria-label` descriptive dan `<title>` di SVG
- Focus indicator: outline 2px var(--emerald) offset 2px, **jangan dihilangkan**
- Tab order natural top-down
- Tabel: `<thead>` + `<th scope="col">`, dan visually-hidden caption per tabel

---

## 16. Assets

Tidak ada gambar/icon external yang dibutuhkan. Semua icon di-inline sebagai SVG (lihat object `Icons` di `ui-primitives.jsx`). Anda bisa:
- **Opsi A (rekomendasi):** install `lucide-react` (icon yang dipakai semua ada di sana: Home, Map, Leaf, Droplets, Calendar, BarChart3, Wallet, Calculator, Bell, User, Search, Plus, Check, ArrowRight, ChevronDown, ChevronUp, Filter, Settings, LogOut, Eye, Mail, Phone, Lock, Download, Share2, Star, MapPin, Sparkles, Truck, CreditCard)
- **Opsi B:** copy SVG path dari `ui-primitives.jsx` jadi `src/components/icons.tsx`

Logo SawitHub: inline SVG di `src/components/Logo.tsx`. **Tidak ada file PNG/SVG eksternal yang perlu di-bundle.**

---

## 17. Files di Bundle

| File | Isi |
|---|---|
| `index.html` | Entry point design canvas |
| `app.jsx` | Wiring DesignCanvas + DCArtboard untuk semua layar |
| `design-canvas.jsx` | Starter component (jangan ditiru, hanya untuk demo) |
| `ui-primitives.jsx` | **Sumber kebenaran** untuk: SHLogo, SHWordmark, Icons, AppTopNav, PageHeader, AreaChart, MultiArea, Bars, Sparkline, Donut, PublicFooter |
| `brand.jsx` | Halaman Identitas/Brand Foundation (referensi sistem desain) |
| `landing.jsx` | LandingPage |
| `auth.jsx` | LoginPage, SignupPage, ResetPasswordPage |
| `dashboard.jsx` | DashboardPage (Ringkasan) |
| `dataops.jsx` | LahanPage, PanenPage, PerawatanPage |
| `financial.jsx` | LaporanPage, PendapatanPage, HargaTbsPage |
| `tools.jsx` | JadwalPage, KalkulatorPage |
| `account.jsx` | ProfilePage, SubscriptionPage, NotifikasiPage |

---

## 18. Checklist Implementasi

Tandai saat selesai:

- [ ] **Foundation:** CSS root tokens diganti, font di-load, Tailwind config di-update
- [ ] **Komponen primitif baru:** Logo, AppTopNav, KPICard, Chip, StatPill, AreaChart wrapper, Donut, Sparkline
- [ ] **Public:** Landing, PublicHeader, PublicFooter, Login, Signup, ForgotPassword, ResetPassword
- [ ] **Shell app:** AppLayout pakai AppTopNav, AppTopbar lama dihapus, Sidebar lama dihapus, BottomNav refactor
- [ ] **Dashboard:** Ringkasan dengan 4 KPI + multi-area + harga TBS hijau + jadwal + breakdown
- [ ] **Ops:** Lahan list + form, Panen list+form, Perawatan timeline
- [ ] **Finance:** Laporan dengan tabel + ekspor, Pendapatan dengan tabs, Harga TBS dengan hero angka
- [ ] **Tools:** Jadwal kalender + preset, Kalkulator dengan NPK + hasil
- [ ] **Akun:** Profile dengan sub-nav, Subscription dengan banner aktif, Notifikasi grouped
- [ ] **Halaman info:** Help, About, Privacy, Terms, NotFound — pakai shell publik baru
- [ ] **Responsive:** test di breakpoint 1280, 1024, 768
- [ ] **Aksesibilitas:** focus state, aria-label, kontras
- [ ] **Hapus:** semua class lama (`.app-card`, `.primary-button`, `bg-white/[0.0X]`, `border-white/10`), dark mode di select/body, dark color hardcoded `#07100a`, `#13102a`

---

## 19. Pertanyaan untuk User (sebelum mulai)

Sebelum mulai coding, konfirmasi ke user:

1. Apakah ada halaman/fitur yang tidak boleh diubah strukturnya (hanya re-skin)?
2. Apakah ada copywriting di mockup yang sudah baku, atau bisa di-tweak ke pesan yang lebih sesuai produk?
3. Apakah perlu menjaga URL/route yang sudah ada, atau bebas re-struktur?
4. Apakah ada brand asset asli (logo PNG, mascot foto, foto petani) yang harus dipakai menggantikan placeholder?
5. Apakah `BottomNav` mobile harus tetap (legacy) atau refactor mengikuti top nav?

---

**Selamat mengerjakan. Kerjakan per fase, commit per fase, dan tanya user di akhir tiap fase sebelum lanjut.**
