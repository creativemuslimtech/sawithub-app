// Shared UI primitives used across all SawitHub pages.
// Logo, top nav, footer, sparklines, etc.

const SHLogo = ({ size = 28, mono = false }) => {
  // Stylized palm frond — central spine with arcing leaflets and a fruit dot.
  const stroke = mono ? "currentColor" : "var(--emerald)";
  const fruit = mono ? "currentColor" : "var(--terra)";
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <defs>
        <clipPath id="shclip">
          <circle cx="20" cy="20" r="20" />
        </clipPath>
      </defs>
      <g clipPath="url(#shclip)">
        {/* fronds: pairs of arcing leaflets around a central stem */}
        <g stroke={stroke} strokeWidth="2.2" strokeLinecap="round" fill="none">
          {/* central stem rising from base */}
          <path d="M20 36 L20 12" />
          {/* leaflets — left side */}
          <path d="M20 30 C 14 30, 10 27, 8 23" />
          <path d="M20 25 C 13 24, 9 20, 7 15" />
          <path d="M20 20 C 14 18, 11 13, 11 8" />
          <path d="M20 15 C 16 12, 15 8, 16 4" />
          {/* leaflets — right side */}
          <path d="M20 30 C 26 30, 30 27, 32 23" />
          <path d="M20 25 C 27 24, 31 20, 33 15" />
          <path d="M20 20 C 26 18, 29 13, 29 8" />
          <path d="M20 15 C 24 12, 25 8, 24 4" />
        </g>
        {/* fruit cluster — single warm dot at apex */}
        <circle cx="20" cy="11" r="2.6" fill={fruit} />
      </g>
    </svg>
  );
};

const SHWordmark = ({ size = 22, color = "var(--ink)" }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 9 }}>
    <SHLogo size={size + 6} />
    <span
      className="display"
      style={{
        fontSize: size,
        fontWeight: 700,
        color,
        letterSpacing: "-0.025em",
        lineHeight: 1,
      }}
    >
      sawit<span style={{ color: "var(--emerald)" }}>hub</span>
    </span>
  </div>
);

// ---- Icons used throughout (line, 1.6 stroke) -------------------------------
const Icon = ({ d, size = 18, stroke = "currentColor", fill = "none", strokeWidth = 1.7 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d={d} />
  </svg>
);
const Icons = {
  Home: (p) => <Icon {...p} d="M3 11 12 3l9 8M5 10v10h14V10" />,
  Map: (p) => <Icon {...p} d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Zm0 0v14m6-12v14" />,
  Leaf: (p) => <Icon {...p} d="M4 20c0-9 7-16 16-16 0 9-7 16-16 16Zm0 0L20 4" />,
  Drop: (p) => <Icon {...p} d="M12 3s7 7 7 12a7 7 0 1 1-14 0c0-5 7-12 7-12Z" />,
  Calendar: (p) => <Icon {...p} d="M4 7h16M4 7v13h16V7M4 7l3-3m13 3-3-3M8 11h2m4 0h2M8 15h2m4 0h2" />,
  Chart: (p) => <Icon {...p} d="M3 21V5m0 16h18M7 17V9m4 8V6m4 11v-7m4 7v-4" />,
  Wallet: (p) => <Icon {...p} d="M3 7h15a3 3 0 0 1 3 3v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Zm0 0V6a2 2 0 0 1 2-2h11M17 13.5h2" />,
  Calc: (p) => <Icon {...p} d="M6 3h12v18H6zM9 7h6M8 11h2m3 0h2M8 15h2m3 0h2M8 19h2m3 0h2" />,
  Bell: (p) => <Icon {...p} d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4l2-2Zm4 4a2 2 0 0 0 4 0" />,
  User: (p) => <Icon {...p} d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-8 9a8 8 0 0 1 16 0" />,
  Search: (p) => <Icon {...p} d="M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14Zm5.5 12 4 4" />,
  Plus: (p) => <Icon {...p} d="M12 5v14M5 12h14" />,
  Check: (p) => <Icon {...p} d="m5 12 5 5 9-11" />,
  Arrow: (p) => <Icon {...p} d="M5 12h14m-6-6 6 6-6 6" />,
  Down: (p) => <Icon {...p} d="m6 9 6 6 6-6" />,
  Up: (p) => <Icon {...p} d="m6 15 6-6 6 6" />,
  Filter: (p) => <Icon {...p} d="M4 5h16l-6 8v6l-4-2v-4L4 5Z" />,
  Settings: (p) => <Icon {...p} d="M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm9 3-2.2-.9.6-2.3-2.2-1.3.6-2.3-2.3-.6-1.3-2.2-2.3.6L11 0 9.7.8 7.4.2 6.1 2.4 3.8 3l.6 2.3L2.2 6.6l.6 2.3L.6 9.8 0 12l.6 2.2 2.2.9-.6 2.3 2.2 1.3-.6 2.3 2.3.6 1.3 2.2 2.3-.6L11 24l1.3-.8 2.3.6 1.3-2.2 2.3-.6-.6-2.3 2.2-1.3-.6-2.3 2.2-.9L24 12Z" strokeWidth="1.2" />,
  Logout: (p) => <Icon {...p} d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l-5-5 5-5m-5 5h11" />,
  Eye: (p) => <Icon {...p} d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12Zm11 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />,
  Mail: (p) => <Icon {...p} d="M3 6h18v12H3zm0 0 9 7 9-7" />,
  Phone: (p) => <Icon {...p} d="M5 4h4l2 5-2 1a11 11 0 0 0 5 5l1-2 5 2v4a2 2 0 0 1-2 2A17 17 0 0 1 3 6a2 2 0 0 1 2-2Z" />,
  Lock: (p) => <Icon {...p} d="M6 11V8a6 6 0 0 1 12 0v3M5 11h14v9H5z" />,
  Download: (p) => <Icon {...p} d="M12 3v12m-5-5 5 5 5-5M5 21h14" />,
  Share: (p) => <Icon {...p} d="M4 12v7h16v-7M12 3v13m-5-8 5-5 5 5" />,
  Star: (p) => <Icon {...p} d="m12 3 2.7 6 6.3.7-4.8 4.4 1.4 6.4L12 17.3 6.4 20.5l1.4-6.4L3 9.7l6.3-.7Z" />,
  Pin: (p) => <Icon {...p} d="M12 22s7-7 7-12a7 7 0 1 0-14 0c0 5 7 12 7 12Zm0-9a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />,
  Sparkle: (p) => <Icon {...p} d="M12 3v6m0 6v6M3 12h6m6 0h6M5 5l4 4m6 6 4 4M19 5l-4 4M5 19l4-4" />,
  Truck: (p) => <Icon {...p} d="M3 16V6h11v10M14 10h4l3 3v3h-7M6 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm12 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />,
  Card: (p) => <Icon {...p} d="M3 7h18v12H3zM3 11h18" />,
};

// ---- Top nav (app shell) ----------------------------------------------------
const NAV_ITEMS = [
  { key: "ringkasan", label: "Ringkasan", icon: Icons.Home },
  { key: "lahan", label: "Lahan", icon: Icons.Map },
  { key: "panen", label: "Panen", icon: Icons.Leaf },
  { key: "perawatan", label: "Perawatan", icon: Icons.Drop },
  { key: "jadwal", label: "Jadwal", icon: Icons.Calendar },
  { key: "keuangan", label: "Keuangan", icon: Icons.Wallet },
  { key: "laporan", label: "Laporan", icon: Icons.Chart },
  { key: "kalkulator", label: "Kalkulator", icon: Icons.Calc },
];

const AppTopNav = ({ active = "ringkasan", farm = "Kebun Suka Maju" }) => (
  <header
    style={{
      background: "rgba(255,255,255,0.9)",
      backdropFilter: "blur(10px)",
      borderBottom: "1px solid var(--line)",
      padding: "12px 28px",
      display: "flex",
      alignItems: "center",
      gap: 28,
      position: "sticky",
      top: 0,
      zIndex: 10,
    }}
  >
    <SHWordmark size={18} />
    <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "5px 10px 5px 12px", border: "1px solid var(--line)", borderRadius: 10, background: "var(--paper)", fontSize: 13, fontWeight: 600 }}>
      <span style={{ width: 6, height: 6, borderRadius: 99, background: "var(--emerald)" }} />
      {farm}
      <Icons.Down size={14} />
    </div>
    <nav style={{ display: "flex", alignItems: "center", gap: 2, flex: 1 }}>
      {NAV_ITEMS.map((item) => {
        const isActive = item.key === active;
        const Icon = item.icon;
        return (
          <a
            key={item.key}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 7,
              padding: "8px 12px",
              borderRadius: 10,
              fontSize: 13.5,
              fontWeight: 600,
              color: isActive ? "var(--ink)" : "var(--ink-3)",
              background: isActive ? "var(--emerald-soft)" : "transparent",
              border: isActive ? "1px solid rgba(10,120,71,0.18)" : "1px solid transparent",
              cursor: "pointer",
            }}
          >
            <Icon size={15} stroke={isActive ? "var(--emerald-2)" : "currentColor"} />
            {item.label}
          </a>
        );
      })}
    </nav>
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <button className="btn btn-ghost" style={{ padding: 8, borderRadius: 10 }}><Icons.Search size={16} /></button>
      <button className="btn btn-ghost" style={{ padding: 8, borderRadius: 10, position: "relative" }}>
        <Icons.Bell size={16} />
        <span style={{ position: "absolute", top: 5, right: 5, width: 7, height: 7, borderRadius: 99, background: "var(--terra)", border: "2px solid white" }} />
      </button>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 12px 5px 5px", border: "1px solid var(--line)", borderRadius: 999, cursor: "pointer" }}>
        <div style={{ width: 28, height: 28, borderRadius: 99, background: "linear-gradient(135deg, var(--emerald), var(--emerald-2))", color: "white", display: "grid", placeItems: "center", fontSize: 12, fontWeight: 700 }}>BS</div>
        <span style={{ fontSize: 13, fontWeight: 600 }}>Pak Budi</span>
      </div>
    </div>
  </header>
);

// ---- Page header on inner pages --------------------------------------------
const PageHeader = ({ eyebrow, title, sub, right }) => (
  <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 24, marginBottom: 20 }}>
    <div>
      {eyebrow && <div className="eyebrow" style={{ marginBottom: 8 }}>{eyebrow}</div>}
      <h1 className="display" style={{ margin: 0, fontSize: 34, fontWeight: 700, letterSpacing: "-0.025em" }}>{title}</h1>
      {sub && <p style={{ margin: "8px 0 0", color: "var(--ink-3)", maxWidth: 640, fontSize: 14.5, lineHeight: 1.55 }}>{sub}</p>}
    </div>
    {right && <div style={{ display: "flex", gap: 10 }}>{right}</div>}
  </div>
);

// ---- Inline area chart (rounded soft gradient) ------------------------------
const AreaChart = ({
  data,                     // array of numbers
  width = 600,
  height = 160,
  stroke = "var(--emerald)",
  fill = "rgba(10,120,71,0.16)",
  fillBottom = "rgba(10,120,71,0.0)",
  showGrid = true,
  padding = 8,
}) => {
  if (!data || data.length === 0) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const w = width;
  const h = height;
  const stepX = (w - padding * 2) / (data.length - 1);

  // monotone-ish smoothing using cubic with control offset
  const pts = data.map((v, i) => [padding + i * stepX, padding + (1 - (v - min) / range) * (h - padding * 2)]);
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 1; i < pts.length; i++) {
    const [x1, y1] = pts[i - 1];
    const [x2, y2] = pts[i];
    const cx = (x1 + x2) / 2;
    d += ` C ${cx} ${y1}, ${cx} ${y2}, ${x2} ${y2}`;
  }
  const area = `${d} L ${pts[pts.length - 1][0]} ${h - padding} L ${pts[0][0]} ${h - padding} Z`;
  const gradId = `g-${Math.random().toString(36).slice(2, 8)}`;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <defs>
        <linearGradient id={gradId} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={fill} />
          <stop offset="100%" stopColor={fillBottom} />
        </linearGradient>
      </defs>
      {showGrid && [0.25, 0.5, 0.75].map((p) => (
        <line key={p} x1={padding} x2={w - padding} y1={padding + p * (h - padding * 2)} y2={padding + p * (h - padding * 2)} stroke="var(--line)" strokeDasharray="2 4" />
      ))}
      <path d={area} fill={`url(#${gradId})`} />
      <path d={d} fill="none" stroke={stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      {pts.map(([x, y], i) => i === pts.length - 1 && (
        <g key={i}>
          <circle cx={x} cy={y} r="6" fill={stroke} opacity="0.15" />
          <circle cx={x} cy={y} r="3" fill={stroke} />
        </g>
      ))}
    </svg>
  );
};

// Multi-series stacked area
const MultiArea = ({ series, width = 700, height = 220, palette = ["var(--c1)", "var(--c2)", "var(--c3)", "var(--c4)"] }) => {
  // series: [{name, data:[..]}]
  const allMax = Math.max(...series.flatMap((s) => s.data));
  const allMin = 0;
  const range = allMax - allMin || 1;
  const padding = 12;
  const len = series[0].data.length;
  const stepX = (width - padding * 2) / (len - 1);

  const pathFor = (data) => {
    const pts = data.map((v, i) => [padding + i * stepX, padding + (1 - (v - allMin) / range) * (height - padding * 2)]);
    let d = `M ${pts[0][0]} ${pts[0][1]}`;
    for (let i = 1; i < pts.length; i++) {
      const [x1, y1] = pts[i - 1];
      const [x2, y2] = pts[i];
      const cx = (x1 + x2) / 2;
      d += ` C ${cx} ${y1}, ${cx} ${y2}, ${x2} ${y2}`;
    }
    const area = `${d} L ${pts[pts.length - 1][0]} ${height - padding} L ${pts[0][0]} ${height - padding} Z`;
    return { d, area };
  };
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      <defs>
        {palette.map((c, i) => (
          <linearGradient key={i} id={`ma-${i}`} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={c} stopOpacity="0.22" />
            <stop offset="100%" stopColor={c} stopOpacity="0" />
          </linearGradient>
        ))}
      </defs>
      {[0.2, 0.4, 0.6, 0.8].map((p) => (
        <line key={p} x1={padding} x2={width - padding} y1={padding + p * (height - padding * 2)} y2={padding + p * (height - padding * 2)} stroke="var(--line)" strokeDasharray="2 4" />
      ))}
      {series.map((s, i) => {
        const { d, area } = pathFor(s.data);
        return (
          <g key={i}>
            <path d={area} fill={`url(#ma-${i})`} />
            <path d={d} fill="none" stroke={palette[i % palette.length]} strokeWidth="2" strokeLinecap="round" />
          </g>
        );
      })}
    </svg>
  );
};

// Vertical bar set
const Bars = ({ data, width = 600, height = 180, color = "var(--emerald)", labels }) => {
  const max = Math.max(...data) || 1;
  const pad = 16;
  const bw = (width - pad * 2) / data.length;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      {[0.25, 0.5, 0.75].map((p) => (
        <line key={p} x1={pad} x2={width - pad} y1={p * (height - 30)} y2={p * (height - 30)} stroke="var(--line)" strokeDasharray="2 4" />
      ))}
      {data.map((v, i) => {
        const bh = (v / max) * (height - 40);
        return (
          <g key={i}>
            <rect x={pad + i * bw + 6} y={height - 22 - bh} width={bw - 12} height={bh} rx="6" fill={color} opacity={i === data.length - 1 ? 1 : 0.78} />
            {labels && <text x={pad + i * bw + bw / 2} y={height - 6} textAnchor="middle" fontSize="10.5" fill="var(--ink-4)" fontFamily="var(--font-sans)">{labels[i]}</text>}
          </g>
        );
      })}
    </svg>
  );
};

// Sparkline (mini)
const Sparkline = ({ data, color = "var(--emerald)", width = 100, height = 32 }) => {
  if (!data?.length) return null;
  const min = Math.min(...data), max = Math.max(...data), range = max - min || 1;
  const stepX = width / (data.length - 1);
  const pts = data.map((v, i) => [i * stepX, height - ((v - min) / range) * (height - 4) - 2]);
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 1; i < pts.length; i++) {
    const [x1, y1] = pts[i - 1];
    const [x2, y2] = pts[i];
    const cx = (x1 + x2) / 2;
    d += ` C ${cx} ${y1}, ${cx} ${y2}, ${x2} ${y2}`;
  }
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      <path d={d} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
};

// Donut/Ring
const Donut = ({ value, size = 88, stroke = 10, color = "var(--emerald)", track = "var(--paper-2)", label }) => {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - Math.min(1, Math.max(0, value)));
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round" transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      </svg>
      {label && (
        <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", textAlign: "center" }}>
          <div>
            <div className="num" style={{ fontSize: 18, fontWeight: 700 }}>{label}</div>
          </div>
        </div>
      )}
    </div>
  );
};

// Public marketing footer
const PublicFooter = ({ year = 2026 }) => (
  <footer style={{ borderTop: "1px solid var(--line)", padding: "48px 56px 40px", background: "var(--paper)", color: "var(--ink-3)" }}>
    <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr 1fr", gap: 40 }}>
      <div>
        <SHWordmark size={20} />
        <p style={{ fontSize: 13.5, lineHeight: 1.7, marginTop: 12, maxWidth: 280 }}>
          Aplikasi catatan kebun &amp; keuangan untuk petani sawit Indonesia. Ringkas, jelas, dipakai dari hape di kebun.
        </p>
        <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
          {["Play Store", "App Store"].map((s) => (
            <div key={s} style={{ padding: "8px 14px", border: "1px solid var(--line)", borderRadius: 10, fontSize: 12, fontWeight: 600, color: "var(--ink)", background: "white" }}>↓ {s}</div>
          ))}
        </div>
      </div>
      {[
        { h: "Produk", items: ["Fitur", "Harga", "Kalkulator pupuk", "Demo", "Roadmap"] },
        { h: "Petani", items: ["Panduan mulai", "Pertanyaan umum", "Komunitas WA", "Pelatihan", "Kontak"] },
        { h: "Perusahaan", items: ["Tentang", "Mitra koperasi", "Privasi", "Syarat", "Cookie"] },
        { h: "Hubungi", items: ["bantuan@sawithub.id", "0811-7100-200", "Senin–Sabtu 08–17", "WhatsApp Resmi"] },
      ].map((c) => (
        <div key={c.h}>
          <div className="eyebrow" style={{ marginBottom: 12 }}>{c.h}</div>
          <ul style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {c.items.map((i) => <li key={i} style={{ fontSize: 13.5 }}>{i}</li>)}
          </ul>
        </div>
      ))}
    </div>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 40, paddingTop: 24, borderTop: "1px solid var(--line)", fontSize: 12.5 }}>
      <span>© {year} SawitHub Indonesia · PT Sawit Hub Nusantara</span>
      <span>Made with 🌴 in Pekanbaru</span>
    </div>
  </footer>
);

Object.assign(window, {
  SHLogo, SHWordmark, Icons, AppTopNav, PageHeader,
  AreaChart, MultiArea, Bars, Sparkline, Donut,
  PublicFooter, NAV_ITEMS,
});
