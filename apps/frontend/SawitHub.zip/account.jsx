// Account pages — Profile, Subscription, Notifikasi

const ProfilePage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="ringkasan" />
    <div style={{ padding: "28px 28px 36px", maxWidth: 1280, margin: "0 auto" }}>
      <PageHeader
        eyebrow="Akun"
        title="Profil & Pengaturan"
        sub="Kelola informasi akun, kebun, anggota, dan preferensi pengingat."
      />

      <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 24 }}>
        {/* Sub-nav */}
        <nav style={{ position: "sticky", top: 80, alignSelf: "flex-start", display: "flex", flexDirection: "column", gap: 4 }}>
          {[
            { l: "Profil saya", i: Icons.User, active: true },
            { l: "Kebun & blok", i: Icons.Map },
            { l: "Anggota tim", i: Icons.User },
            { l: "Pengingat WA & email", i: Icons.Bell },
            { l: "Keamanan", i: Icons.Lock },
            { l: "Cookie & privasi", i: Icons.Settings },
            { l: "Bantuan", i: Icons.Phone },
          ].map((it, i) => {
            const I = it.i;
            return (
              <a key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderRadius: 10, fontSize: 13.5, fontWeight: 600, color: it.active ? "var(--ink)" : "var(--ink-3)", background: it.active ? "white" : "transparent", border: it.active ? "1px solid var(--line)" : "1px solid transparent", cursor: "pointer" }}>
                <I size={15} stroke={it.active ? "var(--emerald-2)" : "currentColor"} />
                {it.l}
              </a>
            );
          })}
        </nav>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Identity card */}
          <div className="card" style={{ padding: 28 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 20, marginBottom: 24 }}>
              <div style={{ width: 92, height: 92, borderRadius: 24, background: "linear-gradient(135deg, var(--emerald), var(--emerald-2))", color: "white", display: "grid", placeItems: "center", fontSize: 32, fontWeight: 800, position: "relative" }}>
                BS
                <button style={{ position: "absolute", bottom: -8, right: -8, width: 32, height: 32, borderRadius: 99, background: "white", border: "1px solid var(--line)", display: "grid", placeItems: "center", cursor: "pointer" }}><Icons.Plus size={14} /></button>
              </div>
              <div style={{ flex: 1 }}>
                <h2 className="display" style={{ fontSize: 26, fontWeight: 700, margin: 0, letterSpacing: "-0.02em" }}>Pak Budi Setiawan</h2>
                <div style={{ display: "flex", gap: 10, marginTop: 6, alignItems: "center" }}>
                  <span style={{ fontSize: 13, color: "var(--ink-3)" }}>Petani · Kebun Suka Maju</span>
                  <span className="chip chip-emerald" style={{ fontSize: 11 }}>✓ Terverifikasi</span>
                  <span className="chip chip-terra" style={{ fontSize: 11 }}>Petani Pro · sejak 2024</span>
                </div>
              </div>
              <button className="btn btn-ghost">Edit profil</button>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {[
                ["Nama lengkap", "Budi Setiawan", Icons.User],
                ["No. WhatsApp", "0852-1234-5678", Icons.Phone],
                ["Email", "budi.sawit@gmail.com", Icons.Mail],
                ["Lokasi", "Kampar, Riau", Icons.Pin],
                ["Bahasa & wilayah", "Bahasa Indonesia · Rp", Icons.Settings],
                ["Anggota sejak", "12 Februari 2024", Icons.Calendar],
              ].map(([l, v, I]) => (
                <div key={l} style={{ padding: 14, background: "var(--paper)", borderRadius: 12 }}>
                  <div style={{ fontSize: 11, color: "var(--ink-4)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>{l}</div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6 }}>
                    <I size={14} stroke="var(--ink-3)" />
                    <span style={{ fontSize: 14, fontWeight: 600 }}>{v}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Activity summary */}
          <div className="card" style={{ padding: 28 }}>
            <div className="eyebrow">Ringkasan aktivitas</div>
            <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 18px" }}>Sejak bergabung</h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
              {[
                ["Kebun dikelola", "6", "blok", "var(--c1)"],
                ["Panen tercatat", "284", "kali", "var(--c2)"],
                ["Hasil panen total", "642", "ton", "var(--c4)"],
                ["Laporan diunduh", "48", "kali", "var(--c5)"],
              ].map(([l, v, u, c]) => (
                <div key={l} style={{ padding: 18, borderRadius: 14, background: "var(--paper)", borderTop: `3px solid ${c}` }}>
                  <div style={{ fontSize: 11, color: "var(--ink-4)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>{l}</div>
                  <div className="num" style={{ fontSize: 32, fontWeight: 800, marginTop: 6, letterSpacing: "-0.025em" }}>{v}<span style={{ fontSize: 14, color: "var(--ink-4)", fontWeight: 500, marginLeft: 4 }}>{u}</span></div>
                </div>
              ))}
            </div>
          </div>

          {/* Team */}
          <div className="card" style={{ padding: 28 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div>
                <div className="eyebrow">Anggota tim</div>
                <h3 className="display" style={{ fontSize: 20, fontWeight: 700, margin: "4px 0 0" }}>4 anggota di akun ini</h3>
              </div>
              <button className="btn btn-ghost"><Icons.Plus size={14} /> Tambah anggota</button>
            </div>
            {[
              { n: "Pak Budi Setiawan", r: "Pemilik · semua akses", c: "var(--emerald)", i: "BS" },
              { n: "Pak Hadi (mandor)", r: "Catat panen & rawat", c: "var(--c4)", i: "PH" },
              { n: "Bu Sari (admin)", r: "Lihat laporan", c: "var(--c5)", i: "BS" },
              { n: "Rian (anak)", r: "Catat panen saja", c: "var(--c3)", i: "RN" },
            ].map((m, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 14, padding: "12px 0", borderTop: i ? "1px solid var(--line)" : "none" }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: m.c, color: "white", display: "grid", placeItems: "center", fontSize: 13, fontWeight: 700 }}>{m.i}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>{m.n}</div>
                  <div style={{ fontSize: 12, color: "var(--ink-4)" }}>{m.r}</div>
                </div>
                <button className="btn btn-ghost" style={{ fontSize: 12 }}>Atur akses</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);

const SubscriptionPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="ringkasan" />
    <div style={{ padding: "28px 28px 36px", maxWidth: 1280, margin: "0 auto" }}>
      <PageHeader
        eyebrow="Berlangganan"
        title="Paket & Pembayaran"
        sub="Atur paket berlangganan, riwayat pembayaran, dan detail tagihan."
      />

      {/* Active plan banner */}
      <div className="card" style={{ padding: 32, background: "linear-gradient(120deg, var(--emerald-2) 0%, var(--emerald) 100%)", color: "white", border: "none", position: "relative", overflow: "hidden", marginBottom: 16 }}>
        <div style={{ position: "absolute", right: -60, top: -60, opacity: 0.1, color: "white" }}><SHLogo size={280} mono /></div>
        <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 32, position: "relative" }}>
          <div>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "5px 12px", background: "var(--terra)", borderRadius: 99, fontSize: 11, fontWeight: 800, letterSpacing: "0.06em", textTransform: "uppercase" }}>
              <Icons.Star size={11} stroke="white" /> Paket aktif
            </div>
            <h2 className="display" style={{ fontSize: 38, fontWeight: 700, margin: "12px 0 8px", letterSpacing: "-0.025em" }}>Petani Pro</h2>
            <p style={{ fontSize: 14, color: "rgba(255,255,255,0.75)", margin: 0, lineHeight: 1.5 }}>Berlangganan sejak 12 Februari 2024 · Pembayaran berikutnya 12 Juni 2026 (Rp 49.000).</p>
            <div style={{ display: "flex", gap: 10, marginTop: 24 }}>
              <button className="btn" style={{ background: "white", color: "var(--ink)", padding: "10px 18px" }}>Ganti paket</button>
              <button className="btn" style={{ background: "transparent", color: "white", border: "1px solid rgba(255,255,255,0.3)", padding: "10px 18px" }}>Atur pembayaran</button>
            </div>
          </div>
          <div style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 16, padding: 22 }}>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 8 }}>Pemakaian bulan ini</div>
            {[
              ["Catatan panen", "12 / tak terbatas", 0.18, "var(--terra)"],
              ["Kebun aktif", "6 / tak terbatas", 0.32, "var(--c3)"],
              ["Laporan diunduh", "8 dari kuota wajar", 0.4, "var(--c1)"],
            ].map((u, i) => (
              <div key={i} style={{ marginTop: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontSize: 12, fontWeight: 600 }}>{u[0]}</span>
                  <span style={{ fontSize: 11, color: "rgba(255,255,255,0.6)" }}>{u[1]}</span>
                </div>
                <div style={{ height: 5, background: "rgba(255,255,255,0.12)", borderRadius: 99, overflow: "hidden" }}>
                  <div style={{ width: `${u[2] * 100}%`, height: "100%", background: u[3] }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {/* Plan compare */}
        <div className="card" style={{ padding: 28 }}>
          <div className="eyebrow">Tingkatkan</div>
          <h3 className="display" style={{ fontSize: 22, fontWeight: 700, margin: "4px 0 18px" }}>Naik ke Koperasi</h3>
          <p style={{ fontSize: 13.5, color: "var(--ink-3)", lineHeight: 1.6, margin: "0 0 18px" }}>
            Cocok jika kamu ingin mengelola anggota koperasi atau kelompok tani 50+ petani. Dapat akun multi-anggota, rekap koperasi, dan API integrasi PKS.
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {[
              "Akun anggota tak terbatas",
              "Rekap koperasi + SHU otomatis",
              "API integrasi pabrik kelapa sawit",
              "Pelatihan onsite untuk anggota",
              "Dedicated success manager",
            ].map((f) => (
              <div key={f} style={{ display: "flex", gap: 10, fontSize: 13.5, alignItems: "center" }}>
                <Icons.Check size={14} stroke="var(--emerald-2)" />{f}
              </div>
            ))}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 24, paddingTop: 20, borderTop: "1px solid var(--line)" }}>
            <div>
              <div className="num" style={{ fontSize: 28, fontWeight: 800, letterSpacing: "-0.02em" }}>Hubungi kami</div>
              <div style={{ fontSize: 12, color: "var(--ink-4)" }}>harga sesuai jumlah anggota</div>
            </div>
            <button className="btn btn-primary">Diskusi dengan tim <Icons.Arrow size={14} /></button>
          </div>
        </div>

        {/* Payment history */}
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ padding: "22px 24px", borderBottom: "1px solid var(--line)" }}>
            <div className="eyebrow">Riwayat pembayaran</div>
            <h3 className="display" style={{ fontSize: 22, fontWeight: 700, margin: "4px 0 0" }}>27 tagihan</h3>
          </div>
          {[
            { d: "12 Mei 2026", a: "Rp 49.000", s: "Lunas", m: "Bank BSI · ****4282", c: "chip-emerald" },
            { d: "12 Apr 2026", a: "Rp 49.000", s: "Lunas", m: "Bank BSI · ****4282", c: "chip-emerald" },
            { d: "12 Mar 2026", a: "Rp 49.000", s: "Lunas", m: "GoPay", c: "chip-emerald" },
            { d: "12 Feb 2026", a: "Rp 49.000", s: "Lunas", m: "Bank BSI · ****4282", c: "chip-emerald" },
            { d: "12 Jan 2026", a: "Rp 540.000", s: "Tahunan", m: "Bank Mandiri · ****8821", c: "chip-warn" },
          ].map((p, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", padding: "14px 24px", borderTop: "1px solid var(--line)", fontSize: 13 }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: "var(--paper)", display: "grid", placeItems: "center", marginRight: 14 }}>
                <Icons.Card size={16} stroke="var(--ink-3)" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700 }}>{p.d}</div>
                <div style={{ fontSize: 11, color: "var(--ink-4)" }}>{p.m}</div>
              </div>
              <div className="num" style={{ fontSize: 14, fontWeight: 700, marginRight: 16 }}>{p.a}</div>
              <span className={`chip ${p.c}`} style={{ fontSize: 11 }}>{p.s}</span>
              <button style={{ marginLeft: 12, padding: 6, background: "transparent", border: "none", cursor: "pointer" }}><Icons.Download size={14} stroke="var(--ink-3)" /></button>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const NotifikasiPage = () => (
  <div className="pg-app" style={{ width: 1440 }}>
    <AppTopNav active="ringkasan" />
    <div style={{ padding: "28px 28px 36px", maxWidth: 1180, margin: "0 auto" }}>
      <PageHeader
        eyebrow="Pemberitahuan"
        title="Notifikasi"
        sub="Pengingat jadwal, perubahan harga TBS, dan update sistem."
        right={
          <>
            <button className="btn btn-ghost">Tandai semua dibaca</button>
            <button className="btn btn-ghost"><Icons.Settings size={14} /> Atur</button>
          </>
        }
      />

      {/* Tabs */}
      <div style={{ display: "flex", gap: 24, borderBottom: "1px solid var(--line)", marginBottom: 20 }}>
        {[
          { l: "Semua", n: 14, active: true },
          { l: "Jadwal", n: 4 },
          { l: "Harga TBS", n: 3 },
          { l: "Keuangan", n: 5 },
          { l: "Sistem", n: 2 },
        ].map((t, i) => (
          <button key={i} style={{ padding: "10px 0", background: "transparent", border: "none", fontSize: 14, fontWeight: 700, color: t.active ? "var(--ink)" : "var(--ink-4)", borderBottom: t.active ? "2px solid var(--ink)" : "2px solid transparent", marginBottom: -1, display: "inline-flex", gap: 8, alignItems: "center", cursor: "pointer" }}>
            {t.l}
            <span style={{ fontSize: 11, padding: "1px 7px", background: t.active ? "var(--emerald-soft)" : "var(--paper-2)", color: t.active ? "var(--emerald-2)" : "var(--ink-3)", borderRadius: 99, fontWeight: 700 }}>{t.n}</span>
          </button>
        ))}
      </div>

      {/* Notification list grouped by day */}
      {[
        {
          day: "Hari ini · Senin, 14 Mei 2026",
          items: [
            { unread: true, c: "var(--c3)", icon: Icons.Sparkle, title: "Harga TBS naik 4,2% pagi ini", body: "Disbun Riau mengumumkan Rp 2.340/kg, naik Rp 95 dari kemarin. Pertimbangkan jadwal panen.", time: "09:42", chip: "Harga" },
            { unread: true, c: "var(--c2)", icon: Icons.Calendar, title: "Jadwal besok: Pemupukan NPK Blok A", body: "240 pohon · Pak Hadi. Bahan: NPK 12-12-27 sudah tercatat di gudang.", time: "08:15", chip: "Jadwal" },
            { unread: true, c: "var(--c5)", icon: Icons.Drop, title: "Saran AI · Biaya rawat Tani Makmur naik 38%", body: "Cek apakah kondisi tanah perlu pemulihan. Lihat saran lengkap di dashboard.", time: "08:00", chip: "Saran" },
          ],
        },
        {
          day: "Kemarin · Minggu, 13 Mei 2026",
          items: [
            { unread: false, c: "var(--c1)", icon: Icons.Check, title: "Pembayaran Petani Pro berhasil", body: "Rp 49.000 dibayar via Bank BSI ****4282. Tagihan PDF sudah dikirim ke email.", time: "12 Mei · 23:01", chip: "Tagihan" },
            { unread: false, c: "var(--c4)", icon: Icons.Chart, title: "Laporan bulanan April 2026 siap", body: "Pendapatan Rp 108jt · Biaya Rp 52jt · Laba bersih Rp 56jt. Unduh PDF untuk koperasi.", time: "12 Mei · 18:30", chip: "Laporan" },
          ],
        },
        {
          day: "Minggu lalu",
          items: [
            { unread: false, c: "var(--c6)", icon: Icons.Bell, title: "Pengingat Pruning Blok C", body: "Sudah 6 bulan sejak pruning terakhir. Atur jadwal supaya akses panen tetap lancar.", time: "08 Mei · 07:00", chip: "Pengingat" },
            { unread: false, c: "var(--terra)", icon: Icons.Sparkle, title: "Subsidi PSR diterima Rp 8,4jt", body: "Pencairan PSR untuk Suka Maju · A dari Dinas Perkebunan Riau telah masuk rekening.", time: "08 Mei · 10:22", chip: "Keuangan" },
          ],
        },
      ].map((g) => (
        <div key={g.day} style={{ marginBottom: 24 }}>
          <div className="eyebrow" style={{ marginBottom: 10 }}>{g.day}</div>
          <div className="card" style={{ padding: 0, overflow: "hidden" }}>
            {g.items.map((n, i) => {
              const I = n.icon;
              return (
                <div key={i} style={{ display: "flex", gap: 16, padding: 18, borderBottom: i < g.items.length - 1 ? "1px solid var(--line)" : "none", background: n.unread ? "rgba(10,120,71,0.03)" : "transparent" }}>
                  <div style={{ width: 42, height: 42, borderRadius: 12, background: n.c, color: "white", display: "grid", placeItems: "center", flexShrink: 0 }}><I size={18} stroke="white" /></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 14 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        {n.unread && <span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--terra)" }} />}
                        <span style={{ fontSize: 14, fontWeight: 700 }}>{n.title}</span>
                        <span className="chip" style={{ fontSize: 10, padding: "2px 7px" }}>{n.chip}</span>
                      </div>
                      <span style={{ fontSize: 11, color: "var(--ink-4)", fontFamily: "var(--font-mono)", flexShrink: 0 }}>{n.time}</span>
                    </div>
                    <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--ink-3)", lineHeight: 1.55 }}>{n.body}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  </div>
);

Object.assign(window, { ProfilePage, SubscriptionPage, NotifikasiPage });
